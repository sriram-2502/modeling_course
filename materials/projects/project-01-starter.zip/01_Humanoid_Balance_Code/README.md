# Project 01: fit a LIPM for standing and walking

1. Open this folder in MATLAB. Run `check_setup`, then `replay_data`.
2. Read `docs/student_code_guide.pdf` and `docs/project_description.pdf`.
3. Complete `+student/model_matrices.m` and `+student/fit_lipm.m`.
4. Build the Dynamics subsystem in `models/g1_student_lipm.slx`.
5. Run `run_project`. It fits each condition once, checks your matrix/Simulink
   agreement and tests the frozen fits across horizons and push levels.
6. Use `animate_results` and `plot_model_errors` to review saved outputs.

One model: xddot = a*(x-COP) + F/m. Fit positive effective coefficient a
separately for standing and walking; supplied mass is not fitted.
The 10 N runs S1/W1 are training. Other runs are validation/illustrations.
Each evaluation forecast starts once at push onset and runs without resets.

Edit `fit_setup.m` to choose test horizons and an accuracy tolerance. The
supplied 10 mm tolerance is illustrative, not a grading threshold.
Future COP and push histories are supplied from the logs: predictions are
conditional on these inputs, not autonomous footstep or disturbance forecasts.

Replay needs base MATLAB. Modeling needs MATLAB and Simulink only. MuJoCo,
Python and robotics toolboxes are not required on the student machine.
Do not change the supplied reference CSVs.
