function [A,B]=model_matrices(m,a)
% TASK 1b: z=[x;v], input=[COP;F], zdot=A*z+B*input.
% Starting equation: xddot=a*(x-COP)+F/m. a has units s^-2.
% Return two 2-by-2 matrices; use eig(A) to explain the unstable mode.
error('g1:TODO','Derive and fill student.model_matrices.');
end
