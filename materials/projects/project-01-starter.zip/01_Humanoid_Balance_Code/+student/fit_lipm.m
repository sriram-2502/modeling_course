function a=fit_lipm(training,m)
% TASK 1b / 2b: fit one positive effective LIPM coefficient a (s^-2).
% Equation: xddot = a*(x-COP) + F/m. Mass is supplied; do not fit m.
% Use only the provided training table, never validation runs.
% provided.training_loss(a,training,m) returns COM prediction MSE on the
% prescribed training interval. Base MATLAB fminbnd is one suitable method.
% fit_setup.m supplies reference bounds. Explain/check your estimate.
error('g1:TODO','Complete student.fit_lipm to return a positive fitted coefficient.');
end
