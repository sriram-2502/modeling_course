function states=simulate_forecast(T,m,a)
% Supplied interface: YOU build models/g1_student_lipm.slx.
% The forecast initializes once from T's first row. No intermediate reset.
% Return N-by-2 [COM position (m), velocity (m/s)].
states=provided.simulate_model(T,m,a);
end
