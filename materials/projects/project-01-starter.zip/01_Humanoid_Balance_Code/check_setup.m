%% Read-only check; student functions may still contain TODOs.
folder=fileparts(mfilename('fullpath'));addpath(folder);R=provided.load_data;assert(height(R.manifest)==10);
fprintf('Loaded ten scenarios. Run replay_data, then read docs/student_code_guide.pdf.\n');
