%% Replay your saved fit/predictions, or explore the reference first.
folder=fileparts(mfilename('fullpath'));addpath(folder);p=provided.settings;file=fullfile(p.outputFolder,'student_results.mat');
if isfile(file),s=load(file,'results');reference=s.results;else,reference=provided.load_data;end
replayFigure=provided.viewer(reference);
