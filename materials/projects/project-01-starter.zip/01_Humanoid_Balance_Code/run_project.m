%% Fit one LIPM per condition, then test horizon and disturbance without resets.
folder=fileparts(mfilename('fullpath'));addpath(folder);results=provided.load_data;p=results.settings;
fitRows=struct([]);coefficients=zeros(1,2);
for j=1:2
 id=p.design.trainingIDs(j);k=find(results.manifest.ID==id,1);
 a=student.fit_lipm(results.runs{k},results.metadata{k}.Mass_kg);
 assert(isscalar(a)&&isfinite(a)&&a>0,'Return a positive finite scalar coefficient.');
 [loss,samples]=provided.training_loss(a,results.runs{k},results.metadata{k}.Mass_kg);
 info=struct('TrainingPositionRMSE_mm',1000*sqrt(loss),'TrainingSamples',samples);coefficients(j)=a;
 row=struct('Condition',results.manifest.Condition(k),'TrainingRun',id,'Coefficient_per_s2',a, ...
  'EquivalentHeight_m',p.g/a,'UnstablePole_per_s',sqrt(a));
 for name=fieldnames(info)',row.(name{1})=info.(name{1});end
 fitRows=[fitRows;row]; %#ok<AGROW>
end
results.fits=struct2table(fitRows);results.predictions=cell(height(results.manifest),1);
checks=struct([]);
for j=1:2
 k=find(results.manifest.ID==p.design.trainingIDs(j),1);
 check=provided.verify_model(results.runs{k},results.metadata{k}.Mass_kg,coefficients(j));
 check.TrainingRun=p.design.trainingIDs(j);checks=[checks;check]; %#ok<AGROW>
end
results.verification=struct2table(checks);writetable(results.verification,fullfile(p.outputFolder,'simulink_verification.csv'));
metrics=struct([]);allHorizons=table;
for k=1:height(results.manifest)
 T=results.runs{k};j=find(results.fits.Condition==results.manifest.Condition(k),1);a=coefficients(j);
 [z,row,H]=provided.evaluate_case(T,results.metadata{k}.Mass_kg,a,p,@student.simulate_forecast);results.predictions{k}=z;
 row.Run=results.manifest.ID(k);row.Condition=results.manifest.Condition(k);row.PeakForce_N=results.manifest.PeakForce_N(k);
 row.ReferenceOutcome=results.manifest.Outcome(k);row.IsTrainingRun=ismember(row.Run,p.design.trainingIDs);
 metrics=[metrics;row]; %#ok<AGROW>
 H.Run=repmat(row.Run,height(H),1);H.Condition=repmat(row.Condition,height(H),1);H.PeakForce_N=repmat(row.PeakForce_N,height(H),1);
 allHorizons=[allHorizons;H]; %#ok<AGROW>
 T.PredictedCOMX_m=z(:,1);T.PredictedCOMVX_mps=z(:,2);writetable(T,fullfile(p.outputFolder,row.Run+"_prediction.csv"));
end
results.metrics=struct2table(metrics);results.horizonMetrics=allHorizons;
writetable(results.fits,fullfile(p.outputFolder,'fitted_parameters.csv'));writetable(results.metrics,fullfile(p.outputFolder,'case_metrics.csv'));
writetable(allHorizons,fullfile(p.outputFolder,'horizon_metrics.csv'));
save(fullfile(p.outputFolder,'student_results.mat'),'results');provided.plot_results(results);disp(results.fits);disp(results.metrics);
if ~exist('showAnimation','var')||showAnimation,provided.viewer(results);end
