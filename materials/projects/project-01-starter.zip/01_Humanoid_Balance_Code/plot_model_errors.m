%% Refresh plots from YOUR saved model results without rerunning Simulink.
folder=fileparts(mfilename('fullpath'));addpath(folder);p=provided.settings;s=load(fullfile(p.outputFolder,'student_results.mat'),'results');provided.plot_results(s.results);
figure('Color','w');image(imread(fullfile(p.outputFolder,'horizon_disturbance.png')));axis image off;
