function plot_results(R)
p=R.settings;f=figure('Visible','off','Color','w','Position',[30 30 1100 700]);tiledlayout(2,2,'TileSpacing','compact');
for j=1:2
 ids=["S2","W2"];k=find(R.manifest.ID==ids(j),1);T=R.runs{k};z=R.predictions{k};
 shown=T.Time_s>=p.design.forecastStart_s-1e-8&T.Time_s<=p.design.forecastStart_s+min(1.6,max(p.design.horizons_s))+1e-8;
 nexttile(j);plot(T.Time_s(shown),T.COMX_m(shown),'Color',[.05 .49 .53],'LineWidth',1.8);hold on;
 plot(T.Time_s(shown),z(shown,1),'--','Color',[.32 .18 .5],'LineWidth',1.6);grid on;
 xlim([p.design.forecastStart_s p.design.forecastStart_s+min(1.6,max(p.design.horizons_s))]);
 ylabel('COM position (m)');title(R.manifest.Condition(k)+" | 30 N validation");
 legend('MuJoCo','Fitted LIPM','Location','northoutside','Orientation','horizontal');
 nexttile(j+2);plot(T.Time_s(shown),1000*(z(shown,1)-T.COMX_m(shown)),'Color',[.32 .18 .5],'LineWidth',1.7);hold on;grid on;
 yline(p.design.positionTolerance_mm,'r:');yline(-p.design.positionTolerance_mm,'r:');
 xlim([p.design.forecastStart_s p.design.forecastStart_s+min(1.6,max(p.design.horizons_s))]);ylim(3*p.design.positionTolerance_mm*[-1 1]);
 ylabel('Prediction - MuJoCo (mm)');xlabel('Time (s)');title('Error zoom | one initialization; no resets');
end
exportgraphics(f,fullfile(p.outputFolder,'validation_predictions.png'),'Resolution',180);close(f);
f=figure('Visible','off','Color','w','Position',[30 30 1100 500]);tiledlayout(1,2);
for j=1:2
 nexttile;hold on;grid on;condition=["Standing","Walking"];
 for force=[10 30 100 500]
  A=R.horizonMetrics(R.horizonMetrics.Condition==condition(j)&R.horizonMetrics.PeakForce_N==force,:);
  plot(A.Horizon_s,A.PeakPositionError_mm,'o-','LineWidth',1.5,'DisplayName',sprintf('%g N',force));
 end
 yline(p.design.positionTolerance_mm,'k--','Tolerance','HandleVisibility','off');
 set(gca,'YScale','log');xlabel('Prediction horizon (s)');ylabel('Peak error up to horizon (mm)');
 title(condition(j));legend('Location','northoutside','Orientation','horizontal','FontSize',9);
end
sgtitle('Fit on 10 N only | larger pushes are validation | unavailable reference intervals are not scored');
exportgraphics(f,fullfile(p.outputFolder,'horizon_disturbance.png'),'Resolution',180);close(f);
f=figure('Visible','off','Color','w','Position',[30 30 1000 400]);tiledlayout(1,2);
for j=1:2
 k=find(R.manifest.ID==p.design.trainingIDs(j),1);T=R.runs{k};z=R.predictions{k};
 shown=T.Time_s>=p.design.forecastStart_s-1e-8&T.Time_s<=p.design.forecastStart_s+p.design.fitDuration_s+1e-8;
 nexttile;plot(T.Time_s(shown),T.COMX_m(shown),'Color',[.05 .49 .53],'LineWidth',1.8);hold on;
 plot(T.Time_s(shown),z(shown,1),'--','Color',[.32 .18 .5],'LineWidth',1.7);grid on;
 xlabel('Time (s)');ylabel('COM position (m)');title(R.manifest.Condition(k)+" | 10 N training");
 legend('MuJoCo','Fitted LIPM','Location','northoutside','Orientation','horizontal');
end
exportgraphics(f,fullfile(p.outputFolder,'training_fit.png'),'Resolution',180);close(f);
end

