function create_scaffold
% CREATE_SCAFFOLD Wiring only: students supply the Dynamics subsystem.
p=provided.settings;name='g1_student_lipm';file=fullfile(p.modelFolder,[name '.slx']);
if isfile(file)
 load_system(file);assert(~isempty(find_system(name,'Name','Replace with your LIPM')),'Refusing to overwrite a completed model.');close_system(name,0);
end
new_system(name);clean=onCleanup(@()close_system(name,0));
add_block('simulink/Sources/From Workspace',[name '/Measured COP'],'VariableName','copInput','Position',[30 65 155 100]);
add_block('simulink/Sources/From Workspace',[name '/Measured push'],'VariableName','forceInput','Position',[30 160 155 195]);
add_block('built-in/Subsystem',[name '/Dynamics'],'Position',[240 60 430 205]);
add_block('simulink/Ports & Subsystems/In1',[name '/Dynamics/COP'],'Port','1','Position',[25 35 55 55]);
add_block('simulink/Ports & Subsystems/In1',[name '/Dynamics/Force'],'Port','2','Position',[25 105 55 125]);
add_block('simulink/Sources/Constant',[name '/Dynamics/Replace with your LIPM'], ...
    'Value','[initialX;initialV]','Position',[120 45 250 95]);
add_block('simulink/Sinks/Terminator',[name '/Dynamics/Unused COP'],'Position',[95 32 115 58]);
add_block('simulink/Sinks/Terminator',[name '/Dynamics/Unused force'],'Position',[95 102 115 128]);
add_block('simulink/Ports & Subsystems/Out1',[name '/Dynamics/States'],'Position',[320 60 350 80]);
add_line([name '/Dynamics'],'COP/1','Unused COP/1');add_line([name '/Dynamics'],'Force/1','Unused force/1');
add_line([name '/Dynamics'],'Replace with your LIPM/1','States/1');
add_block('simulink/Sinks/To Workspace',[name '/Output'],'VariableName','states','SaveFormat','Timeseries','Position',[515 105 625 145]);
add_line(name,'Measured COP/1','Dynamics/1');add_line(name,'Measured push/1','Dynamics/2');add_line(name,'Dynamics/1','Output/1');
set_param(name,'Solver','ode45','RelTol','1e-8','AbsTol','1e-10','MaxStep','.005','ReturnWorkspaceOutputs','on','StopTime','stopTime');
mw=get_param(name,'ModelWorkspace');values=struct('m',32.1069,'a',14.2, ...
    'initialX',0,'initialV',0,'stopTime',.2,'copInput',timeseries([0;0],[0;.2]),'forceInput',timeseries([0;0],[0;.2]));
for key=fieldnames(values)',assignin(mw,key{1},values.(key{1}));end
save_system(name,file);
end
