function states=predict(T,m,a)
% Fast calibration propagation using the state matrices YOU derive.
[A,B]=student.model_matrices(m,a);
assert(isequal(size(A),[2 2])&&isequal(size(B),[2 2]),'A and B must be 2-by-2.');
states=provided.propagate(T,A,B);
end
