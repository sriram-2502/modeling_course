function [loss,count]=training_loss(a,T,m)
p=provided.settings;
% One continuous training forecast; no resetting to later measured COM states.
start=p.design.forecastStart_s;stop=start+p.design.fitDuration_s;
W=T(T.Time_s>=start-1e-8&T.Time_s<=stop+1e-8,:);
assert(height(W)>=2&&W.Time_s(end)-W.Time_s(1)>=p.design.fitDuration_s-1e-6&&all(W.COPValid)&~any(W.Fallen), ...
 'The prescribed training interval must be fully supported.');
z=provided.predict(W,m,a);count=height(W);loss=mean((z(:,1)-W.COMX_m).^2);
end
