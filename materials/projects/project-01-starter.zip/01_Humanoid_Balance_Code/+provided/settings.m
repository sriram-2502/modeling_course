function p=settings
p.folder=fileparts(fileparts(mfilename('fullpath')));p.root=p.folder;
p.dataFolder=fullfile(p.folder,'data');p.outputFolder=fullfile(p.folder,'results');p.modelFolder=fullfile(p.folder,'models');p.g=9.81;
run(fullfile(p.folder,'fit_setup.m'));p.design=design;
p.evaluationMode='single_rollout';p.windowDuration=max(design.horizons_s);p.windowSpacing=nan;
if ~isfolder(p.outputFolder),mkdir(p.outputFolder);end
end
