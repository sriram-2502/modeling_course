function states=propagate(T,A,B)
% Generic exact propagation for a two-state linear model and linear inputs.
u=[T.COPX_m T.PushForce_N];states=zeros(height(T),2);
states(1,:)=[T.COMX_m(1) T.COMVX_mps(1)];
M=[A B zeros(2);zeros(2,4) eye(2);zeros(2,6)];last=nan;E=[];
for j=1:height(T)-1
 dt=T.Time_s(j+1)-T.Time_s(j);assert(dt>0);
 if isempty(E)||abs(dt-last)>1e-10,E=expm(M*dt);last=dt;end
 q=E*[states(j,:)';u(j,:)';(u(j+1,:)-u(j,:))'/dt];states(j+1,:)=q(1:2)';
end
end
