function states=simulate_model(T,m,a)
% Supplied execution wrapper; dynamics must be built in your Simulink model.
p=provided.settings;name='g1_student_lipm';load_system(fullfile(p.modelFolder,[name '.slx']));
if ~isempty(find_system(name,'Name','Replace with your LIPM'))
 error('g1:BuildModel','Build Dynamics, remove the placeholder and save the SLX. See docs/student_code_guide.pdf.');
end
t=round(T.Time_s-T.Time_s(1),10);
values=struct('copInput',timeseries(T.COPX_m,t),'forceInput',timeseries(T.PushForce_N,t), ...
 'm',m,'a',a,'initialX',T.COMX_m(1),'initialV',T.COMVX_mps(1),'stopTime',t(end));
in=Simulink.SimulationInput(name);
for key=fieldnames(values)',in=in.setVariable(key{1},values.(key{1}),'Workspace',name);end
in=in.setModelParameter('OutputOption','SpecifiedOutputTimes','OutputTimes',mat2str(t',17));
out=sim(in);ts=out.states;z=squeeze(ts.Data);if size(z,1)~=numel(ts.Time),z=z';end
states=interp1(ts.Time,z,t);assert(isequal(size(states),[height(T) 2]),'Output must be N-by-2 [x v].');
end
