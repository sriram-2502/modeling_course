function [prediction,summary,horizons]=evaluate_case(T,m,a,p,simulate)
% ONE initial condition at push onset. No reset as the horizon increases.
start=p.design.forecastStart_s;H=sort(unique(p.design.horizons_s(:)))';
indices=find(T.Time_s>=start-1e-8&T.Time_s<=start+max(H)+1e-8);
W=T(indices,:);reason="Maximum requested horizon";
bad=find(~W.COPValid|W.Fallen|~isfinite(W.COPX_m),1);
if ~isempty(bad),indices=indices(1:bad-1);W=W(1:bad-1,:);reason="Reference support/fall limit";
elseif isempty(W)||W.Time_s(end)<start+max(H)-1e-6,reason="Reference ended";end
prediction=nan(height(T),2);rows=struct([]);lossLead=nan;maxUseful=0;available=0;
z=[];error=[];
if height(W)>=2
 z=simulate(W,m,a);assert(isequal(size(z),[height(W) 2]));
 prediction(indices,:)=z;error=1000*(z(:,1)-W.COMX_m);
 available=W.Time_s(end)-start;
 first=find(abs(error)>p.design.positionTolerance_mm|~isfinite(error),1);
 if ~isempty(first),lossLead=W.Time_s(first)-start;end
end
for horizon=H
 peak=nan;rmse=nan;endpoint=nan;status="Unvalidated";
 if available>=horizon-1e-8
  use=W.Time_s<=start+horizon+1e-8;e=error(use);
  peak=max(abs(e));rmse=sqrt(mean(e.^2));endpoint=e(end);
  if all(isfinite(e))&&peak<=p.design.positionTolerance_mm,status="WithinTolerance";maxUseful=max(maxUseful,horizon);
  else,status="ExceedsTolerance";end
 end
 rows=[rows;struct('Horizon_s',horizon,'Status',status,'PeakPositionError_mm',peak, ...
  'PositionRMSE_mm',rmse,'EndpointError_mm',endpoint)]; %#ok<AGROW>
end
horizons=struct2table(rows);
summary=struct('Coefficient_per_s2',a,'AvailableLead_s',available,'AccuracyLossLead_s',lossLead, ...
 'LargestUsefulTestedHorizon_s',maxUseful,'PositionTolerance_mm',p.design.positionTolerance_mm,'ReferenceLimit',reason);
end
