function R=load_data
p=provided.settings;M=readtable(fullfile(p.dataFolder,'manifest.csv'),'TextType','string');
runs=cell(height(M),1);metadata=runs;
for k=1:height(M)
 runs{k}=readtable(fullfile(p.dataFolder,M.File(k)));
 metadata{k}=jsondecode(fileread(fullfile(p.dataFolder,M.ID(k)+"_metadata.json")));
end
R=struct('settings',p,'manifest',M,'runs',{runs},'metadata',{metadata});
end
