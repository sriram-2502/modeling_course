function row=verify_model(T,m,a)
% Compare your matrices and your Simulink diagram on identical inputs.
p=provided.settings;start=p.design.forecastStart_s;
W=T(T.Time_s>=start-1e-8&T.Time_s<=start+.2+1e-8,:);
fast=provided.predict(W,m,a);slx=student.simulate_forecast(W,m,a);delta=max(abs(fast-slx),[],1);
row=struct('PositionDifference_m',delta(1),'VelocityDifference_mps',delta(2),'Pass',all(delta<1e-5));
assert(row.Pass,'Your matrices and Simulink diagram disagree. Check signs, initial states and [x v] output order.');
end
