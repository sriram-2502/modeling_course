function fig = viewer(R,varargin)
% VIEWER Recorded standing/walking poses; LIPM predicts COM position only.
ip=inputParser;addParameter(ip,'Visible','on');addParameter(ip,'AutoPlay',true);parse(ip,varargin{:});
p=R.settings;cache=fullfile(p.outputFolder,'replay_geometry.mat');
if isfile(cache),saved=load(cache,'model');model=saved.model;
else
    saved=load(fullfile(p.dataFolder,'g1_replay_geometry.mat'),'model');model=saved.model;
    for k=1:numel(model.geoms)
        M=model.geoms{k};if size(M.faces,1)>1000,[M.faces,M.vertices]=reducepatch(M.faces,M.vertices,1000);end
        model.geoms{k}=M;
    end
    save(cache,'model');
end
fig=figure('Name','G1 | Standing and walking LIPM','Color','w','Position',[35 35 1250 760], ...
    'Visible',ip.Results.Visible,'MenuBar','none','ToolBar','figure');
annotation(fig,'textbox',[.04 .94 .93 .04],'String','Observe standing and walking. Model COM motion.', ...
    'FontWeight','bold','FontSize',18,'EdgeColor','none');
menu=uicontrol(fig,'Style','popupmenu','String',cellstr(R.manifest.ID+" | "+R.manifest.Condition+" | "+R.manifest.Role), ...
    'Value',1,'Units','normalized','Position',[.04 .88 .92 .04],'Callback',@change);
ax=axes(fig,'Position',[.035 .23 .43 .62]);hold(ax,'on');grid(ax,'on');axis(ax,'equal');view(ax,135,15);
xlim(ax,[-.7 .8]);ylim(ax,[-.35 .35]);zlim(ax,[0 1.4]);xlabel(ax,'X (m)');ylabel(ax,'Y (m)');zlabel(ax,'Height (m)');
floorPatch=patch(ax,'XData',[-1 1 1 -1],'YData',[-.5 -.5 .5 .5],'ZData',zeros(1,4),'FaceColor',[.92 .94 .97],'EdgeColor','none');
objects=gobjects(numel(model.geoms),1);
for j=1:numel(objects)
    M=model.geoms{j};objects(j)=patch(ax,'Faces',M.faces,'Vertices',M.vertices,'FaceColor',M.color(:)', ...
        'EdgeColor','none','FaceLighting','gouraud','AmbientStrength',.6);
end
camlight(ax,'headlight');
% A transparent foreground axes keeps indicators visible through the meshes.
% Link its camera to the robot axes so markers stay registered during rotation.
overlay=axes(fig,'Position',ax.Position,'Color','none','Visible','off', ...
    'HitTest','off','PickableParts','none');hold(overlay,'on');
properties={'Position','XLim','YLim','ZLim','DataAspectRatio','PlotBoxAspectRatio', ...
    'CameraPosition','CameraTarget','CameraUpVector','CameraViewAngle','Projection'};
for k=1:numel(properties),overlay.(properties{k})=ax.(properties{k});end
cameraLink=linkprop([ax overlay],properties);
setappdata(fig,'G1OverlayCameraLink',cameraLink);
com=plot3(overlay,0,0,0,'o','MarkerFaceColor',[0 .65 .65],'MarkerSize',12, ...
    'MarkerEdgeColor','w','LineWidth',2);
comLeader=plot3(overlay,nan,nan,nan,'-','Color',[0 .45 .45],'LineWidth',1.5);
comLabel=text(overlay,0,0,0,'Whole-body COM','Color',[0 .4 .4], ...
    'FontWeight','bold','BackgroundColor','w','Margin',3,'Clipping','on');
push=quiver3(overlay,0,0,0,0,0,0,0,'Color',[.9 .12 .05],'LineWidth',3,'MaxHeadSize',.55);
% Filled cone gives a clear direction cue even when the view is rotated.
pushHead=patch(overlay,'Faces',[1 2 3],'Vertices',zeros(3,3), ...
    'FaceColor',[.9 .12 .05],'EdgeColor','none');
pushPoint=plot3(overlay,0,0,0,'o','MarkerSize',9,'MarkerFaceColor',[1 .4 .05],'MarkerEdgeColor','w');
pushLabel=text(overlay,0,0,0,'','Color',[.75 .08 .02],'FontWeight','bold', ...
    'BackgroundColor','w','Margin',3,'Clipping','on');
copMarker=plot3(overlay,nan,nan,0,'d','MarkerSize',11,'MarkerFaceColor',[.32 .18 .5],'MarkerEdgeColor','w','LineWidth',1.5);
copLabel=text(overlay,0,0,0,'COP','Color',[.32 .18 .5],'FontWeight','bold','BackgroundColor','w','Margin',3);
pendulum=plot3(overlay,nan,nan,nan,'--','Color',[0 .5 .5],'LineWidth',1.7);
footMarkers=plot3(overlay,nan,nan,nan,'s','MarkerSize',12,'MarkerFaceColor','none','MarkerEdgeColor',[.32 .18 .5],'LineWidth',2);
cameraMenu=uicontrol(fig,'Style','popupmenu','String',{'Follow COM','Global view'}, ...
    'Value',1,'Units','normalized','Position',[.04 .205 .23 .035],'Callback',@cameraChanged);
cameraReady=false;
outputAxes=axes(fig,'Position',[.56 .65 .39 .18]);hold(outputAxes,'on');grid(outputAxes,'on');
measured=plot(outputAxes,nan,nan,'-','Color',[.05 .49 .53],'LineWidth',1.8);pred=gobjects(1,2);
pred(1)=plot(outputAxes,nan,nan,'--','Color',[.32 .18 .5],'LineWidth',1.5);
pred(2)=plot(outputAxes,nan,nan,':','Color',[.5 .5 .5],'LineWidth',1.2);
legend(outputAxes,[measured pred],{'MuJoCo COM',sprintf('LIPM: %g s windows',p.windowDuration),'Measured COP'},'Location','northoutside','Orientation','horizontal','FontSize',8,'AutoUpdate','off');
if isfield(p,'evaluationMode')&&strcmp(p.evaluationMode,'single_rollout')
    legend(outputAxes,[measured pred],{'MuJoCo COM','Fitted LIPM','Measured COP'},'Location','northoutside','Orientation','horizontal','FontSize',8,'AutoUpdate','off');
end
cursor=xline(outputAxes,0);ylabel(outputAxes,'Forward position (m)');xlabel(outputAxes,'Time (s)');
errorAxes=axes(fig,'Position',[.56 .445 .39 .13]);hold(errorAxes,'on');grid(errorAxes,'on');
errorLine=plot(errorAxes,nan,nan,'Color',[.32 .18 .5],'LineWidth',1.6,'Tag','LIPMPositionError');
yline(errorAxes,0,':','Color',[.5 .5 .5],'HandleVisibility','off');
errorCursor=xline(errorAxes,0,'HandleVisibility','off');
resetDots=plot(errorAxes,nan,nan,'o','Color',[.05 .49 .53],'MarkerSize',4,'HandleVisibility','off');
ylabel(errorAxes,'COM error (mm)');xlabel(errorAxes,'Time (s)');
title(errorAxes,sprintf('LIPM - MuJoCo | %g s horizon / %g s resets',p.windowDuration,p.windowSpacing),'FontSize',9);
errorMessage=text(errorAxes,.5,.5,'Run run_project to add model predictions', ...
    'Units','normalized','HorizontalAlignment','center','Color',[.4 .4 .4],'FontSize',9);
forceAxes=axes(fig,'Position',[.56 .255 .39 .11]);grid(forceAxes,'on');forceLine=plot(forceAxes,nan,nan,'Color',[.85 .15 .1],'LineWidth',1.6);
if isfield(p,'evaluationMode')&&strcmp(p.evaluationMode,'single_rollout')
    title(errorAxes,sprintf('One forecast from %.1f s | tolerance %g mm',p.design.forecastStart_s,p.design.positionTolerance_mm),'FontSize',9);
    yline(errorAxes,p.design.positionTolerance_mm,'r:');yline(errorAxes,-p.design.positionTolerance_mm,'r:');
end
forceCursor=xline(forceAxes,0);grid(forceAxes,'on');ylabel(forceAxes,'Push force (N)');xlabel(forceAxes,'Time (s)');
status=uicontrol(fig,'Style','text','Units','normalized','Position',[.04 .14 .92 .06],'BackgroundColor','w','FontSize',11,'HorizontalAlignment','left');
uicontrol(fig,'Style','pushbutton','String','Play / pause','Units','normalized','Position',[.04 .075 .13 .04],'Callback',@toggle);
slider=uicontrol(fig,'Style','slider','Min',0,'Max',12,'Value',0,'Units','normalized','Position',[.21 .08 .73 .025],'Callback',@(s,~)seek(s.Value));
annotation(fig,'textbox',[.04 .015 .94 .035],'String', ...
    sprintf('Recorded motion. Teal = COM; purple diamond = COP. Predictions: %g s horizon; measured-state resets every %g s.',p.windowDuration,p.windowSpacing), ...
    'FontSize',9,'EdgeColor','none');
if isfield(p,'evaluationMode')&&strcmp(p.evaluationMode,'single_rollout')
    boxes=findall(fig,'Type','textboxshape');
    for b=boxes',if contains(string(b.String),'Predictions:'),b.String='Recorded body motion. The fitted LIPM initializes once at push onset; later COM measurements are for scoring only.';end;end
end
index=1;T=[];poses=[];playing=false;time=0;wall=tic;lastTarget=[0 0 0];
tm=timer('ExecutionMode','fixedSpacing','Period',.04,'BusyMode','drop','TimerFcn',@tick);
fig.CloseRequestFcn=@closeViewer;rotation=rotate3d(fig);setAllowAxesRotate(rotation,ax,true);
setAllowAxesRotate(rotation,outputAxes,false);setAllowAxesRotate(rotation,errorAxes,false);setAllowAxesRotate(rotation,forceAxes,false);rotation.Enable='on';
setAllowAxesRotate(rotation,overlay,false);
set(allchild(overlay),'HitTest','off','PickableParts','none');
setappdata(fig,'G1LIPMReplayControls',struct('seek',@seek,'menu',menu,'timer',tm,'axes',ax, ...
    'pushArrow',push,'pushHead',pushHead,'pushPoint',pushPoint,'pushLabel',pushLabel,'com',com,'overlay',overlay,'cop',copMarker,'camera',cameraMenu, ...
    'errorAxes',errorAxes,'errorLine',errorLine));
change();if ip.Results.AutoPlay,toggle();end
    function change(varargin)
        index=menu.Value;T=R.runs{index};id=R.manifest.ID(index);
        poses=readmatrix(fullfile(p.dataFolder,'replay',id+"_poses.csv"));
        measured.XData=T.Time_s;measured.YData=T.COMX_m;
        pred(1).XData=nan;pred(1).YData=nan;
        errorLine.XData=nan;errorLine.YData=nan;errorMessage.Visible='on';resetDots.XData=nan;resetDots.YData=nan;
        if isfield(R,'predictions')&&~isempty(R.predictions{index})
            pred(1).XData=T.Time_s;pred(1).YData=R.predictions{index}(:,1);
            errorLine.XData=T.Time_s;errorLine.YData=1000*(R.predictions{index}(:,1)-T.COMX_m);
            errorMessage.Visible='off';
            if isfield(R,'windows')&&~isempty(R.windows{index})
                resetDots.XData=R.windows{index}.Start_s;resetDots.YData=zeros(size(R.windows{index}.Start_s));
            end
        end
        pred(2).XData=T.Time_s;pred(2).YData=T.COPX_m;
        floorPatch.XData=[min(T.COMX_m)-1 max(T.COMX_m)+1 max(T.COMX_m)+1 min(T.COMX_m)-1];
        floorPatch.YData=[min(T.COMY_m)-.6 min(T.COMY_m)-.6 max(T.COMY_m)+.6 max(T.COMY_m)+.6];
        cameraReady=false;
        forceLine.XData=T.Time_s;forceLine.YData=T.PushForce_N;
        slider.Max=max(T.Time_s);xlim(outputAxes,[0 slider.Max]);xlim(errorAxes,[0 slider.Max]);
        errorAxes.YLimMode='auto';
        if isfield(p,'evaluationMode')&&strcmp(p.evaluationMode,'single_rollout')
            errorAxes.YLim=[-2 2]*p.design.positionTolerance_mm;
            span=max(T.COMX_m)-min(T.COMX_m);ylim(outputAxes,[min(T.COMX_m)-.1*max(span,.1) max(T.COMX_m)+.1*max(span,.1)]);
        end
        xlim(forceAxes,[0 slider.Max]);seek(0);
    end
    function seek(t)
        time=max(0,min(t,slider.Max));slider.Value=time;wall=tic;[~,sample]=min(abs(T.Time_s-time));
        B=reshape(poses(sample,2:end),7,[])';
        for k=1:numel(objects)
            M=model.geoms{k};b=M.body;q=B(b,4:7);Q=rotationMatrix(q);
            local=(M.transform*[M.vertices ones(size(M.vertices,1),1)]')';
            objects(k).Vertices=(Q*local(:,1:3)')'+B(b,1:3);
        end
        set(com,'XData',T.COMX_m(sample),'YData',T.COMY_m(sample),'ZData',T.COMZ_m(sample));
        center=[T.COMX_m(sample) T.COMY_m(sample) T.COMZ_m(sample)];
        labelPosition=center+[.20 0 -.10];
        set(comLeader,'XData',[center(1) labelPosition(1)], ...
            'YData',[center(2) labelPosition(2)],'ZData',[center(3) labelPosition(3)]);
        comLabel.Position=labelPosition;
        F=T.PushForce_N(sample);
        application=[T.PushPointX_m(sample) T.PushPointY_m(sample) T.PushPointHeight_m(sample)];
        active=abs(F)>1e-4;
        % Minimum visible length; arrow tip remains at the actual application point.
        arrowLength=sign(F)*min(.48,.22+.004*abs(F));
        set(push,'XData',application(1)-arrowLength,'YData',application(2),'ZData',application(3), ...
            'UData',arrowLength,'VData',0,'WData',0,'Visible',active);
        set(pushPoint,'XData',application(1),'YData',application(2),'ZData',application(3));
        % Cone ends just outside the application marker, so the marker cannot
        % cover the arrowhead. Its axis follows the signed world-X force.
        direction=sign(F);tip=application-[direction*.025 0 0];
        phi=(0:15)'*2*pi/16;
        ring=tip+[-direction*.085 0 0]+[zeros(16,1) .035*cos(phi) .035*sin(phi)];
        faces=[ones(16,1) (2:17)' [3:17 2]'];
        set(pushHead,'Faces',faces,'Vertices',[tip;ring],'Visible',active);
        if active
            label=sprintf('Push: %+.1f N',F);
        else
            label='Push location (0 N)';
        end
        set(pushLabel,'Position',application+[-arrowLength 0 .09],'String',label);
        cursor.Value=time;errorCursor.Value=time;forceCursor.Value=time;
        valid=logical(T.COPValid(sample));
        set([copMarker copLabel pendulum],'Visible',valid);
        if valid
            support=[T.COPX_m(sample) T.COPY_m(sample) .008];
            set(copMarker,'XData',support(1),'YData',support(2),'ZData',support(3));
            copLabel.Position=support+[.16 0 .04];
            set(pendulum,'XData',[support(1) center(1)],'YData',[support(2) center(2)],'ZData',[support(3) center(3)]);
        end
        feet=[T.LeftFootX_m(sample) T.LeftFootY_m(sample) T.LeftFootZ_m(sample); ...
              T.RightFootX_m(sample) T.RightFootY_m(sample) T.RightFootZ_m(sample)];
        feet=feet(logical([T.LeftContact(sample);T.RightContact(sample)]),:);
        set(footMarkers,'XData',feet(:,1),'YData',feet(:,2),'ZData',feet(:,3));
        if cameraMenu.Value==1
            target=center+[0 0 -.05];
            if cameraReady
                delta=target-lastTarget;cameraPosition=ax.CameraPosition+delta;cameraTarget=ax.CameraTarget+delta;
                xlim(ax,center(1)+[-.75 .75]);ylim(ax,center(2)+[-.5 .5]);
                ax.CameraPosition=cameraPosition;ax.CameraTarget=cameraTarget;
            else
                xlim(ax,center(1)+[-.75 .75]);ylim(ax,center(2)+[-.5 .5]);zlim(ax,[0 1.45]);
                view(ax,135,15);cameraReady=true;
            end
            lastTarget=target;
        elseif ~cameraReady
            xlim(ax,[min(T.COMX_m)-.7 max(T.COMX_m)+.7]);
            ylim(ax,[min(T.COMY_m)-.5 max(T.COMY_m)+.5]);zlim(ax,[0 1.45]);view(ax,135,15);cameraReady=true;
        end
        status.String=sprintf('%s | t %.2f s | COM speed %.2f m/s | push %+.1f N | COP valid %d | %s\nReplay is recorded MuJoCo motion. LIPM uses measured COP and cannot independently predict recovery or falls.', ...
            R.manifest.ID(index),time,T.COMVX_mps(sample),F,valid,R.manifest.Outcome(index));
        if T.Fallen(sample),status.ForegroundColor=[.8 .15 .1];else,status.ForegroundColor=[.15 .15 .15];end
        drawnow limitrate;
    end
    function cameraChanged(varargin),cameraReady=false;seek(time);end
    function tick(~,~),next=time+toc(wall);seek(next);if next>=slider.Max,playing=false;stop(tm);end;end
    function toggle(varargin),playing=~playing;if playing,if time>=slider.Max,seek(0);end;wall=tic;start(tm);else,stop(tm);end;end
    function closeViewer(~,~),stop(tm);delete(tm);delete(fig);end
end
function R=rotationMatrix(q)
w=q(1);x=q(2);y=q(3);z=q(4);
R=[1-2*(y*y+z*z),2*(x*y-z*w),2*(x*z+y*w); ...
    2*(x*y+z*w),1-2*(x*x+z*z),2*(y*z-x*w); ...
    2*(x*z-y*w),2*(y*z+x*w),1-2*(x*x+y*y)];
end
