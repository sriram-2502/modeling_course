%% Simple fitted-LIPM project settings. Edit horizons and accuracy criterion here.
design.trainingIDs=["S1","W1"]; % Fit once per condition; do not fit validation runs.
design.coefficientBounds=[.5 40]; % Positive effective coefficient a, s^-2.
design.fitDuration_s=1.6;         % Fixed training interval; independent of test horizon.
design.forecastStart_s=2;         % One initialization, at push onset.
design.horizons_s=[.1 .2 .4 .8 1.6 3.2];
design.positionTolerance_mm=10;  % Illustrative model-usefulness criterion, NOT a grade.
