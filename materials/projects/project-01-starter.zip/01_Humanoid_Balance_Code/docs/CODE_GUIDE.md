# Code guide: one fitted LIPM, two operating conditions

## First observe the reference

`replay_data` works before any student function is completed. Choose standing
S0-S4 or walking W0-W4; play, pause, scrub, or rotate the scene. Teal marks
whole-body COM; the purple ground diamond is combined COP; outlined squares
show supporting feet; the red foreground arrow shows the applied push.
Body motion is recorded MuJoCo motion, not a reconstruction from your model.
After fitting, the displayed predicted COM is your model output. Your model
does not generate body poses, joint angles, footstep locations, or a new gait.
A convincing full-body replay therefore does not itself validate your LIPM.

## Your model and parameter

Use xddot = a*(x-p) + F/m, with state [x;v] and input [p;F]. World X is forward,
world Z is upward, and ground is z=0. Positions use m, velocity m/s and force N.
Mass m is supplied (32.1069 kg). Fit positive coefficient a in s^-2; it ideally
equals g/h, but the estimate is an EFFECTIVE model coefficient. g/a is an
equivalent height, not an identified physical COM height, mass or inertia.

With COP held fixed and no push, the model has one unstable mode. The full
robot can nevertheless balance because its supplied controller changes contact
forces and support/COP. Your model receives that controlled COP history as an
input; it does not reproduce the controller. A positive model pole is therefore
not evidence that the recorded robot must fall. A larger a means stronger
acceleration for the same COM�COP separation and faster unstable-mode growth
with fixed support; it is not itself a balance-quality score.

Standing and walking use the same equation but have separate fitted a values.
Use only S1 (10 N standing) and W1 (10 N walking) for identification. Freeze
both fits before testing other push levels. Never fit a new a for each horizon.

## What you implement

| File / model | Your work | Related task |
|---|---|---|
| `+student/model_matrices.m` | Derive A and B for zdot=A*z+B*[p;F]. | 1b, reused in 2b |
| `+student/fit_lipm.m` | Fit one positive a from the supplied training table. | 1b / 2b |
| `models/g1_student_lipm.slx` | Build the Dynamics subsystem using gains, a sum and two integrators. | 1b, reused in 2b |

The fitting objective `provided.training_loss(a,training,m)` is supplied. It
uses YOUR matrices to simulate one continuous training interval from 2.0 to
3.6 s and returns position MSE. It initializes only once, not at each sample.
Base MATLAB `fminbnd` is one suitable parameter-search tool. Reference bounds
are in `fit_setup.m`: 0.5 to 40 s^-2. These are suggested starting bounds,
not mandatory physical limits. You may change them with justification.
Report an estimate at a bound and discuss whether the range constrained the fit.
`fit_lipm` must read or explicitly use your chosen bounds; changing the setting
alone does not automatically alter a search you have hard-coded.
No numerical differentiation of position is necessary.

Open the Simulink model and enter Dynamics. Remove `Replace with your LIPM`
and the unused-input terminators. Input 1 is COP p, input 2 is push F.
Implement acceleration a*(x-p)+F/m and integrate to v, then x.
Use model-workspace variables `a`, `m`, `initialX`, and `initialV`.
Set the first (acceleration-to-velocity) integrator initial condition to
`initialV`; set the second (velocity-to-position) integrator to `initialX`. Output a
two-element vector **[x;v]**. Retain the two supplied From Workspace sources
(`copInput`, `forceInput`) and the Timeseries logger named `states`.

`+student/simulate_forecast.m` is a completed interface wrapper; you do not
need to change it. The provided runner executes YOUR Simulink diagram for
the evaluation, rather than replacing it with instructor dynamics.

## First successful run: build and debug in this order

1. Run `check_setup` and `replay_data` from the extracted project folder.
2. Complete `student.model_matrices(m,a)`. With a trial positive coefficient,
   check that A and B are finite 2-by-2 matrices. Check units and input order [COP;F].
3. Try your matrices on one training case before implementing the optimizer:

   ```matlab
   R = provided.load_data;
   k = find(R.manifest.ID == "S1", 1);
   T = R.runs{k};
   m = R.metadata{k}.Mass_kg;
   trialA = 14; % A trial coefficient, not an identified answer.
   loss = provided.training_loss(trialA,T,m)
   ```

   A finite nonnegative loss confirms that the fitting objective can execute;
   it does not establish that your matrices are physically correct.
4. Complete `student.fit_lipm`, then build and SAVE the Simulink Dynamics subsystem.
   Keep the supplied solver settings and output order [x;v].
5. Run `run_project`. It fits S1/W1, verifies both matrix/Simulink implementations,
   then evaluates all cases. Resolve verification failures before interpreting results.
6. Review the saved metrics and plots; use `animate_results` for replay.

**Running the model:** clicking Run directly in the scaffold uses its saved
zero-input demonstration values. It is not a recorded-data experiment.
`run_project` supplies the actual COP, push, fitted coefficient, mass, and
measured initial states automatically for each case. Do not manually copy
all CSVs into the Simulink workspace. Remove the placeholder block and save
before evaluation; otherwise a `BuildModel` message is expected.

**Keep the protocol fixed:** training cases S1/W1, training interval 2.0�3.6 s,
push-onset initialization at 2.0 s, unchanged reference data, and no later
COM-state resets. Student choices are the fitting method and justified search
bounds, prediction horizons, and accuracy tolerance. Use the same tolerance
when comparing conditions and push levels.

## What is already completed

- CSV loading, paths, metadata and base-MATLAB replay.
- Generic propagation for calibration using your derived state matrices.
- A training-loss objective and the Simulink input/logging wrapper.
- A matrix-versus-Simulink numerical check.
- Training/validation separation, one-shot forecast evaluation, error metrics,
  horizon/force plots and saved-result animation.

The model equations are not filled into the scaffold or the student matrices.
An initial TODO or BuildModel message is expected until you complete them.

## How run_project evaluates your result

1. Fit standing on S1 and walking on W1, once each. Training duration is fixed
   at 1.6 s, independent of the horizons you later test.
2. Check your matrix simulation and Simulink diagram on identical inputs over
   the first 0.2 s after push onset. The supplied checker requires maximum absolute
   differences below 1e-5 m for position and 1e-5 m/s for velocity. These are
   implementation tolerances, not model-versus-robot accuracy criteria.
   If the check fails, inspect signs, initial states, input interpolation, output
   ordering [x;v], and solver settings before interpreting validation errors.
3. Initialize each case once at t=2.0 s, just before the push. Use measured
   COM position and velocity as the initial state. Supply measured COP and
   known push during the forecast. Later COM measurements are used only to score.
4. Run continuously to the largest chosen horizon or the first invalid
   reference COP/fall flag, whichever occurs first. There are no reset windows
   or intentional gaps in this evaluation.
5. Evaluate lead times in `fit_setup.m`: by default 0.1, 0.2, 0.4, 0.8, 1.6,
   and 3.2 s. Lead time means time since the forecast began, not absolute time.

�Useful� means peak absolute COM position error **up to** that horizon stays
within your stated tolerance. Checking only the final error could hide an
earlier large error. The supplied example tolerance is 10 mm; justify a
criterion and discuss how it affects the usable horizon. For example:
"We accept up to 10 mm (1 cm) forward COM prediction error for this study."
Relate that choice to the intended prediction use; it is not a safety standard.
Repeat the comparison with one tighter or looser tolerance, such as 5 or 20 mm,
using `design.positionTolerance_mm` in `fit_setup.m`. State whether conclusions
change. This tolerance is not a grade.

The accuracy-loss time is the first sampled lead time where error exceeds
the tolerance. Sample spacing is 0.02 s, so this is not an exact continuous
crossing time. It is not a robot-fall time. If no crossing is observed, write
"no crossing within the validated interval" and give that duration.
`AccuracyLossLead_s = NaN` means no crossing was observed; inspect
`AvailableLead_s` and the horizon statuses to see how much was actually validated.
It does not mean infinite prediction accuracy. `LargestUsefulTestedHorizon_s = 0`
means none of the requested horizons was validated within tolerance, not
necessarily that error was already too large at initialization. If the reference stops or COP becomes
invalid before a requested horizon, that horizon is **Unvalidated**, not a pass.

Future COP is supplied from logs. This is conditional COM prediction given
support motion; an online forecast would additionally need future COP or a
support/foot-placement model. The task does not ask you to design that model.

## Files to use in your report

- `fitted_parameters.csv`: training case, fitted a, equivalent height, training RMSE.
- `simulink_verification.csv`: differences between your matrices and your block diagram.
- `case_metrics.csv`: first accuracy-loss time, available reference length and
  largest tested useful horizon for each condition/force.
- `horizon_metrics.csv`: peak error, RMSE, endpoint error and validation status
  for each horizon and force level.
- Per-case prediction CSVs, `training_fit.png`, `validation_predictions.png`,
  `horizon_disturbance.png`, and `student_results.mat`.

Use S2/W2 (30 N) and the stronger cases as validation, not additional fitting
data. S0/W0 reveal nominal behavior. 100/500 N cases can lose support or fall
before long horizons can be assessed. A reference outcome and model accuracy
are separate pieces of evidence. Fixed baseline phase, one trial per level,
and ideal simulated measurements limit generalization.

To skip animation, set `showAnimation=false` before `run_project`.
Close a replay window to release its timer. Never replace invalid COP by zero.
The positive pole sqrt(a) explains possible error growth; successful controlled
walking does not make the open-loop pendulum intrinsically stable.
