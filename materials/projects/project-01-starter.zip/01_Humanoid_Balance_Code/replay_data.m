%% Start here: recorded MuJoCo poses and data; no completed model needed.
folder=fileparts(mfilename('fullpath'));addpath(folder);reference=provided.load_data;replayFigure=provided.viewer(reference);
