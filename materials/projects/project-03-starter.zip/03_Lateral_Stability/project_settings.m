function settings=project_settings
% Justify the same small-slip interval for every axle and tire.
settings.fitInterval=[-.02 .02]; % radians
end
