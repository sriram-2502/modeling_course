Generated outputs belong here. No solved logs or fitted parameters are distributed.
Run the completed main script before animate_results.m.
