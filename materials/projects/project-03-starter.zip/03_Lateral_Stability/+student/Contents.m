% Complete: fit_linear, fit_nonlinear, nonlinear_force, linear_matrix,
% build_model (and the SLX), and recommend. Supplied evaluation is in +provided.
