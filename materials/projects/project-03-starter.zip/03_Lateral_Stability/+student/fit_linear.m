function slopes=fit_linear(data,interval)
% Return positive 3-by-2 axle stiffnesses [front rear], N/rad.
% Fit each CSV column through zero over the common interval (radians).
slopes=nan(3,2);
error('student:Todo','Complete +student/fit_linear.m');
end
