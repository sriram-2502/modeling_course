function parameters=fit_nonlinear(data)
% Fit the handout simplified Magic Formula using fminsearch (base MATLAB).
% Return finite 3-by-2-by-4 array: tire, axle (F/R), [B C D E].
% Use B>0, 1<C<2, D>0, -1<E<1; transform unconstrained optimizer variables.
% Normalize residuals and try several starts; no toolbox fitter is required.
parameters=nan(3,2,4);
error('student:Todo','Complete +student/fit_nonlinear.m');
end
