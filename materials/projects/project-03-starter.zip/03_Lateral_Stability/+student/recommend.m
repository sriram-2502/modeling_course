function choice=recommend(metrics,p)
% Choose one tire package for both cases using ONLY Model==reference rows.
% Explain intended speeds, disturbances, recovery tradeoff and model limits.
% This is an engineering argument: no unique required minimizer.
choice=struct('tire',NaN,'reason',"");
error('student:Todo','Complete +student/recommend.m');
end
