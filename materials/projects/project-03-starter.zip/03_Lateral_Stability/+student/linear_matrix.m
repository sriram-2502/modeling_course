function A=linear_matrix(p,U,Cf,Cr)
% Derive the 2-by-2 A matrix from your ODEs for x=[vy;r], delta=0.
% Cf and Cr are complete axle stiffnesses, N/rad. U is m/s.
A=nan(2);
error('student:Todo','Complete +student/linear_matrix.m');
end
