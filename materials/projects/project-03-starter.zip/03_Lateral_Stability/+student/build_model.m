function path=build_model(p)
% Complete models/lateral_student.slx using sums, gains, two integrators,
% and supplied force-table inputs; derive your equations independently.
% See docs/code_guide.pdf for variable names and stopping/logging contract.
% Use the Lec15 vehicle model on Canvas as a reference, adapted to tire laws.
path=fullfile(p.modelDir,'lateral_student.slx');
error('student:Todo','Complete +student/build_model.m');
end
