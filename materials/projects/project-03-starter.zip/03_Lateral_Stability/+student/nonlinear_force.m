function force=nonlinear_force(alpha,theta)
% Evaluate the supplied formula, theta=[B C D E]. Alpha is in radians.
% Return finite N in exactly the input shape; support vector inputs.
force=nan(size(alpha));
error('student:Todo','Complete +student/nonlinear_force.m');
end
