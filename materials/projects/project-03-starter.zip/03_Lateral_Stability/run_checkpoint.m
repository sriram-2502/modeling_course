function output=run_checkpoint(stage)
folder=fileparts(mfilename('fullpath'));addpath(folder);p=provided.load_project(folder);
api=struct('fit_linear',@student.fit_linear,'nonlinear_force',@student.nonlinear_force, ...
 'linear_matrix',@student.linear_matrix,'build_model',@student.build_model);
fits.slopes=student.fit_linear(p.table,p.fitInterval);output=fits;
switch string(stage)
 case "linear_fit",disp(fits.slopes);
 case "fits"
  fits.parameters=student.fit_nonlinear(p.table);output=fits;disp(size(fits.parameters));
 case "simulink"
  path=student.build_model(p);load_system(path);[~,model]=fileparts(path);
  cleanup=onCleanup(@() close_system(model,0));output=provided.verify_linear(p,model,fits,api);
 otherwise,error('checkpoint:Stage','Choose linear_fit, fits, or simulink.');
end
end
