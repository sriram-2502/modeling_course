folder=fileparts(mfilename('fullpath'));addpath(folder);p=provided.load_project(folder);
assert(exist('Simulink.SimulationInput','class')==8,'MATLAB and Simulink are required.');
assert(isfile(fullfile(p.modelDir,'lateral_student.slx')),'Extract the complete starter folder.');
assert(max(abs(p.table{501,2:end}))<1e-5,'Reference must have zero force at zero slip.');
fprintf('Setup OK. Six student functions plus the unfinished Simulink plant remain to complete.\n');
