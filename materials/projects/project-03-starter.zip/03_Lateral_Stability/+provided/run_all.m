function results=run_all(p,api)
fits.slopes=api.fit_linear(p.table,p.fitInterval);fits.parameters=api.fit_nonlinear(p.table);
assert(isequal(size(fits.slopes),[3 2]) && all(fits.slopes>0,'all'));
assert(isequal(size(fits.parameters),[3 2 4]) && all(isfinite(fits.parameters),'all'));
assert(all(fits.parameters(:,:,1)>0,'all') && all(fits.parameters(:,:,2)>1 & fits.parameters(:,:,2)<2,'all') && ...
 all(fits.parameters(:,:,3)>0,'all') && all(abs(fits.parameters(:,:,4))<1,'all'),'Nonlinear parameters violate the handout bounds.');
modelPath=api.build_model(p);load_system(modelPath);[~,model]=fileparts(modelPath);
cleanup=onCleanup(@() close_system(model,0));
verification=provided.verify_linear(p,model,fits,api);
rows=struct([]);responses={}; trims={}; modes=["linear","nonlinear","reference"];
for tire=1:3
 for test=1:2
  for U=p.speeds{test}
   if test==1,radius=Inf;else,radius=p.radius;end
   nominal=provided.trim_turn(p,U,radius,p.front(:,tire),p.rear(:,tire));
   for mode=modes
    [front,rear]=provided.force_tables(p,fits,tire,mode,api);
    own=provided.trim_turn(p,U,radius,front,rear);
    maxReal=NaN;
    if own.exists,A=provided.local_matrix(p,U,front,rear,own,api);maxReal=max(real(eig(A)));end
    for amplitude=1:2
     r=provided.simulate_case(p,model,front,rear,U,nominal,p.disturbances(amplitude,:));
     metric=provided.evaluate_case(r,nominal,p);
     row=struct('Tire',tire,'Test',test,'Speed_mps',U,'Model',mode,'Disturbance',amplitude, ...
      'TrimExists',nominal.exists,'ModelTrimExists',own.exists,'MaxRealEigenvalue',maxReal, ...
      'Completed',r.completed,'PeakSlip_deg',metric.PeakSlip_deg,'FinalError',metric.FinalError, ...
      'Recovered',metric.Recovered,'Status',metric.Status);
     rows=[rows;row];responses{end+1}=r;trims{end+1}=own; %#ok<AGROW>
    end
   end
  end
 end
 fprintf('Finished T%d across both driving cases.\n',tire);
end
metrics=struct2table(rows);validation=provided.compare_models(metrics,responses,trims,p);
choice=api.recommend(metrics,p);
assert(isfield(choice,'tire') && ismember(choice.tire,1:3) && strlength(string(choice.reason))>0);
% Force errors use identical alpha samples for both fitted laws.
errors=struct([]);
for tire=1:3
 for mode=modes(1:2)
  [f,r]=provided.force_tables(p,fits,tire,mode,api);
  errors=[errors;struct('Tire',tire,'Model',mode,'FrontRMSE_N',sqrt(mean((f-p.front(:,tire)).^2)), ...
   'RearRMSE_N',sqrt(mean((r-p.rear(:,tire)).^2)))]; %#ok<AGROW>
 end
end
% Straight-driving speed sweep is independent of the finite simulation window.
stability=struct([]);
for tire=1:3
 for U=5:.5:45
  A=api.linear_matrix(p,U,fits.slopes(tire,1),fits.slopes(tire,2));
  stability=[stability;struct('Tire',tire,'Speed_mps',U,'MaxRealEigenvalue',max(real(eig(A))))]; %#ok<AGROW>
 end
end
results=struct('parameters',p,'fits',fits,'verification',verification,'metrics',metrics, ...
 'forceErrors',struct2table(errors),'stability',struct2table(stability),'validation',validation, ...
 'responses',{responses},'modelTrims',{trims},'choice',choice);
writetable(metrics,fullfile(p.outputDir,'case_metrics.csv'));
writetable(results.forceErrors,fullfile(p.outputDir,'force_errors.csv'));
writetable(validation,fullfile(p.outputDir,'model_errors.csv'));
writetable(results.stability,fullfile(p.outputDir,'speed_stability.csv'));
provided.plot_results(results);
save(fullfile(p.outputDir,'project_results.mat'),'results');
fprintf('Recommended T%d: %s\n',choice.tire,choice.reason);
end
