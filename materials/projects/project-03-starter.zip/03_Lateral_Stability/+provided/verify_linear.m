function verification=verify_linear(p,model,fits,api)
U=15;C=fits.slopes(1,:);A=api.linear_matrix(p,U,C(1),C(2));
assert(isequal(size(A),[2 2]) && all(isfinite(A),'all'));
trim=struct('exists',true,'state',[0;0],'steering',0,'alpha',[0 0],'reason',"");
[front,rear]=provided.force_tables(p,fits,1,"linear",api);
r=provided.simulate_case(p,model,front,rear,U,trim,p.disturbances(1,:));
exact=zeros(size(r.states));for k=1:numel(r.t),exact(k,:)=(expm(A*r.t(k))*p.disturbances(1,:)')';end
verification=table(max(abs(r.states-exact),[],1)', ...
 'VariableNames',{'MaxAbsoluteError'},'RowNames',{'vy_mps','r_radps'});
writetable(verification,fullfile(p.outputDir,'linear_verification.csv'),'WriteRowNames',true);

t=r.t;simulinkStates=r.states;matrixStates=exact;
save(fullfile(p.outputDir,'linear_verification.mat'),'t','simulinkStates','matrixStates','A');
f=figure('Visible','off','Units','inches','Position',[1 1 6.5 4]);tiledlayout(2,1);
for j=1:2
 nexttile;plot(t,simulinkStates(:,j),t,matrixStates(:,j),'--');grid on;
 if j==1,ylabel('v_y (m/s)');else,ylabel('r (rad/s)');xlabel('Time (s)');end
end
legend({'Simulink','Matrix exponential'},'Location','best');
exportgraphics(f,fullfile(p.outputDir,'linear_verification.pdf'));close(f);

assert(all(verification.MaxAbsoluteError<1e-5),'Linear Simulink and matrix solution disagree.');
end
