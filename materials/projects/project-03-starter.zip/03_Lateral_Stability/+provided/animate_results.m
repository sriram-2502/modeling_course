function fig=animate_results(results,options)
% Supplied saved-log viewer. Does not solve vehicle or tire dynamics.
if nargin<2,options=struct;end
if ~isfield(options,'Visible'),options.Visible='on';end
if ~isfield(options,'AutoPlay'),options.AutoPlay=true;end
p=results.parameters;M=results.metrics;
fig=figure('Name','Lateral stability | saved-results playback','NumberTitle','off', ...
 'Color','w','Position',[90 70 1250 760],'Visible',options.Visible);
caseMenu=menu([.02 .94 .15 .04],{'A: straight','B: cornering'},1,@changeCase);
tireMenu=menu([.18 .94 .15 .04],p.names,results.choice.tire,@changeCase);
modelMenu=menu([.34 .94 .15 .04],{'CSV reference','Linear fit','Nonlinear fit'},1,@changeCase);
speedMenu=menu([.50 .94 .12 .04],{'15 m/s','27 m/s','33 m/s'},2,@changeCase);
ampMenu=menu([.63 .94 .12 .04],{'Small disturbance','Larger disturbance'},1,@changeCase);
cameraMenu=menu([.76 .94 .13 .04],{'Follow car','Global'},1,@renderFrame);
play=uicontrol(fig,'Style','pushbutton','Units','normalized','Position',[.90 .94 .08 .04], ...
 'String','Play','Callback',@toggle);
status=uicontrol(fig,'Style','text','Units','normalized','Position',[.02 .85 .96 .07], ...
 'BackgroundColor','w','HorizontalAlignment','left','FontSize',10);
world=axes(fig,'Position',[.06 .18 .52 .62]);
phase=axes(fig,'Position',[.68 .51 .28 .28]);
history=axes(fig,'Position',[.68 .16 .28 .25]);
seek=uicontrol(fig,'Style','slider','Units','normalized','Position',[.07 .05 .75 .03], ...
 'Min',0,'Max',1,'Value',0,'Callback',@scrub);
rate=menu([.84 .045 .12 .04],{'0.25x','0.5x','1x','2x','4x'},3,[]);
caseMenu.Tag='AnimationCase';tireMenu.Tag='AnimationTire';modelMenu.Tag='AnimationModel';
speedMenu.Tag='AnimationSpeed';ampMenu.Tag='AnimationDisturbance';cameraMenu.Tag='AnimationCamera';
play.Tag='AnimationPlay';seek.Tag='AnimationTime';
playing=false;clock=tic;lastTick=0;time=0;response=[];duration=1;ready=false;
introElapsed=0;introDuration=1.4;disturbanceCue=[];
car=[];trail=[];historyDot=[];phaseDot=[];curves=[];
playTimer=timer('ExecutionMode','fixedSpacing','Period',.033,'BusyMode','drop','TimerFcn',@tick);
setappdata(fig,'PlaybackTimer',playTimer);fig.CloseRequestFcn=@closeViewer;
loadCase();if options.AutoPlay && ready,toggle();end
 function h=menu(pos,strings,value,callback)
  h=uicontrol(fig,'Style','popupmenu','Units','normalized','Position',pos, ...
   'String',strings,'Value',value,'Callback',callback);
 end
 function loadCase()
  ready=false;test=caseMenu.Value;
  speedMenu.String=arrayfun(@(x)sprintf('%g m/s',x),p.speeds{test},'UniformOutput',false);
  speedMenu.Value=min(speedMenu.Value,numel(p.speeds{test}));
  modes=["reference","linear","nonlinear"];U=p.speeds{test}(speedMenu.Value);
  k=find(M.Tire==tireMenu.Value & M.Test==test & M.Model==modes(modelMenu.Value) & ...
    M.Speed_mps==U & M.Disturbance==ampMenu.Value,1);
  response=results.responses{k};time=0;seek.Value=0;introElapsed=0;
  cla(world,'reset');cla(phase,'reset');cla(history,'reset');
  if isempty(response.t)
   status.String=sprintf('No operating point: %s',response.reason);play.Enable='off';seek.Enable='off';return;
  end
  ready=true;play.Enable='on';seek.Enable='on';duration=response.t(end);
  t=response.t;pose=response.pose;trim=response.trim;psi=trim.state(2)*t;
  if abs(trim.state(2))<1e-10,nominal=[U*t,trim.state(1)*t];
  else,r=trim.state(2);nominal=[(U*sin(psi)+trim.state(1)*(cos(psi)-1))/r, ...
    (U*(1-cos(psi))+trim.state(1)*sin(psi))/r];end
  hold(world,'on');grid(world,'on');axis(world,'equal');
  plot(world,nominal(:,1),nominal(:,2),'k:','LineWidth',1.5);
  for offset=[-1.8 1.8]
   plot(world,nominal(:,1)-offset*sin(psi),nominal(:,2)+offset*cos(psi),'Color',[.7 .7 .7]);
  end
  plot(world,pose(:,1),pose(:,2),'Color',[.8 .85 .95]);
  trail=plot(world,nan,nan,'Color',[.1 .4 .8],'LineWidth',1.5);
  car.body=patch(world,nan,nan,[.2 .55 .95],'EdgeColor','k');
  for j=1:4,car.wheels(j)=patch(world,nan,nan,[.2 .2 .2]);end
  disturbanceCue.push=quiver(world,0,0,0,0,0,'Color',[.9 .15 .05], ...
   'LineWidth',3,'MaxHeadSize',.7,'Tag','InitialLateralKick');
  disturbanceCue.arc=plot(world,nan,nan,'Color',[.9 .15 .05], ...
   'LineWidth',2.5,'Tag','InitialYawKick');
  disturbanceCue.arrow=quiver(world,0,0,0,0,0,'Color',[.9 .15 .05], ...
   'LineWidth',2.5,'MaxHeadSize',1);
  disturbanceCue.label=text(world,.02,.97,'','Units','normalized', ...
   'VerticalAlignment','top','Color',[.7 .1 .03],'BackgroundColor','w', ...
   'FontSize',10,'Interpreter','none','Tag','InitialKickLabel');
  xlabel(world,'World X (m)');ylabel(world,'World Y (m)');title(world,'Vehicle motion and nominal path');
  curves=[pose(:,1:2);nominal];
  hold(phase,'on');grid(phase,'on');plot(phase,response.states(:,1),response.states(:,2));
  plot(phase,trim.state(1),trim.state(2),'kx','MarkerSize',10);
  phaseDot=plot(phase,nan,nan,'ro','MarkerFaceColor','r');xlabel(phase,'v_y (m/s)');ylabel(phase,'r (rad/s)');
  title(phase,'Phase trajectory (x marks trim)');
  hold(history,'on');grid(history,'on');plot(history,t,response.states(:,2));
  yline(history,trim.state(2),'k:');historyDot=plot(history,0,response.states(1,2),'ro','MarkerFaceColor','r');
  xlabel(history,'Time (s)');ylabel(history,'Yaw rate (rad/s)');
  status.String=sprintf('T%d | %s | U %.1f m/s | steering %.2f deg | local max Re(lambda) %.3f /s\n%s | full-test recovery: %s | saved-log playback; follow view is 36 m wide', ...
   tireMenu.Value,modes(modelMenu.Value),U,trim.steering*180/pi,M.MaxRealEigenvalue(k), ...
   M.Status(k),string(M.Recovered(k)));
  renderFrame();lastTick=toc(clock);
 end
 function renderFrame(varargin)
  if ~ready,return;end
  state=interp1(response.t,response.states,time);pose=interp1(response.t,response.pose,time);
  updatePatch(car.body,pose(1:2),pose(3),4.4,1.8);
  wheels=[p.a -.85;p.a .85;-p.b -.85;-p.b .85];R=[cos(pose(3)) -sin(pose(3));sin(pose(3)) cos(pose(3))];
  for j=1:4
   point=pose(1:2)+(R*wheels(j,:)')';angle=pose(3)+(j<=2)*response.trim.steering;
   updatePatch(car.wheels(j),point,angle,.8,.22);
  end
  use=response.t<=time;trail.XData=response.pose(use,1);trail.YData=response.pose(use,2);
  set(phaseDot,'XData',state(1),'YData',state(2));set(historyDot,'XData',time,'YData',state(2));
  if cameraMenu.Value==1,xlim(world,pose(1)+[-18 18]);ylim(world,pose(2)+[-18 18]);
  else,xlim(world,[min(curves(:,1))-6 max(curves(:,1))+6]);ylim(world,[min(curves(:,2))-6 max(curves(:,2))+6]);end
  renderDisturbance(pose,R);
  seek.Value=time/duration;drawnow limitrate;
 end
 function renderDisturbance(pose,R)
  handles=[disturbanceCue.push disturbanceCue.arc disturbanceCue.arrow disturbanceCue.label];
  if time>0 || introElapsed>=introDuration
   set(handles,'Visible','off');car.body.EdgeColor='k';return;
  end
  set(handles,'Visible','on');
  kick=p.disturbances(ampMenu.Value,:);
  pulse=.65+.35*sin(pi*introElapsed/introDuration);
  lateralSign=sign(kick(1));yawSign=sign(kick(2));
  if lateralSign==0,lateralSign=1;end
  if yawSign==0,yawSign=1;end
  length=3*pulse*(1+.4*(ampMenu.Value-1));
  tail=pose(1:2)+(R*[0;-lateralSign*(1+length)])';
  vector=(R*[0;lateralSign*length])';
  set(disturbanceCue.push,'XData',tail(1),'YData',tail(2),'UData',vector(1),'VData',vector(2));
  theta=linspace(-pi/3,-pi/3+yawSign*(pi/3+pi/3*pulse),40);
  arc=[3.4*cos(theta);3.4*sin(theta)];arc=R*arc+pose(1:2)';
  set(disturbanceCue.arc,'XData',arc(1,:),'YData',arc(2,:));
  tangent=R*(yawSign*[-sin(theta(end));cos(theta(end))]);
  set(disturbanceCue.arrow,'XData',arc(1,end),'YData',arc(2,end), ...
   'UData',.8*tangent(1),'VData',.8*tangent(2));
  disturbanceCue.label.String=sprintf(['Initial-state kick (illustration)\n' ...
   'Delta v_y = %+.3f m/s; Delta r = %+.3f rad/s\n' ...
   't = 0 held briefly, then the saved response plays'],kick(1),kick(2));
  car.body.EdgeColor=[.9 .15 .05];
 end
 function tick(varargin)
  now=toc(clock);elapsed=now-lastTick;lastTick=now;
  if introElapsed<introDuration
   consumed=min(elapsed,introDuration-introElapsed);introElapsed=introElapsed+consumed;elapsed=elapsed-consumed;
  end
  speeds=[.25 .5 1 2 4];time=min(duration,time+elapsed*speeds(rate.Value));
  renderFrame();if time>=duration,pausePlayback();end
 end
 function pausePlayback(),stop(playTimer);playing=false;play.String='Play';end
 function toggle(varargin)
  if ~ready,return;end
  if playing,pausePlayback();return;end
  if time>=duration,time=0;introElapsed=0;end
  playing=true;play.String='Pause';lastTick=toc(clock);start(playTimer);
 end
 function scrub(varargin)
  if ready
   time=seek.Value*duration;
   if time==0,introElapsed=0;else,introElapsed=introDuration;end
   lastTick=toc(clock);renderFrame();
  end
 end
 function changeCase(varargin)
  resume=playing;pausePlayback();loadCase();if resume && ready,toggle();end
 end
 function closeViewer(varargin),stop(playTimer);delete(playTimer);delete(fig);end
end
function updatePatch(h,point,angle,length,width)
xy=[-length/2 -width/2;length/2 -width/2;length/2 width/2;-length/2 width/2];
R=[cos(angle) -sin(angle);sin(angle) cos(angle)];xy=xy*R'+point;
set(h,'XData',xy(:,1),'YData',xy(:,2));
end
