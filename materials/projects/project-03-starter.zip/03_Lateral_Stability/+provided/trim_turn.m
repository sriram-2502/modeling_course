function trim=trim_turn(p,U,radius,front,rear)
% Supplied inverse-force helper. Force/moment balances are explained in the guide.
trim=struct('exists',true,'state',[0;0],'steering',0,'alpha',[0 0],'reason',"");
if isinf(radius),return;end
force=p.m*U^2/radius*[p.b p.a]/(p.a+p.b);alpha=zeros(1,2);
for j=1:2
 if j==1,f=front;else,f=rear;end
 use=p.alpha>=0; a=p.alpha(use);f=f(use);[peak,index]=max(f);a=a(1:index);f=f(1:index);
 if force(j)>peak || any(diff(f)<=0)
  trim.exists=false;trim.reason="Required force exceeds the usable pre-peak tire curve.";return;
 end
 alpha(j)=interp1(f,a,force(j),'linear');
end
r=U/radius;vy=p.b*r-U*alpha(2);delta=alpha(1)+(vy+p.a*r)/U;
trim.state=[vy;r];trim.steering=delta;trim.alpha=alpha;
if abs(vy/U)>p.betaLimit || max(abs(alpha))>=p.alphaLimit
 trim.exists=false;trim.reason="Trim exceeds the assignment small-angle validity limits.";
end
end
