function tableOut=compare_models(metrics,responses,trims,p) %#ok<INUSD>
rows=struct([]);
for k=1:height(metrics)
 row=metrics(k,:);if row.Model=="reference",continue;end
 j=find(metrics.Tire==row.Tire & metrics.Test==row.Test & metrics.Speed_mps==row.Speed_mps & ...
  metrics.Disturbance==row.Disturbance & metrics.Model=="reference",1);
 a=responses{k};b=responses{j};both=a.completed && b.completed;
 ev=NaN;er=NaN;delta=NaN;
 if both
  x=interp1(a.t,a.states,b.t);err=x-b.states;
  ev=sqrt(trapz(b.t,err(:,1).^2)/(b.t(end)-b.t(1)));
  er=sqrt(trapz(b.t,err(:,2).^2)/(b.t(end)-b.t(1)));
 end
 if trims{k}.exists && ~isempty(b.t),delta=(trims{k}.steering-b.trim.steering)*180/pi;end
 r=struct('Tire',row.Tire,'Test',row.Test,'Speed_mps',row.Speed_mps,'Model',row.Model, ...
  'Disturbance',row.Disturbance,'BothCompleted',both,'VyErrorRMS_mps',ev, ...
  'YawErrorRMS_radps',er,'OwnTrimSteeringDifference_deg',delta);
 rows=[rows;r]; %#ok<AGROW>
end
tableOut=struct2table(rows);
end
