function plot_results(results)
p=results.parameters;colors=lines(3);
f=figure('Visible','off','Units','inches','Position',[1 1 7 4.4]);tiledlayout(2,3);
for k=1:3
 for j=1:2
  nexttile((j-1)*3+k);col=2+(k-1)*2+j-1;
  a=p.alpha;theta=squeeze(results.fits.parameters(k,j,:))';
  % Plot the saved parameters using the documented assignment formula.
  nonlinear=theta(3)*sin(theta(2)*atan(theta(1)*a-theta(4)*(theta(1)*a-atan(theta(1)*a))));
  plot(a*180/pi,p.table{:,col}/1000,'k',a*180/pi,results.fits.slopes(k,j)*a/1000,'--',a*180/pi,nonlinear/1000,'LineWidth',1.2);
  xlabel('Slip angle (deg)');ylabel('Axle force (kN)');grid on;title(sprintf('T%d axle %d',k,j));
  ylim(1.25*max(abs(p.table{:,col}))/1000*[-1 1]);xline(p.fitInterval(1)*180/pi,':','HandleVisibility','off');xline(p.fitInterval(2)*180/pi,':','HandleVisibility','off');
 end
end
lg=legend({'CSV MF6.2 reference','Linear fit','Simplified fit'},'Orientation','horizontal');lg.Layout.Tile='south';
set(findall(f,'Type','axes'),'FontSize',9);set(findall(f,'Type','legend'),'FontSize',8);
exportgraphics(f,fullfile(p.outputDir,'tire_fits.pdf'));close(f);
f=figure('Visible','off','Units','inches','Position',[1 1 3.4 2.5]);hold on;
for k=1:3,t=results.stability(results.stability.Tire==k,:);plot(t.Speed_mps,t.MaxRealEigenvalue,'Color',colors(k,:));end
yline(0,'k:');xlabel('Forward speed (m/s)');ylabel('Maximum real eigenvalue (1/s)');grid on;
legend(p.names,'Location','best');set(findall(f,'Type','axes'),'FontSize',9);set(findall(f,'Type','legend'),'FontSize',8);
exportgraphics(f,fullfile(p.outputDir,'speed_stability.pdf'));close(f);
f=figure('Visible','off','Units','inches','Position',[1 1 7 4.4]);tiledlayout(2,2);
for test=1:2
 for model=["linear","nonlinear","reference"]
  use=find(results.metrics.Tire==results.choice.tire & results.metrics.Test==test & ...
    results.metrics.Speed_mps==p.speeds{test}(2) & results.metrics.Model==model & results.metrics.Disturbance==1,1);
  r=results.responses{use};if isempty(r.t),continue;end
  nexttile(test);hold on;plot(r.t,r.states(:,2));
  nexttile(test+2);hold on;plot(r.states(:,1),r.states(:,2));
 end
 nexttile(test);grid on;xlim([0 p.stopTime]);xlabel('Time (s)');ylabel('Yaw rate (rad/s)');title(sprintf('Case %d',test));
 nexttile(test+2);grid on;xlabel('Lateral velocity (m/s)');ylabel('Yaw rate (rad/s)');
end
lg=legend({'Linear','Nonlinear','CSV'},'Orientation','horizontal');lg.Layout.Tile='south';set(findall(f,'Type','axes'),'FontSize',9);set(findall(f,'Type','legend'),'FontSize',8);
exportgraphics(f,fullfile(p.outputDir,'selected_responses.pdf'));close(f);
end
