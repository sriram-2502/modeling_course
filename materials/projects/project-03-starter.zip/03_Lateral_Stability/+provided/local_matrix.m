function A=local_matrix(p,U,front,rear,trim,api)
% Local force slopes at the actual operating point, not always at zero slip.
h=1e-5;C=zeros(1,2);
for j=1:2
 if j==1,f=front;else,f=rear;end
 a=trim.alpha(j);C(j)=(interp1(p.alpha,f,a+h,'linear','extrap')-interp1(p.alpha,f,a-h,'linear','extrap'))/(2*h);
end
% Reuse the STUDENT-derived matrix with local tire slopes; no solved matrix here.
A=api.linear_matrix(p,U,C(1),C(2));
end
