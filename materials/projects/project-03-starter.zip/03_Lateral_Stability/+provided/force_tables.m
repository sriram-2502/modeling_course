function [front,rear]=force_tables(p,fits,tire,mode,api)
switch mode
 case "linear"
  front=fits.slopes(tire,1)*p.alpha;rear=fits.slopes(tire,2)*p.alpha;
 case "nonlinear"
  front=api.nonlinear_force(p.alpha,squeeze(fits.parameters(tire,1,:))');
  rear=api.nonlinear_force(p.alpha,squeeze(fits.parameters(tire,2,:))');
 case "reference"
  front=p.front(:,tire);rear=p.rear(:,tire);
end
assert(isequal(size(front),size(p.alpha)) && isequal(size(rear),size(p.alpha)));
assert(all(isfinite([front;rear])));
assert(all(p.alpha.*front>=-1e-6) && all(p.alpha.*rear>=-1e-6),'Check tire-force signs.');
[~,zero]=min(abs(p.alpha));assert(max(abs([front(zero),rear(zero)]))<1e-6,'Zero slip must give zero force.');
end
