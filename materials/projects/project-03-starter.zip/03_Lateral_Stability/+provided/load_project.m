function p=load_project(folder)
p.root=folder; p.outputDir=fullfile(folder,'results'); p.modelDir=fullfile(folder,'models');
if ~isfolder(p.outputDir),mkdir(p.outputDir);end
p.m=1500;p.Iz=2500;p.a=1.2;p.b=1.6;p.g=9.81;
p.dt=.01;p.stopTime=12;p.alphaLimit=.25;p.betaLimit=.15;
settings=project_settings();p.fitInterval=settings.fitInterval;
assert(isequal(size(p.fitInterval),[1 2]) && p.fitInterval(1)<0 && p.fitInterval(2)>0 && all(abs(p.fitInterval)<=.25));
p.baseline=1;p.radius=120;
p.speeds={[15 27 33],[15 22 28]};p.disturbances=[.05 .003;.4 .025];
p.table=readtable(fullfile(folder,'data','tire_curves.csv'));p.alpha=p.table.alpha_rad;
assert(all(diff(p.alpha)>0) && all(isfinite(p.table{:,:}),'all'));
for k=1:3,p.front(:,k)=p.table.(sprintf('T%d_F_N',k));p.rear(:,k)=p.table.(sprintf('T%d_R_N',k));end
p.names={'T1: baseline','T2: balanced','T3: stiff / reduced peak'};
end
