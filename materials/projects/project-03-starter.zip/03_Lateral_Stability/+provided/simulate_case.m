function result=simulate_case(p,model,front,rear,U,trim,disturbance)
result=struct('completed',false,'reason',trim.reason,'t',[],'states',[]);
if ~trim.exists,return;end
variables=struct('vehicleMass',p.m,'yawInertia',p.Iz,'cgFront',p.a,'cgRear',p.b, ...
 'speed',U,'steering',trim.steering,'initialState',trim.state+disturbance(:), ...
 'alphaGrid',p.alpha','frontForces',front','rearForces',rear', ...
 'stopTime',p.stopTime,'outputTimes',(0:p.dt:p.stopTime));
in=Simulink.SimulationInput(model); names=fieldnames(variables);
for k=1:numel(names),in=in.setVariable(names{k},variables.(names{k}));end
in=in.setModelParameter('Solver','ode45','MaxStep',num2str(p.dt),'RelTol','1e-8', ...
 'AbsTol','1e-10','StopTime','stopTime','ReturnWorkspaceOutputs','on', ...
 'OutputOption','SpecifiedOutputTimes','OutputTimes','outputTimes');
out=sim(in); logged=out.states;x=squeeze(logged.Data);if size(x,1)~=numel(logged.Time),x=x';end
assert(size(x,2)==2,'Log states as [vy r].');
t=logged.Time;alpha=[trim.steering-(x(:,1)+p.a*x(:,2))/U, -(x(:,1)-p.b*x(:,2))/U];
valid=max(abs(alpha),[],2)<p.alphaLimit+1e-7 & abs(x(:,1)/U)<=p.betaLimit;
first=find(~valid,1);if isempty(first),last=numel(t);else,last=first;end
result.t=t(1:last);result.states=x(1:last,:);result.alpha=alpha(1:last,:);
result.completed=t(end)>=p.stopTime-1e-6 && isempty(first);
if ~result.completed,result.reason="Slip/sideslip validity limit reached; no full-test metrics.";end
psi=cumtrapz(result.t,result.states(:,2));
result.pose=[cumtrapz(result.t,U*cos(psi)-result.states(:,1).*sin(psi)), ...
 cumtrapz(result.t,U*sin(psi)+result.states(:,1).*cos(psi)),psi];
result.trim=trim;result.speed=U;
end
