function metric=evaluate_case(response,nominal,p)
metric=struct('PeakSlip_deg',NaN,'FinalError',NaN,'Recovered',false,'Status',"Unavailable");
if isempty(response.t),return;end
metric.PeakSlip_deg=max(abs(response.alpha),[],'all')*180/pi;
if ~response.completed,metric.Status="Validity limit";return;end
% Dimensionless distance to the COMMON reference operating point, not lane error.
e=sqrt(((response.states(:,1)-nominal.state(1))/.5).^2+ ...
 ((response.states(:,2)-nominal.state(2))/.05).^2);
use=response.t>=p.stopTime-2; metric.FinalError=max(e(use));
metric.Recovered=metric.FinalError<=.1;
if metric.Recovered,metric.Status="Recovered";else,metric.Status="Not recovered in window";end
end
