% Complete the functions in +student and the independent Simulink plant.
folder=fileparts(mfilename('fullpath'));addpath(folder);p=provided.load_project(folder);
api=struct('fit_linear',@student.fit_linear,'fit_nonlinear',@student.fit_nonlinear, ...
 'nonlinear_force',@student.nonlinear_force,'linear_matrix',@student.linear_matrix, ...
 'build_model',@student.build_model,'recommend',@student.recommend);
results=provided.run_all(p,api);
% Run animate_results.m to replay the saved logs without simulating again.
