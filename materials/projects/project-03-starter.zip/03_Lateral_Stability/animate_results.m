% Replay saved logs without running Simulink.
folder=fileparts(mfilename('fullpath'));addpath(folder);
file=fullfile(folder,'results','project_results.mat');
if ~isfile(file),error('lateral:MissingResults','Run run_project.m first to save project results.');end
saved=load(file,'results');animationFigure=provided.animate_results(saved.results);
