% Prepare the baseline, linear, straight-driving case in the editor workspace.
folder=fileparts(mfilename('fullpath'));addpath(folder);p=provided.load_project(folder);
slopes=student.fit_linear(p.table,p.fitInterval);
vehicleMass=p.m;yawInertia=p.Iz;cgFront=p.a;cgRear=p.b;
speed=15;steering=0;initialState=p.disturbances(1,:)';
alphaGrid=p.alpha';frontForces=slopes(1,1)*alphaGrid;rearForces=slopes(1,2)*alphaGrid;
stopTime=p.stopTime;outputTimes=0:p.dt:stopTime;
open_system(fullfile(p.modelDir,'lateral_student.slx'));
