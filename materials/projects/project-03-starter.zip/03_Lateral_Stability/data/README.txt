MODEL-GENERATED CSV REFERENCE -- NOT MEASURED TIRE DATA

Source: MathWorks R2026b Combined Slip Wheel 2DOF default Mid-size passenger car
235/45R18 MF6.2 pure-lateral force core. Optional Extended Tire Features is not
used. Instructor-only generator and full provenance metadata live outside this package.
https://www.mathworks.com/help/vdynblks/ref/combinedslipwheel2dof.html

alpha_rad: tire slip angle in radians, 1001 samples over [-0.25,0.25].
T1_F_N,T1_R_N,...: complete front/rear axle force in N, positive slope at zero.
Native force sign is normalized to the assignment convention; each single-tire
force is doubled for two identical tires at the fixed axle load. No student scaling.

m=1500 kg, a=1.2 m, b=1.6 m, g=9.81 m/s^2. Per-tire front/rear loads are
4204.285714/3153.214286 N. Pressure=220000 Pa, source speed=16.7 m/s,
zero camber and turn slip; lateral offsets and ply steer suppressed.
Each alpha channel is held fixed; the native pre-combination Fy0 signal is exported.
Combined-slip weighting and force relaxation are excluded.
The student vehicle model freezes these force curves at every test speed.

T1 baseline: front/rear stiffness scaling 1.05/0.65, peak scaling 1.00/0.95.
T2 balanced: stiffness 0.90/1.05, peak 1.05/1.05.
T3 stiff/reduced peak: stiffness 1.20/1.20, peak 0.82/0.82.
These are illustrative scaled packages, not commercial compound-hardness grades.

Keep the CSV unchanged; use linear interpolation. The assignment validity bound
is |alpha|<0.25 rad and |vy/U|<=0.15, not a universal tire operating envelope.
