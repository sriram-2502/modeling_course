%% RUN PROJECT: the complete, reproducible student study.
% First use start_here and run_checkpoint to complete one part at a time.
projectFolder = fileparts(mfilename('fullpath')); addpath(projectFolder);

%% 1. Check one local-stability example using your derived matrix.
baselineModes = run_checkpoint("stability");

%% 2. Fit cable data, verify your ODE and Simulink, then run 36 comparisons.
results = run_checkpoint("final");
results.baselineLocalAnalysis = baselineModes;

%% 3. Save replayable results, metrics, fit errors and every simulation CSV.
% run_checkpoint returns results; this entry script writes the submission.
results.metrics = provided.save_cable_results(results);
provided.plot_cable_results(results);
save(fullfile(results.settings.outputFolder,'project_results.mat'),'results');
referenceRows = results.metrics.ForceModel=="CSV reference";
summaryColumns = {'Case','Controller','K_Npm','D_Nspm', ...
    'PeakPathError_mm','PeakTimedError_mm','Band'};
disp(results.metrics(referenceRows,summaryColumns));
fprintf('Saved all 36 runs to %s\n',results.settings.outputFolder);

%% 4. Replay: camera movement changes only the view, not the experiment.
if results.settings.showAnimation
    replayFigure = provided.replay(results);
end
