function plot_cable_results(R)
% PLOT_CABLE_RESULTS Supplied path geometry and force-model prediction errors.
p=R.settings;chord=p.targetOffset/norm(p.targetOffset);side=p.arcNormal;
f=figure('Visible','off','Color','w','Position',[40 40 1100 390]);clean=onCleanup(@()close(f));
for k=1:3
    ax=subplot(1,3,k,'Parent',f);settings=p;settings.pathType=p.pathNames{k};
    x=provided.seam_path(linspace(0,1,401),settings)-p.startPosition;
    plot(ax,1000*x*chord',1000*x*side','LineWidth',2,'Color',[.48 .23 .68]);
    hold(ax,'on');plot(ax,0,0,'ko','MarkerFaceColor','k');grid(ax,'on');axis(ax,'equal');
    xlim(ax,[-10 120]);ylim(ax,[-30 40]);title(ax,p.pathNames{k});
    xlabel(ax,'Along chord (mm)');ylabel(ax,'Lateral position (mm)');
end
exportgraphics(f,fullfile(p.outputFolder,'seam_paths.png'),'Resolution',160);
clear clean
f=figure('Visible','off','Color','w','Position',[40 40 1050 520]);clean=onCleanup(@()close(f));
ax=axes(f);error=zeros(6,2);
for c=1:6
    for m=2:3
        rows=R.metrics.Case==string(R.cases(c).name)& ...
            R.metrics.ForceModel==string(p.fitNames{m})&R.metrics.Controller==string(p.profiles(2).name);
        error(c,m-1)=R.metrics.PredictionRMSE_mm(rows);
    end
end
bars=bar(ax,error);bars(1).FaceColor=[.9 .36 .09];bars(2).FaceColor=[.48 .23 .68];
labels=cell(1,6);
for c=1:6
    labels{c}=strrep(R.cases(c).name,' cable load','');
end
ax.XTick=1:6;ax.XTickLabel=labels;ax.XTickLabelRotation=0;
ax.FontSize=10;
xlabel(ax,'Seam / cable load');
ylabel(ax,'Trajectory prediction RMSE vs CSV reference (mm)');grid(ax,'on');
legend(ax,p.fitNames(2:3),'Location','northoutside','Orientation','horizontal');
title(ax,'Tuned controller: effect of cable-force approximation');
exportgraphics(f,fullfile(p.outputFolder,'prediction_comparison.png'),'Resolution',160);
end
