function applied = limit_force(requested,limit)
% LIMIT_FORCE Supplied virtual actuator budget, independently on X/Y/Z.
% Use the same operation/block in the ODE and Simulink. Inputs/outputs in N.
applied=max(-limit,min(limit,requested));
end
