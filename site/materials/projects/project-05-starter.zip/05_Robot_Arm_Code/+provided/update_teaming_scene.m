function update_teaming_scene(h,model,q,desired,F)
% UPDATE_TEAMING_SCENE Equal force arrow scale in both panels; no exaggerated motion.
[x,T]=provided.fk(model,q);x=x';
for k=1:numel(h.transforms),h.transforms(k).Matrix=T(:,:,k);end
set(h.target,'XData',desired(1),'YData',desired(2),'ZData',desired(3));
set(h.tip,'XData',x(1),'YData',x(2),'ZData',x(3));
set(h.error,'XData',[desired(1) x(1)],'YData',[desired(2) x(2)],'ZData',[desired(3) x(3)]);
vertices=(T(:,:,model.tip)*[h.toolLocal ones(size(h.toolLocal,1),1)]')';
set(h.tool,'XData',reshape(vertices(:,1),2,[]),'YData',reshape(vertices(:,2),2,[]), ...
    'ZData',reshape(vertices(:,3),2,[]));
if norm(F)>1e-6
    u=F/norm(F);v=cross([0 0 1],u);v=v/norm(v);
    tail=x-.10*F;
    set(h.force,'XData',tail(1),'YData',tail(2),'ZData',tail(3), ...
        'UData',.10*F(1),'VData',.10*F(2),'WData',.10*F(3),'Visible','on');
    shape=[-.030 -.010;-.005 -.010;-.005 -.006;.017 -.006;.022 -.003; ...
        .018 0;.002 0;.004 .006;.001 .010;-.005 .007;-.008 .013;-.017 .014;-.030 .010];
    points=tail+shape(:,1)*u+shape(:,2)*v;
    set(h.hand,'XData',points(:,1),'YData',points(:,2),'ZData',points(:,3),'Visible','on');
else
    h.force.Visible='off';h.hand.Visible='off';
end
end
