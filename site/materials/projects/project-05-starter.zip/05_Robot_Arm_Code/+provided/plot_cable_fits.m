function plot_cable_fits(p,fits,data)
% PLOT_CABLE_FITS Input data and fit comparison; equal aspect across exports.
f=figure('Visible','off','Color','w','Position',[50 50 650 580]);
clean=onCleanup(@()close(f));ax=axes(f);hold(ax,'on');grid(ax,'on');
plot(ax,data.Velocity_mps,data.CableForce_N,'ko','MarkerSize',4,'DisplayName','Synthetic CSV');
v=linspace(min(fits.velocity),max(fits.velocity),501)';
plot(ax,v,provided.cable_force(v,fits,2),'--','LineWidth',1.8,'Color',[.9 .36 .09],'DisplayName','Linear');
plot(ax,v,provided.cable_force(v,fits,3),'-','LineWidth',1.8,'Color',[.48 .23 .68],'DisplayName','Nonlinear');
xlabel(ax,'Cable sliding velocity (m/s)');ylabel(ax,'Force on robot (N)');
title(ax,'Synthetic cable-guide data (low load)');legend(ax,'Location','northeast');
exportgraphics(f,fullfile(p.outputFolder,'cable_force_fits.png'),'Resolution',160);
exportgraphics(f,fullfile(p.outputFolder,'cable_force_fits.pdf'),'ContentType','vector');
end
