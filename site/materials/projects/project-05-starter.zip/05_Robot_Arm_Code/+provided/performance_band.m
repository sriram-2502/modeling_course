function band=performance_band(pathError,timedError,p)
% PERFORMANCE_BAND Both limits must hold. Inputs are peak errors in meters.
band=repmat("Needs improvement",size(pathError));
acceptable=pathError<=p.evaluation.acceptablePath & timedError<=p.evaluation.acceptableTimed;
good=pathError<=p.evaluation.goodPath & timedError<=p.evaluation.goodTimed;
band(acceptable)="Acceptable";band(good)="Good";
end
