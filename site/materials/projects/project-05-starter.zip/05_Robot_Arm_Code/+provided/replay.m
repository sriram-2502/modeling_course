function fig = replay(results,varargin)
% REPLAY All animations use saved states; no dynamics or fitting runs here.
% Supplied numerical IK converts selected saved positions to drawing poses.
ip=inputParser;addParameter(ip,'Visible','on');addParameter(ip,'AutoPlay',true);
addParameter(ip,'CaseIndex',4);addParameter(ip,'ModelIndex',1);parse(ip,varargin{:});
c=ip.Results.CaseIndex;m=ip.Results.ModelIndex;C=results.cases(c);p=C.settings;
for g=1:numel(p.profiles)
    L=C.logs{m,g};
    if any(~isfinite(L.q),'all')
        fprintf('Preparing replay poses: %s / %s (no dynamic simulation).\n',C.name,p.profiles(g).name);
        seed=p.home;
        for k=1:numel(L.t)
            [seed,info]=provided.ik_position(results.model,L.position(k,:),seed);
            assert(info.success,'robot:ReplayReach', ...
                'Tool position at %.2f s is outside drawing workspace. Numerical metrics remain valid.',L.t(k));
            L.q(k,:)=seed;
        end
        C.logs{m,g}=L;
    end
end
results.cases(c)=C;
viewResults=struct('settings',p,'model',results.model,'logs',{C.logs(m,:)});
fig=provided.seam_viewer(viewResults,'Visible',ip.Results.Visible,'AutoPlay',ip.Results.AutoPlay);
base=getappdata(fig,'SO101SeamControls');base.choice.Position=[.035 .85 .23 .035];
base.camera.Position=[.81 .85 .16 .035];
caseMenu=uicontrol(fig,'Style','popupmenu','String',{results.cases.name}, ...
    'Units','normalized','Position',[.28 .85 .29 .035],'Value',c,'Callback',@change);
fitMenu=uicontrol(fig,'Style','popupmenu','String',p.fitNames, ...
    'Units','normalized','Position',[.59 .85 .20 .035],'Value',m,'Callback',@change);
set(findall(fig,'Tag','ReplayTitle'),'String','Trace the seam. Compare cable models and gains.');
set(findall(fig,'Tag','ReplayFooter'),'String', ...
    'Saved-data replay. Drag scene to rotate; toolbar to zoom/pan. Dashed blue = desired seam. Solid = modeled tool motion.');
setappdata(fig,'RobotReplayControls',struct('caseMenu',caseMenu,'fitMenu',fitMenu,'base',base));
    function change(~,~)
        time=base.slider.Value;angle=base.sceneAxes.View;gain=base.choice.Value;
        next=provided.replay(results,'Visible',ip.Results.Visible,'AutoPlay',false, ...
            'CaseIndex',caseMenu.Value,'ModelIndex',fitMenu.Value);
        controls=getappdata(next,'RobotReplayControls');controls.base.choice.Value=gain;
        controls.base.seek(time);controls.base.sceneAxes.View=angle;close(fig);
    end
end
