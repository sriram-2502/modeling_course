function results = run_study(p,model,fits,modelFile)
% RUN_STUDY Six cases x three force models x two gain pairs = 36 SLX runs.
results=struct('settings',p,'model',model,'fits',fits,'cases',struct([]));
for c=1:6
    settings=provided.case_settings(p,fits,c,1);
    C=struct('name',sprintf('%s / %s cable load',settings.pathType,p.loadNames{mod(c-1,2)+1}), ...
        'settings',settings,'logs',{cell(3,2)});
    for m=1:3
        settings.cable.modelIndex=m;
        for g=1:2
            fprintf('%s | %s | %s\n',C.name,p.fitNames{m},p.profiles(g).name);
            C.logs{m,g}=provided.simulate_model(modelFile,settings,p.profiles(g));
        end
    end
    if c==1,results.cases=C;else,results.cases(c)=C;end
end
end

