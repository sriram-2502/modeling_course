function [p,model,data] = load_project
% LOAD_PROJECT Fixed setup; never invokes student functions or external paths.
p=project_settings;
saved=load(fullfile(p.folder,'assets','robot_geometry.mat'),'model'); model=saved.model;
p.startPosition=provided.fk(model,p.home)';
[~,p.initialPosition]=provided.initial_state(p,model);
data=readtable(fullfile(p.dataFolder,'cable_force_velocity.csv'),'TextType','string');
assert(all(ismember(data.Split,["fit","validation"])), 'Unexpected CSV split labels.');
assert(all(diff(data.Velocity_mps)>0),'CSV velocities must be strictly increasing.');
if ~isfolder(p.outputFolder),mkdir(p.outputFolder);end
end
