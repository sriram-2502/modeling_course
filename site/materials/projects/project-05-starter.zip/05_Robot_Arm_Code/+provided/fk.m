function [tip,T,J] = fk(model,q)
% FK Forward kinematics and TRANSLATIONAL world-frame Jacobian; base MATLAB.
q=q(:);T=repmat(eye(4),1,1,numel(model.names));
axes=zeros(3,5);origins=axes;
for k=1:numel(model.joints)
    joint=model.joints(k);A=T(:,:,joint.parent)*joint.origin;
    if joint.index>0
        j=joint.index;axes(:,j)=A(1:3,1:3)*joint.axis;origins(:,j)=A(1:3,4);
        a=joint.axis/norm(joint.axis);S=[0 -a(3) a(2);a(3) 0 -a(1);-a(2) a(1) 0];
        R=eye(3)+sin(q(j))*S+(1-cos(q(j)))*(S*S);
        A=A*[R zeros(3,1);0 0 0 1];
    end
    T(:,:,joint.child)=A;
end
tip=T(1:3,4,model.tip);
if nargout>2
    J=zeros(3,5);
    for j=1:5,J(:,j)=cross(axes(:,j),tip-origins(:,j));end
end
end
