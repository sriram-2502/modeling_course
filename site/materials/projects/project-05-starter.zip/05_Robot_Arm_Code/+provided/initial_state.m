function [q,x]=initial_state(p,model)
% INITIAL_STATE Match the virtual and physical initial tip positions exactly.
[q,info]=provided.ik_position(model,p.startPosition+p.initialOffset,p.home);
assert(info.success,'The prescribed initial offset is outside the reachable workspace.');
x=provided.fk(model,q)';
end
