function distance=seam_distance(position,p)
% SEAM_DISTANCE Euclidean distance to finite arc, using 1000 line segments.
% This includes endpoint distance; it does not confuse along-path timing lag
% with distance to the geometric seam. Segment error is below 0.1 micrometers
% for the default arc. Also handles the preserved straight seam.
path=provided.seam_path(linspace(0,1,1001),p);best=inf(size(position,1),1);
for j=1:size(path,1)-1
    edge=path(j+1,:)-path(j,:);delta=position-path(j,:);
    f=max(0,min(1,delta*edge'/sum(edge.^2)));
    best=min(best,sum((delta-f*edge).^2,2));
end
distance=sqrt(best);
end
