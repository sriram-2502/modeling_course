function h=teaming_scene(fig,position,model,color)
% TEAMING_SCENE Reusable SO-101 scene, with a schematic human push indicator.
ax=axes(fig,'Position',position);hold(ax,'on');h.axes=ax;
h.floor=patch(ax,'XData',[-.08 .44 .44 -.08],'YData',[-.20 -.20 .20 .20], ...
    'ZData',[-.005 -.005 -.005 -.005],'FaceColor',[.91 .93 .95], ...
    'EdgeColor','none','FaceLighting','none');
h.transforms=gobjects(1,numel(model.names));
for k=1:numel(h.transforms),h.transforms(k)=hgtransform('Parent',ax);end
for k=1:numel(model.meshes)
    mesh=model.meshes(k);V=(mesh.transform*[mesh.vertices ones(size(mesh.vertices,1),1)]')';
    patch('Parent',h.transforms(mesh.link),'Faces',mesh.faces,'Vertices',V(:,1:3), ...
        'FaceColor',mesh.color,'EdgeColor','none','FaceLighting','gouraud', ...
        'AmbientStrength',.55,'DiffuseStrength',.65,'SpecularStrength',.10);
end
h.target=plot3(ax,nan,nan,nan,'o','Color',[.10 .35 .40],'MarkerSize',12,'LineWidth',1.8);
h.tip=plot3(ax,nan,nan,nan,'.','Color',color,'MarkerSize',20);
h.error=plot3(ax,nan,nan,nan,'--','Color',color,'LineWidth',1.7);
h.force=quiver3(ax,0,0,0,0,0,0,0,'Color',[.92 .35 .08],'LineWidth',2.6,'MaxHeadSize',.65);
% Simple pointing-hand silhouette in the horizontal plane. Schematic, no contact physics.
h.hand=patch(ax,'XData',nan,'YData',nan,'ZData',nan,'FaceColor',[1 .87 .70], ...
    'EdgeColor',[.75 .39 .14],'LineWidth',1.0,'FaceLighting','none');
% A small illustrative handle at the TCP; it adds no payload or grasp mechanics.
[X,Y,Z]=cylinder(.0045,12);h.toolLocal=[X(:) Y(:) .028*(Z(:)-.5)];
h.tool=surf(ax,X,Y,Z,'FaceColor',[.34 .45 .58],'EdgeColor','none','FaceLighting','gouraud');
axis(ax,'equal');xlim(ax,[-.02 .38]);ylim(ax,[-.125 .125]);zlim(ax,[-.005 .30]);
view(ax,135,24);grid(ax,'on');ax.GridAlpha=.10;ax.FontSize=8;ax.Box='off';
ax.Color=[.98 .99 1];ax.Toolbar.Visible='off';
xlabel(ax,'X (m)');ylabel(ax,'Y (m)');zlabel(ax,'Z (m)');
camlight(ax,'headlight');lighting(ax,'gouraud');
h.floor.FaceLighting='none';axis(ax,'off');
end
