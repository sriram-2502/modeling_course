function log = simulate_model(modelFile,p,controller)
% SIMULATE_MODEL Runs YOUR saved standard-block SLX with isolated case inputs.
[~,name]=fileparts(modelFile);load_system(modelFile);
blocks=find_system(name,'SearchDepth',1,'Type','Block');
for k=1:numel(blocks)
    handles=get_param(blocks{k},'PortHandles');
    for port=handles.Inport
        assert(get_param(port,'Line')~=-1,'robot:UnwiredModel', ...
            'Connect every input port; unfinished block: %s',get_param(blocks{k},'Name'));
    end
end
in=Simulink.SimulationInput(name);values=provided.model_variables(p,controller);
names=fieldnames(values);
for k=1:numel(names),in=in.setVariable(names{k},values.(names{k}));end
in=in.setModelParameter('StopTime','stopTime','Solver','ode45', ...
    'RelTol','1e-8','AbsTol','1e-10','MaxStep','.01', ...
    'ReturnWorkspaceOutputs','on','OutputOption','SpecifiedOutputTimes', ...
    'OutputTimes','outputTimes');
out=sim(in);ts=out.tipStates;states=squeeze(ts.Data);
if size(states,1)~=numel(ts.Time),states=states';end
assert(size(states,2)==6,'Log [x;y;z;vx;vy;vz] in that order.');
time=values.outputTimes;states=interp1(ts.Time,states,time);
log=provided.package_log(time,states,p,controller);
end
