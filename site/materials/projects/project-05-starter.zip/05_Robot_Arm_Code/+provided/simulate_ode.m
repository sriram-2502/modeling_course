function log = simulate_ode(p,controller)
% SIMULATE_ODE Numerical integration calls YOUR six-state RHS, not an answer.
time=(0:p.dt:p.duration)';initial=[p.initialPosition zeros(1,3)]';
options=odeset('RelTol',1e-8,'AbsTol',1e-10,'MaxStep',0.02);
[~,states]=ode45(@(t,s)student.tool_rhs(t,s,p,controller),time,initial,options);
log=provided.package_log(time,states,p,controller);
end
