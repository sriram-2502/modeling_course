function [xd,vd,ad] = reference(time,p)
% REFERENCE Supplied target position, velocity, acceleration: N x 3 rows.
% Uses analytical path derivatives; students do not fit or differentiate these.
s=(time(:)-p.moveWindow(1))/diff(p.moveWindow);s=max(0,min(1,s));
h=10*s.^3-15*s.^4+6*s.^5;
hd=(30*s.^2-60*s.^3+30*s.^4)/diff(p.moveWindow);
hdd=(60*s-180*s.^2+120*s.^3)/diff(p.moveWindow)^2;
[xd,pathD,pathDD]=provided.seam_path(h,p);
vd=pathD.*hd;ad=pathDD.*hd.^2+pathD.*hdd;
end
