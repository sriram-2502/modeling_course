function fits = fit_models(data)
% FIT_MODELS Split data once; never pass validation rows to a fitting function.
training=data.Split=="fit";
fits=struct('velocity',data.Velocity_mps,'force',data.CableForce_N);
fits.linearDamping=student.fit_linear(data.Velocity_mps(training),data.CableForce_N(training));
assert(isscalar(fits.linearDamping)&&isfinite(fits.linearDamping)&&fits.linearDamping>=0, ...
    'fit_linear must return a finite nonnegative scalar.');
fits.nonlinear=student.fit_nonlinear(data.Velocity_mps(training),data.CableForce_N(training));
assert(isstruct(fits.nonlinear)&&isscalar(fits.nonlinear),'Return nonlinear parameters in a scalar struct.');
fitError=zeros(2,1);validationError=fitError;
for modelIndex=2:3
    residual=provided.cable_force(data.Velocity_mps,fits,modelIndex)-data.CableForce_N;
    fitError(modelIndex-1)=sqrt(mean(residual(training).^2));
    validationError(modelIndex-1)=sqrt(mean(residual(~training).^2));
end
fits.metrics=table(["Linear fit";"Nonlinear fit"],fitError,validationError, ...
    'VariableNames',{'Model','FitRMSE_N','ValidationRMSE_N'});
% Check interpolation as well as data points; do not impose a nonlinear family.
v=linspace(min(fits.velocity),max(fits.velocity),1001)';
F=provided.cable_force(v,fits,3);
assert(all(F.*v<=1e-8),'Your nonlinear law supplies energy at some sampled speed. Check its sign.');
end
