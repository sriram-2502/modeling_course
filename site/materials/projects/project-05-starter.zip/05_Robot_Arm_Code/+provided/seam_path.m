function [x,dh,ddh]=seam_path(h,p)
% SEAM_PATH Circular arc parameterized by progress h in [0,1].
% Derivatives are with respect to h; inputs.m applies the time chain rule.
h=h(:);L=norm(p.targetOffset);e=p.targetOffset/L;
if isfield(p,'pathType') && strcmp(p.pathType,'S-curve')
    n=p.arcNormal/norm(p.arcNormal);A=.015;
    x=p.startPosition+h*p.targetOffset+A*sin(2*pi*h)*n;
    dh=repmat(p.targetOffset,numel(h),1)+2*pi*A*cos(2*pi*h)*n;
    ddh=-(2*pi)^2*A*sin(2*pi*h)*n;return
end
if isfield(p,'pathType') && strcmp(p.pathType,'Straight')
    x=p.startPosition+h*p.targetOffset;
    dh=repmat(p.targetOffset,numel(h),1);ddh=zeros(size(dh));return
end
if ~isfield(p,'arcAngle') || abs(p.arcAngle)<1e-8
    x=p.startPosition+h*p.targetOffset;
    dh=repmat(p.targetOffset,numel(h),1);ddh=zeros(size(dh));return
end
theta=p.arcAngle;n=p.arcNormal/norm(p.arcNormal);
assert(abs(e*n')<1e-8,'Arc normal must be perpendicular to the chord.');
R=L/(2*sin(theta/2));angle=theta*(h-.5);
center=p.startPosition+p.targetOffset/2-R*cos(theta/2)*n;
x=center+R*(sin(angle)*e+cos(angle)*n);
dh=R*theta*(cos(angle)*e-sin(angle)*n);
ddh=-R*theta^2*(sin(angle)*e+cos(angle)*n);
end
