function [applied,requested,limited]=command_force(x,v,xd,vd,ad,p,profile)
% COMMAND_FORCE Total virtual command, including acceleration feedforward.
% A componentwise symmetric force budget is an educational actuator model,
% not an experimentally identified SO-101 Cartesian force rating.
requested=p.virtualMass*ad+profile.stiffness*(xd-x)+profile.damping*(vd-v);
applied=requested;
if isfield(p,'commandForceLimit')
    applied=max(-p.commandForceLimit,min(p.commandForceLimit,requested));
end
limited=any(abs(applied-requested)>1e-10,2);
end
