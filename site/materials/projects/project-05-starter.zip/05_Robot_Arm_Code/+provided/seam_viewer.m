function fig=seam_viewer(results,varargin)
% SEAM_VIEWER Task A replay. Drag the scene to rotate the camera, not the provided.
ip=inputParser;addParameter(ip,'Visible','on');addParameter(ip,'AutoPlay',true);parse(ip,varargin{:});
p=results.settings;logs=results.logs;n=numel(p.profiles);colors=[.48 .23 .68;.05 .48 .52;.90 .36 .09];
fig=figure('Name','Robot arm | Seam tracing','Color','w','Position',[30 40 1380 820], ...
    'MenuBar','none','ToolBar','none','Visible',ip.Results.Visible);
annotation(fig,'textbox',[.03 .94 .94 .045],'String','Trace the seam. Reject the pull. Recover from the bump.', ...
    'FontSize',19,'FontWeight','bold','EdgeColor','none','Tag','ReplayTitle');
subtitle=sprintf('Marker-tracing analogy | command limit +/- %.1f N per axis | path tolerance %.0f mm',p.commandForceLimit,1000*p.pathTolerance);
if isfield(p,'evaluation')
 subtitle=sprintf('Command +/- %.1f N / axis | Acceptable: path <= %.0f mm AND timed <= %.0f mm | Scoring: %.1f-%.1f s', ...
     p.commandForceLimit,1000*p.pathTolerance,1000*p.timedTolerance,p.moveWindow);
end
annotation(fig,'textbox',[.03 .902 .94 .035],'String',subtitle,'FontSize',11,'EdgeColor','none');
choice=uicontrol(fig,'Style','popupmenu','String',{p.profiles.name},'Units','normalized', ...
    'Position',[.04 .85 .27 .035],'Value',min(2,n),'Callback',@change);
h=provided.teaming_scene(fig,[.015 .34 .51 .49],results.model,colors(2,:));
a=p.startPosition;
[path,pathD]=provided.seam_path(linspace(0,1,301),p);
side=p.arcNormal/norm(p.arcNormal);
normal=cross(repmat(cross(p.targetOffset,side),size(path,1),1),pathD,2);
normal=normal./vecnorm(normal,2,2);
% A light workpiece under the seam gives the tool path a clear visual surface.
chord=p.targetOffset/norm(p.targetOffset);down=cross(chord,side);
corners=a+[-.025 -.04;norm(p.targetOffset)+.025 -.04; ...
    norm(p.targetOffset)+.025 .065;-.025 .065]*[chord;side]+.006*down;
patch(h.axes,'Vertices',corners,'Faces',[1 2 3 4],'FaceColor',[.87 .91 .95], ...
    'EdgeColor',[.55 .65 .75],'FaceLighting','none','FaceAlpha',.85);
plot3(h.axes,path(:,1),path(:,2),path(:,3),'--','Color',[.10 .22 .55],'LineWidth',3);
text(h.axes,path(1,1),path(1,2)-.012,path(1,3),'START','FontSize',9,'FontWeight','bold');
text(h.axes,path(end,1),path(end,2)+.012,path(end,3),'END','FontSize',9,'FontWeight','bold');
for sign=[-1 1]
    boundary=path+sign*p.pathTolerance*normal;
    plot3(h.axes,boundary(:,1),boundary(:,2),boundary(:,3), ...
        ':','Color',[.6 .6 .6],'LineWidth',1.5);
end
trail=plot3(h.axes,nan,nan,nan,'Color',colors(2,:),'LineWidth',3);
view(h.axes,65,40);
zoom=axes(fig,'Position',[.075 .21 .38 .12]);hold(zoom,'on');grid(zoom,'on');
lengthMM=1000*norm(p.targetOffset);tolMM=1000*p.pathTolerance;
upper=path+p.pathTolerance*normal;lower=path-p.pathTolerance*normal;
patch(zoom,1000*([upper;flipud(lower)]-a)*chord',1000*([upper;flipud(lower)]-a)*side',[.88 .95 .91], ...
    'EdgeColor','none','FaceAlpha',.65);
plot(zoom,1000*(path-a)*chord',1000*(path-a)*side','k--','LineWidth',1.2);
zoomTrail=plot(zoom,nan,nan,'LineWidth',2,'Color',colors(2,:));
zoomTip=plot(zoom,nan,nan,'.','MarkerSize',16,'Color',colors(2,:));
xlim(zoom,[-tolMM lengthMM+tolMM]);
ylim(zoom,1000*[min((path-a)*side')-.025 max((path-a)*side')+.015]);
xlabel(zoom,'Along chord (mm)');ylabel(zoom,'Lateral position (mm)');
title(zoom,'Magnified tool path: green = tolerance','FontSize',10);
ax=axes(fig,'Position',[.57 .58 .39 .23]);hold(ax,'on');grid(ax,'on');
errors=cell(1,numel(logs));
d=p.targetOffset/norm(p.targetOffset);
for k=1:numel(logs)
    errors{k}=1000*provided.seam_distance(logs{k}.position,p);
end
errLine=gobjects(1,n);
offset=0;
for k=1:n,errLine(k)=plot(ax,logs{k}.t,errors{offset+k},'Color',colors(k,:),'LineWidth',1.5);end
yline(ax,1000*p.pathTolerance,'k--','Tolerance','HandleVisibility','off');
xlim(ax,[0 p.duration]);ylabel(ax,'Distance to seam (mm)');xlabel(ax,'Time (s)');
legend(ax,{p.profiles.name},'Location','northoutside','Orientation','horizontal','FontSize',8);
cursor=xline(ax,0,'k-','HandleVisibility','off');
af=axes(fig,'Position',[.57 .24 .39 .23]);hold(af,'on');grid(af,'on');
L=logs{offset+min(2,n)};[cmd,req]=provided.command_force(L.position,L.velocity,L.desired,L.desiredVelocity,L.desiredAcceleration,p,L.profile);
forceLabel='External Y';if isfield(p,'cable'),forceLabel='Cable Y';end
plot(af,L.t,L.force(:,2),'Color',[.6 .6 .6],'DisplayName',forceLabel);
requestLine=plot(af,L.t,req(:,2),'--','Color',colors(2,:),'LineWidth',1.5,'DisplayName','Requested Y');
commandLine=plot(af,L.t,cmd(:,2),'-','Color',colors(2,:),'LineWidth',1.5,'DisplayName','Applied Y');
yline(af,p.commandForceLimit,'k:','HandleVisibility','off');yline(af,-p.commandForceLimit,'k:','HandleVisibility','off');
xlim(af,[0 p.duration]);xlabel(af,'Time (s)');ylabel(af,'Force (N)');legend(af,'Location','northoutside','Orientation','horizontal');
forceCursor=xline(af,0,'k-','HandleVisibility','off');
status=uicontrol(fig,'Style','text','BackgroundColor','w','Units','normalized', ...
    'Position',[.035 .135 .93 .045],'FontSize',12,'HorizontalAlignment','left');
button=uicontrol(fig,'Style','pushbutton','String','Play / pause','Units','normalized', ...
    'Position',[.04 .07 .12 .045],'Callback',@toggle);
camera=uicontrol(fig,'Style','popupmenu','String',{'Perspective','Top','Side','Seam close-up'}, ...
    'Units','normalized','Position',[.67 .85 .16 .035],'Callback',@setCamera);
slider=uicontrol(fig,'Style','slider','Min',0,'Max',p.duration,'Value',0,'Units','normalized', ...
    'Position',[.19 .075 .74 .03],'Callback',@(s,~)seek(s.Value));
annotation(fig,'textbox',[.035 .015 .94 .035],'String', ...
    'Drag the 3-D scene to rotate the camera. Use its toolbar to zoom/pan. Blue dashed = seam; colored solid = actual trail. Pull: 2.5-4.5 s; bump: 6-6.25 s.', ...
    'FontSize',9,'EdgeColor','none','Tag','ReplayFooter');
playing=false;time=0;wall=tic;
tm=timer('ExecutionMode','fixedSpacing','Period',.04,'BusyMode','drop','TimerFcn',@tick);
fig.CloseRequestFcn=@closeViewer;
% Rotation applies only to the arm scene; data plots stay fixed.
rotation=rotate3d(fig);setAllowAxesRotate(rotation,h.axes,true);
setAllowAxesRotate(rotation,zoom,false);setAllowAxesRotate(rotation,ax,false);setAllowAxesRotate(rotation,af,false);
rotation.Enable='on';h.axes.Toolbar.Visible='on';
setappdata(fig,'SO101SeamControls',struct('seek',@seek,'timer',tm,'slider',slider, ...
    'choice',choice,'camera',camera, ...
    'sceneAxes',h.axes,'setCamera',@setCamera));
seek(0);if ip.Results.AutoPlay,toggle();end
    function seek(t)
        time=max(0,min(p.duration,t));slider.Value=time;wall=tic;
        index=choice.Value;L=logs{index};[~,sample]=min(abs(L.t-time));
        provided.update_teaming_scene(h,results.model,L.q(sample,:),L.desired(sample,:),L.force(sample,:));
        h.hand.Visible='off';set(trail,'XData',L.position(1:sample,1),'YData',L.position(1:sample,2), ...
            'ZData',L.position(1:sample,3),'Color',colors(choice.Value,:));
        along=1000*(L.position(1:sample,:)-a)*d';lateral=1000*(L.position(1:sample,:)-a)*side';
        set(zoomTrail,'XData',along,'YData',lateral,'Color',colors(choice.Value,:));
        set(zoomTip,'XData',along(end),'YData',lateral(end),'Color',colors(choice.Value,:));
        cursor.Value=time;forceCursor.Value=time;
        [c,r,lim]=provided.command_force(L.position,L.velocity,L.desired,L.desiredVelocity,L.desiredAcceleration,p,L.profile);
        set(requestLine,'YData',r(:,2),'Color',colors(choice.Value,:));set(commandLine,'YData',c(:,2),'Color',colors(choice.Value,:));
        for j=1:n,errLine(j).YData=errors{j};end
        label='WITHIN TOLERANCE';if errors{index}(sample)>1000*p.pathTolerance,label='OUTSIDE TOLERANCE';end
        if isfield(p,'evaluation')
            active=L.t>=p.moveWindow(1)&L.t<=p.moveWindow(2);
            timed=vecnorm(L.position-L.desired,2,2);
            band=provided.performance_band(max(errors{index}(active))/1000,max(timed(active)),p);
            phase='traversal';if time<p.moveWindow(1),phase='startup (not scored)';elseif time>p.moveWindow(2),phase='final hold (not scored)';end
            status.FontSize=10;status.Position=[.035 .12 .93 .06];
            status.String=sprintf('t %.2f s | K %.0f N/m, D %.2f Ns/m | %s | traversal band: %s\nCurrent path error %.1f mm | timed error %.1f mm | force limited %d', ...
                time,L.profile.stiffness,L.profile.damping,phase,band,errors{index}(sample),1000*timed(sample),lim(sample));
        else
        status.String=sprintf('t = %.2f s | K = %.0f N/m, D = %.2f Ns/m | path error %.1f mm | %s | force limited: %d', ...
            time,L.profile.stiffness,L.profile.damping,errors{index}(sample),label,lim(sample));
        end
        drawnow limitrate;
    end
    function tick(~,~)
        next=time+toc(wall);seek(next);
        if next>=p.duration,playing=false;stop(tm);end
    end
    function toggle(varargin)
        playing=~playing;
        if playing,if time>=p.duration,seek(0);end;wall=tic;start(tm);else,stop(tm);end
    end
    function change(~,~),seek(time);end
    function setCamera(varargin)
        % Reset framing; these presets do not alter the saved robot motion.
        xlim(h.axes,[-.02 .38]);ylim(h.axes,[-.125 .125]);zlim(h.axes,[-.005 .30]);
        switch camera.Value
            case 1,view(h.axes,65,40);
            case 2,view(h.axes,0,90);
            case 3,view(h.axes,0,0);
            case 4
                xlim(h.axes,[min(path(:,1))-.025 max(path(:,1))+.025]);
                ylim(h.axes,[min(path(:,2))-.035 max(path(:,2))+.025]);
                zlim(h.axes,[min(path(:,3))-.025 max(path(:,3))+.045]);
                view(h.axes,95,70);
        end
    end
    function closeViewer(~,~)
        stop(tm);delete(tm);delete(fig);
    end
end
