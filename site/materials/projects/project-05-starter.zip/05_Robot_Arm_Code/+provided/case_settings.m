function settings = case_settings(p,fits,caseIndex,modelIndex)
% CASE_SETTINGS Case order: straight low/high, arc low/high, S-curve low/high.
assert(ismember(caseIndex,1:6)&&ismember(modelIndex,1:3),'Invalid case/model index.');
pathIndex=ceil(caseIndex/2);loadIndex=mod(caseIndex-1,2)+1;
settings=p;settings.pathType=p.pathNames{pathIndex};
settings.cable=struct('fits',fits,'scale',p.loadScales(loadIndex),'modelIndex',modelIndex);
end
