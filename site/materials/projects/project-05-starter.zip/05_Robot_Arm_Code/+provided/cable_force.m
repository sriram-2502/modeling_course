function force = cable_force(velocity,fits,modelIndex)
% CABLE_FORCE Low-load signed force; lambda scaling occurs outside this helper.
switch modelIndex
    case 1
        force=interp1(fits.velocity,fits.force,velocity,'linear','extrap');
    case 2
        force=-fits.linearDamping*velocity;
    case 3
        force=student.nonlinear_force(velocity,fits.nonlinear);
    otherwise
        error('robot:ForceModel','Force model must be 1, 2 or 3.');
end
assert(isequal(size(force),size(velocity)) && all(isfinite(force),'all'), ...
    'Cable force must be finite and the same size as velocity.');
end
