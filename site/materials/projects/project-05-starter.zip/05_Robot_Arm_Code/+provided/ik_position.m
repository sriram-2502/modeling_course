function [q,info] = ik_position(model,target,seed)
% IK_POSITION Position-only damped least squares. No toolbox is required.
% Preserve the previous seed to keep the redundant arm's branch continuous.
q=seed(:);target=target(:);tol=5e-6;
for iteration=1:80
    [x,~,J]=provided.fk(model,q);e=target-x;
    if norm(e)<tol,break;end
    dq=J'*((J*J'+1e-7*eye(3))\e);
    dq=dq*min(1,0.12/max(norm(dq),eps));
    accepted=false;
    for alpha=[1 .5 .25 .125 .0625]
        trial=min(max(q+alpha*dq,model.lower'+1e-5),model.upper'-1e-5);
        next=provided.fk(model,trial);
        if norm(target-next)<norm(e),q=trial;accepted=true;break;end
    end
    if ~accepted,break;end
end
x=provided.fk(model,q);
info=struct('error_m',norm(target-x),'iterations',iteration,'success',norm(target-x)<tol);
q=q';
end
