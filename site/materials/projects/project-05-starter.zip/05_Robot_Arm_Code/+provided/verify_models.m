function report = verify_models(p,data,modelFile)
% VERIFY_MODELS Independent checks: student ODE and SLX vs saved baseline CSV.
% These baseline fixtures were generated once, not fitted by students.
fits=struct('velocity',data.Velocity_mps,'force',data.CableForce_N);
saved=load(fullfile(p.folder,'demo','baseline_replay.mat'),'results');
rows=struct([]);
for caseIndex=1:2
    settings=provided.case_settings(p,fits,caseIndex,1);controller=p.profiles(1);
    numerical=provided.simulate_ode(settings,controller);
    reference=saved.results.cases(caseIndex).logs{1,1};
    candidates={numerical};labels="ODE vs supplied baseline";
    if ~isempty(modelFile)
        candidates{2}=provided.simulate_model(modelFile,settings,controller);
        labels(2)="Simulink vs supplied baseline";
    end
    for k=1:numel(candidates)
        L=candidates{k};dx=max(abs(L.position-reference.position),[],'all');
        dv=max(abs(L.velocity-reference.velocity),[],'all');
        rows=[rows;struct('Case',caseIndex,'Comparison',labels(k), ...
            'MaxPositionDifference_m',dx,'MaxVelocityDifference_mps',dv, ...
            'Pass',dx<1e-5 && dv<1e-4)]; %#ok<AGROW>
    end
end
report=struct2table(rows);disp(report);
writetable(report,fullfile(p.outputFolder,'verification_metrics.csv'));
assert(all(report.Pass),'robot:Verification', ...
    'Model check failed. Inspect signs, actual-speed feedback, force limit, initial states and log order.');
end
