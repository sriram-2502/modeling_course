function fig = plot_data(p)
% PLOT_DATA Nonlinear supplied curve only; no fitted or completed student model.
data=readtable(fullfile(p.dataFolder,'cable_force_velocity.csv'));
fig=figure('Name','Supplied cable-force data','Color','w','Position',[80 80 900 440]);
for k=1:2
    ax=subplot(1,2,k);plot(ax,data.Velocity_mps,p.loadScales(k)*data.CableForce_N, ...
        'Color',[.32 .18 .50],'LineWidth',2);grid(ax,'on');pbaspect(ax,[1 1 1]);
    xlabel(ax,'Actual sliding velocity (m/s)');ylabel(ax,'Signed force on robot (N)');
    title(ax,sprintf('%s load: lambda = %g',p.loadNames{k},p.loadScales(k)));
end
end
