function parameters = fit_nonlinear(velocity,force)
% TASK 1a: choose and identify ONE nonlinear cable-force approximation.
% INPUTS: velocity [N x 1], m/s; force [N x 1], N, FIT rows only.
% OUTPUT: parameters, a scalar struct containing everything needed by
%         student.nonlinear_force. Choose its field names and document units.
% 1. Choose a representation; justify it from the data, not coefficient count.
% 2. Identify its coefficients using FIT rows only.
%    Base MATLAB tools include fminsearch, polynomial tools and interpolation.
% 3. Check zero-speed force, force sign, and behavior between/outside samples.
% 4. Return a self-contained struct. No file reads or held-out data here.
% No particular nonlinear formula is prescribed or supplied.
error('robot:TODO','Task 1a: complete student.fit_nonlinear.');
end
