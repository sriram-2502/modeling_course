function b = fit_linear(velocity,force)
% TASK 1a: identify the zero-intercept linear model F(v) = -b*v.
% INPUTS: velocity [N x 1], m/s; force [N x 1], N, FIT rows only.
% OUTPUT: b, one finite nonnegative scalar, N s/m.
% 1. State the least-squares objective for signed measured force.
% 2. Find the coefficient using base MATLAB matrix/vector operations.
% 3. Check units and the resistance sign; do not add an offset.
% The supplied workflow keeps validation rows out of this function.
error('robot:TODO','Task 1a: complete student.fit_linear.');
end
