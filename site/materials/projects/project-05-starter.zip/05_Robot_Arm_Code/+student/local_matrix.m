function A = local_matrix(virtualMass,K,D,loadScale,forceSlope)
% TASK 1c: local tracking-error matrix along the fixed cable direction.
% INPUTS: virtualMass [kg], K [N/m], D [N s/m], loadScale [-],
% forceSlope = dF/dv at the chosen actual sliding speed [N s/m].
% OUTPUT: A [2 x 2], for perturbations [delta e; delta e_dot], e=x-x_d.
% 1. Derive the unsaturated tracking-error equation first.
% 2. Linearize the signed cable force about the chosen operating speed.
% 3. Collect the two first-order perturbation equations into A.
% Use eig(A) to classify local modes; explain why stable poles alone do
% not establish path/timing performance when the full command is limited.
error('robot:TODO','Task 1c: complete student.local_matrix.');
end
