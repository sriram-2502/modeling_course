% STUDENT WORK -- complete these six functions, in this order.
% fit_linear       Task 1a: zero-intercept signed force approximation.
% fit_nonlinear    Task 1a: identify your chosen nonlinear force model.
% nonlinear_force Task 1a: evaluate that model for arbitrary signed speeds.
% tool_rhs        Task 1b: six first-order tool-motion equations.
% build_model     Task 1b: complete the supplied independent Simulink model.
% local_matrix    Task 1c: local tracking-error perturbation matrix.
% Tasks 2a--2c: choose tunedK/tunedD in project_settings; interpret metrics,
% compare predictions and recommend a design in your report.
