function stateRate = tool_rhs(time,state,p,controller)
% TASK 1b: convert the boxed second-order equation to six first-order ODEs.
% INPUTS: time in s; state = [x;y;z;vx;vy;vz], a 6 x 1 column.
% p contains the fixed experiment, selected path and cable model.
% controller.stiffness = K (N/m); controller.damping = D (N s/m).
% OUTPUT: stateRate [6 x 1] = [velocity; acceleration].
%
% Useful supplied interfaces (all Cartesian vectors below are 1 x 3 ROWS):
% [xd,vd,ad] = provided.reference(time,p);
% lowForce = provided.cable_force(slidingSpeed,p.cable.fits,p.cable.modelIndex);
% applied = provided.limit_force(requested,p.commandForceLimit);
%
% 1. Unpack actual position and velocity from state.
% 2. Evaluate the supplied desired motion at THIS time.
% 3. Form the requested virtual command from errors and feedforward.
% 4. Apply the supplied per-axis force budget using limit_force.
% 5. Project ACTUAL velocity onto p.cableDirection. Evaluate low-load
%    force, then multiply by p.cable.scale and the cable direction.
% 6. Use force balance with p.virtualMass; return a column derivative.
% Do not substitute desired velocity into the cable law.

%% Supplied unpacking: row vectors match the reference helper's outputs.
position = state(1:3)';
velocity = state(4:6)';
[desiredPosition,desiredVelocity,desiredAcceleration] = provided.reference(time,p);
K = controller.stiffness;
D = controller.damping;

%% Your work: command, applied force, cable feedback and six derivatives.
error('robot:TODO','Task 1b: complete student.tool_rhs.');
end
