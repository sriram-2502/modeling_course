function force = nonlinear_force(velocity,parameters)
% TASK 1a: evaluate YOUR nonlinear force law on robot, at LOW load.
% INPUTS: velocity, scalar/vector/array in m/s; parameters from fit_nonlinear.
% OUTPUT: force in N, same size as velocity, finite for tested speeds.
% 1. Read your chosen coefficient fields from parameters.
% 2. Evaluate your model using elementwise operations where needed.
% 3. Document extrapolation. Do not silently clamp velocity to CSV bounds.
% Resistance should satisfy force.*velocity <= 0.
% Do not multiply by lambda here: the supplied workflow does that once.
error('robot:TODO','Task 1a: complete student.nonlinear_force.');
end
