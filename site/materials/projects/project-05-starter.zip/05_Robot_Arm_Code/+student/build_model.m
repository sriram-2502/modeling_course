function modelFile = build_model(p)
% TASK 1b: complete and SAVE your independent standard-block Simulink model.
% Run open_student_model first. It creates the scaffold only when missing;
% it never overwrites an existing SLX. Wire the blocks in Simulink and save.
% INPUT: fixed settings p. OUTPUT: full path of your completed SLX.
% Required model I/O, variable names and wiring hints are in the PDF guide.
% 1. Build vector command, force limit, actual-velocity cable feedback and
%    two vector integrators. Keep the supplied state logger unchanged.
% 2. Set the initial position to startPosition and initial velocity to zeros.
% 3. Save models/robot_arm_student.slx, then remove the TODO error below.
% This function returns the file; it does not replace your model with a solution.
modelFile = fullfile(p.modelFolder,'robot_arm_student.slx');
error('robot:TODO','Task 1b: wire/save the SLX, then finish student.build_model.');
assert(isfile(modelFile),'Save your Simulink model before continuing.');
end
