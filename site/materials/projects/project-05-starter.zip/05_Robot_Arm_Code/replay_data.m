%% REPLAY DATA: supplied baseline CSV-reference runs, no student code needed.
projectFolder = fileparts(mfilename('fullpath')); addpath(projectFolder);
saved = load(fullfile(projectFolder,'demo','baseline_replay.mat'),'results');
replayFigure = provided.replay(saved.results);
