function p = project_settings
% PROJECT_SETTINGS Fixed experiment and the ONE controller you will tune.
% Units are SI. Change only tunedK and tunedD for the required comparison.
p.folder = fileparts(mfilename('fullpath'));
p.dataFolder = fullfile(p.folder,'data');
p.modelFolder = fullfile(p.folder,'models');
p.outputFolder = fullfile(p.folder,'results');

%% Your design: replace NaN with positive numbers after the baseline works.
tunedK = NaN;                         % virtual stiffness, N/m
tunedD = NaN;                         % virtual damping, N s/m
p.profiles = struct('name',{'Baseline','Your design'}, ...
    'stiffness',{35,tunedK},'damping',{7,tunedD});

%% Supplied virtual tool and cable: keep these fixed.
p.virtualMass = 0.35;                 % M_v, virtual mass; not arm link mass
p.commandForceLimit = 0.8;            % N per world axis
p.cableDirection = [0 1 0];           % d, row vector; fixed world Y
p.loadNames = {'Low','High'};
p.loadScales = [1 11];                % lambda
p.fitNames = {'CSV reference','Linear fit','Nonlinear fit'};

%% Supplied paths, timing and logging: keep fixed.
p.pathNames = {'Straight','Arc','S-curve'};
p.duration = 10; p.dt = 0.02; p.inputDt = 0.0005;
p.moveWindow = [0.5 8];               % scoring window AND traversal window
p.targetOffset = [-0.07 0.08 0];      % chord displacement, m
p.arcAngle = pi/2;
p.arcNormal = [0.08 0.07 0]/norm([0.08 0.07 0]);
p.home = [0 -0.45 0.85 0.30 0];      % supplied visualization pose, rad
p.initialOffset = [0 -0.003 0];       % 3 mm initial error, approximately

%% Supplied evaluation: both errors must satisfy each band's limits.
p.pathTolerance = 0.004; p.timedTolerance = 0.005;
p.evaluation = struct('goodPath',0.002,'goodTimed',0.003, ...
    'acceptablePath',0.004,'acceptableTimed',0.005);
p.showAnimation = true;              % desktop replay after a full run
p.scenario = 'Seam tracing with nonlinear cable-guide resistance';
end
