%% ANIMATE RESULTS: replay your saved simulations without running a solver.
projectFolder = fileparts(mfilename('fullpath')); addpath(projectFolder);
archive = fullfile(projectFolder,'results','project_results.mat');
if ~isfile(archive)
    fprintf('No completed results yet. Showing the supplied baseline replay.\n');
    replay_data;
else
    saved = load(archive,'results');
    replayFigure = provided.replay(saved.results);
end
