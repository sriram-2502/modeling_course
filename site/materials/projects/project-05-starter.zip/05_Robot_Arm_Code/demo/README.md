# Baseline observation and verification data

`baseline_replay.mat` contains ONLY the six supplied CSV-reference baseline
runs, using K=35 N/m and D=7 N s/m. No tuned controller, fitted nonlinear
coefficients, analytical force generator or completed student function is included.
The companion `baseline_case_01.csv` through `06.csv` contain the same
time/desired position/actual position/actual velocity records in SI units.
Order: straight low/high, arc low/high, S-curve low/high.

These are saved simulations, not measured robot logs. `replay_data` animates
them before any TODO is completed. Verification compares your baseline ODE
and SLX with cases 1/2, preserving the initial geometry/IK offset exactly.
The supplied baseline can fail the tracking bands; it is an observation,
not a recommended design. A verification pass checks implementation agreement.
