# Your generated results

`run_checkpoint` returns in-memory outputs. The ODE/Simulink checks also write
`verification_metrics.csv`; the fits checkpoint exports fit figures.
`run_project` saves the complete `project_results.mat`, 36 state/force CSVs,
performance/fit metrics and summary figures. A later full run overwrites files
with the same names. Copy a study before running a different tuned design if
you want to retain both. No student answers are pre-populated in this folder.
