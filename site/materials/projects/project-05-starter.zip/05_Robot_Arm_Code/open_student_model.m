%% OPEN STUDENT MODEL: prepare a baseline test without completing any fit.
projectFolder=fileparts(mfilename('fullpath'));addpath(projectFolder);
[p,~,data]=provided.load_project;
fits=struct('velocity',data.Velocity_mps,'force',data.CableForce_N);
settings=provided.case_settings(p,fits,1,1); % straight / low / CSV / baseline
modelFile=provided.create_scaffold(p);      % creates ONLY if missing
values=provided.model_variables(settings,p.profiles(1));
names=fieldnames(values);
for k=1:numel(names),assignin('base',names{k},values.(names{k}));end
open_system(modelFile);
fprintf('Wire the blocks, save the SLX, then complete student.build_model.\n');
fprintf('Do not rename variables or tipStates. See PDF guide for vector sizes.\n');
