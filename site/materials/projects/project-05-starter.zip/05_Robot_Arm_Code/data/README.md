# Cable-force data

`cable_force_velocity.csv` is instructor-generated synthetic teaching data.
It is not a real robot/cable measurement or evidence of damaged motors.
Velocity is signed sliding speed (m/s); force is signed LOW-load force on
the robot (N). Positive speed therefore has negative resistance force.

Use rows labeled `fit` to identify models and rows labeled `validation`
only to assess force errors. The full CSV, linearly interpolated with
endpoint-segment extrapolation, defines the simulation reference.
Multiply force by lambda = 1 or 11 outside the low-load force function.

The full-CSV reference is a benchmark, not an independent experimental
validation dataset. Its exact zero at sampled speeds is not a fitted-model score.
