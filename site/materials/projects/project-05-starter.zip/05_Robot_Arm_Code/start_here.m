%% START HERE: observe supplied data before building a model.
projectFolder = fileparts(mfilename('fullpath'));
addpath(projectFolder);              % Do not use genpath on package folders.
fprintf('\nProject 05: robot-arm seam tracking\n');
fprintf('1. Watch this baseline replay; rotate/zoom the 3-D view.\n');
fprintf('2. Read README.md and docs/student_code_guide.pdf.\n');
fprintf('3. Run run_checkpoint with no input to list the next steps.\n');
fprintf('No student function is called by this starting replay.\n\n');
provided.plot_data(project_settings);
replay_data;
