# Supplied drawing geometry

The numeric mesh/kinematic cache `robot_geometry.mat` is derived from
TheRobotStudio robot-arm assets, commit recorded in `provenance.json`.
Source: https://github.com/TheRobotStudio/SO-ARM100/tree/main/Simulation/SO101
The upstream Apache 2.0 license is included as `LICENSE`. Provenance lists
the original source files; the student distribution uses only the derived
numeric cache and requires no URDF importer or robotics toolbox.

This cache supplies visualization and IK, not measured tool dynamics.
