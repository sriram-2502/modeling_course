function output = run_checkpoint(stage)
% RUN_CHECKPOINT Work incrementally; no stage secretly completes a TODO.
% With no input, list stages. Each stage returns output for inspection.
if nargin==0
    fprintf(['data       supplied nonlinear curve and fixed settings\n' ...
        'linear     your zero-intercept fit\n' ...
        'fits       both fits and held-out errors\n' ...
        'ode        your ODE vs two saved baseline runs (no fit needed)\n' ...
        'stability  your local matrix, baseline/low load at zero speed\n' ...
        'simulink   ODE and SLX vs saved low/high baseline (no fit needed)\n' ...
        'final      fit, verify, run all 36 cases; returns results\n']);
    output=[];return
end
[p,model,data]=provided.load_project;
switch string(stage)
    case "data"
        provided.plot_data(p);output=struct('settings',p,'data',data);return
    case "linear"
        rows=data.Split=="fit";
        output=student.fit_linear(data.Velocity_mps(rows),data.CableForce_N(rows));
        fprintf('Your linear damping: %.6g N s/m\n',output);return
    case "fits"
        output=provided.fit_models(data);provided.plot_cable_fits(p,output,data);
        disp(output.metrics);return
    case "ode"
        output=provided.verify_models(p,data,[]);return
    case "stability"
        % A central CSV slope is supplied for this ONE check, not all analysis.
        step=0.001;F=@(v)interp1(data.Velocity_mps,data.CableForce_N,v,'linear');
        slope=(F(step)-F(-step))/(2*step);
        A=student.local_matrix(p.virtualMass,35,7,1,slope);
        assert(isequal(size(A),[2 2])&&all(isfinite(A),'all'),'Return a finite 2 x 2 A.');
        output=struct('operatingSpeed_mps',0,'forceSlope_Nspm',slope,'A',A,'poles',eig(A));
        disp(output);return
    case "simulink"
        modelFile=student.build_model(p);
        output=provided.verify_models(p,data,modelFile);return
    case "final"
        fits=provided.fit_models(data);provided.plot_cable_fits(p,fits,data);
        gains=[p.profiles.stiffness p.profiles.damping];
        assert(all(isfinite(gains)&gains>0),'robot:Design', ...
            'Choose finite positive tunedK/tunedD in project_settings.m.');
        modelFile=student.build_model(p);
        verification=provided.verify_models(p,data,modelFile);
        output=provided.run_study(p,model,fits,modelFile);output.verification=verification;
    otherwise
        error('robot:Checkpoint','Unknown checkpoint. Run run_checkpoint with no input.');
end
end
