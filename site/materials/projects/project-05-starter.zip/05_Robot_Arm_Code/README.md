# Project 05: robot-arm seam tracking

Open **this folder** as MATLAB's current folder and run **`start_here`**.
The supplied nonlinear force curve and an interactive baseline replay work
before you complete any student function. Try the six path/load cases. Drag
the 3-D scene to rotate it; use the camera menu or toolbar to see the seam.

The baseline is intentionally imperfect. Your question is: **how do stiffness,
damping and the cable-force model affect the resulting closed-loop tracking,
timing and stability?** You study the supplied closed-loop structure rather
than develop a new control law.

Read **[the project handout](docs/05_Robot_Arm_Seam_Tracking.pdf)** and
**[the student code guide](docs/student_code_guide.pdf)**.
The guide explains the model, every function's inputs/outputs, Simulink
variables, evaluation, and how each code step supports the tasks.

## What you receive and what you build

| Supplied; use unchanged | Your work |
|---|---|
| Synthetic signed cable-force CSV, with fit/validation labels | Choose and identify linear and nonlinear force models (1a) |
| Desired position, velocity and acceleration for three seams | Derive and implement the six-state ODE (1b) |
| Unwired standard-block Simulink scaffold | Wire/save an independent block model (1b) |
| Baseline replay and low/high verification records | Derive a local perturbation matrix and interpret modes (1c) |
| Six-case runner, complete metrics, bands and CSV export | Tune one K,D pair and evaluate it across all six cases (2a) |
| Identical model-comparison machinery | Explain prediction differences and resulting behavior (2b, 2c) |
| Robot geometry, numerical IK, interactive replay | Interpret results; no robot importer or animation code needed |

All six unfinished functions are in `+student`. They stop deliberately with
`robot:TODO`. Read the contract and numbered steps, implement your answer,
then remove its TODO error. `run_project` is expected to stop until you
finish the relevant functions. No arbitrary nonlinear force formula or
successful tuned-gain answer is supplied.

## Work in this order

| Step | Edit / inspect | Run in the Command Window |
|---|---|---|
| 1 | Supplied data, baseline replay, handout | `start_here` |
| 2 | `+student/fit_linear.m` | `b = run_checkpoint("linear")` |
| 3 | `fit_nonlinear.m`, `nonlinear_force.m` | `fits = run_checkpoint("fits")` |
| 4 | `tool_rhs.m` | `checks = run_checkpoint("ode")` |
| 5 | Wire/save the SLX; finish `build_model.m` | `open_student_model`, then `run_checkpoint("simulink")` |
| 6 | `local_matrix.m`; written stability analysis | `modes = run_checkpoint("stability")` |
| 7 | `tunedK`, `tunedD` in `project_settings.m` | `run_project` |
| 8 | Saved results and the report | `animate_results` |

ODE and Simulink checkpoints use the **supplied CSV law and baseline gains**,
so you can build/check the dynamics before finishing either force fit or
choosing tuned gains. The stability checkpoint is one baseline/low-load check
at zero speed; select additional operating conditions for your report.
`run_checkpoint` with no input lists the stages.

## The model in plain language

`x` is the actual tool position in the fixed world frame, not a joint angle.
`xd`, `vd`, `ad` are supplied desired position, velocity, acceleration.
The prescribed virtual mass `p.virtualMass = 0.35` kg is a controller-model
choice, not the mass of the physical robot. You choose positive virtual
stiffness `K` and damping `D`, shared by X/Y/Z, using the same pair in all six
experiments. Keep the reference timing and the other conditions unchanged.

The cable sees **actual** sliding speed `vc = v*d'`, with `d = [0 1 0]`.
Its signed low-load force is negative for positive speed. Multiply this force
by `lambda = 1` or `11` and by the direction vector once. `+provided/limit_force`
applies the fixed virtual command-force budget; use the matching Saturation
block in Simulink. The cable force is added after this command limit.

Your ODE state is a **6-by-1 column** `[x;y;z;vx;vy;vz]`. Reference and log
helpers return **N-by-3 rows**; transpose carefully. `K,D` are software virtual
tool gains. No physical arm inertia, actuator friction, thermal welding or
contact-quality model is identified here.

## Folders and software

Use base MATLAB plus standard Simulink. No Robotics System, Control System,
Optimization, Curve Fitting, System Identification or Simscape toolbox is
required. A Simulink license is needed to edit/run the model; baseline replay,
fitting, ODE integration and metrics use MATLAB. Internet is not needed.

Keep `+student`, `+provided`, `data`, `assets`, `demo`, `models` and `results`
beside the entry scripts. Add only this root to the path; do not use `genpath`
or add package folders directly. Use a fresh MATLAB session when switching
between course projects with the same `student`/`provided` package names.

- `data/`: signed low-load force samples and split rules.
- `demo/`: six saved baseline simulations, also exported as readable CSVs.
- `models/robot_arm_student.slx`: deliberately unconnected scaffold.
- `assets/`: numeric drawing geometry and upstream attribution/license.
- `results/`: your generated outputs, initially just a README.
- `docs/`: this workflow explained in PDF/LaTeX and a replay preview.

## What the full run does

`run_project` checks your local matrix, fits the force models, verifies your ODE and SLX against supplied baseline
records, then runs **36 Simulink simulations**: 3 paths x 2 loads x 3 force
laws x 2 controllers. All comparisons use your **one saved SLX**, with new
inputs/parameters, rather than 36 hand-built models. It saves:

- `project_results.mat`: complete simulation results for replay.
- `performance_metrics.csv`: 36 rows of scores and diagnostics.
- `force_fit_metrics.csv`: fit/validation errors for the two fitted laws.
- `verification_metrics.csv`: ODE/SLX comparison with saved baseline records.
- `case_01_model_1_gain_1.csv` through the 36 case/model/gain combinations.
- Fit, seam-path and prediction-comparison figures.

The filename indices are case **1--6** = straight low/high, arc low/high,
S-curve low/high; model **1--3** = CSV, linear, nonlinear; gain **1--2** =
baseline, your design. CSV state/joint values use SI units; metric columns
ending `_mm` use millimeters.

`run_checkpoint("final")` returns the verified 36-run structure but does
not save the full archive. `run_project` saves it. Checkpoints can export
verification/fit files as noted in `results/README.md`. Repeated full runs
overwrite the same output names; copy a study if you want to preserve it.
The full runner does not write your stability explanation or recommendation.

## Read the evaluation correctly

Only **0.5--8 s** counts for the tracking bands. Both limits must hold:

| Band | Peak distance to the geometric seam | Peak distance to desired timed position |
|---|---:|---:|
| Good | <= 2 mm | <= 3 mm |
| Acceptable | <= 4 mm | <= 5 mm |
| Needs improvement | Either Acceptable limit is exceeded | |

Path error measures distance to the finite seam regardless of timing. Timed
error also detects falling behind on that seam. `PredictionRMSE_mm` compares
each fitted-law trajectory against the **matching CSV-law run with the same
gains**, over all 10 s. It is not a tracking score. Fit RMSE has force units
(N), not position units. Saturation time, final error and speed outside CSV
range are separate diagnostics. Bands are not grades or welding standards.

Simulink verification requires maximum component position difference below
1e-5 m and velocity difference below 1e-4 m/s. These check implementation
agreement, not experimental realism. Missing/nonfinite states stop with an
error; they are not silently scored as successful runs. The baseline itself
can fail the tracking requirements while passing verification.

## Replay and limitations

`replay_data` always uses supplied baseline logs. `animate_results` uses your
saved archive if available, otherwise the baseline. No dynamics or fitting
reruns during replay. For your saved Cartesian trajectories, the supplied
numerical IK first prepares drawing poses for the selected case/model.
Joint-angle columns in simulation CSVs are intentionally NaN: drawing poses
are prepared only in replay memory and do not rewrite the CSVs.
The Cartesian simulation/evaluation does not use IK.
The baseline CSV-law trajectory is the reference, not a measured ground truth.

If an extreme design moves outside the drawable workspace, replay explains
the issue; the numerical tracking results remain available. The robot drawing
does not validate torque feasibility. Your final report must discuss modeling
limits, explain gain choices, and answer the conceptual looking-ahead prompt.

Task 2c also asks a conceptual extension to process-contact forces: propose the added force term, choose sensors for force and tool/workpiece motion, and explain how measurements would distinguish cable/contact effects and update contact-model parameters. No additional simulation or controller is required.

The assets originate from TheRobotStudio; see `assets/README.md` and LICENSE.

