function p = project_settings()
% Fixed settings shared with the instructor solution. Do not tune on F3/D3.

% Time and preprocessing (the supplied CSVs are already processed).
p.dt = 0.02;                 % Sample interval, seconds
p.filterTau = 0.12;          % Applied filter time constant, seconds
p.scoreStart = 0.4;          % Predict from zero; score from this time, seconds
p.commandThreshold = 0.05;   % Original input-based crop threshold, m/s
p.tail = 2;                  % Seconds kept after the last active command

% Parameter order:          K     zeta    omega_n (rad/s)
p.lower =                 [0.2   0.15     0.4];
p.upper =                 [1.5   5       30];
p.starts = [0.9  0.7   6;    % Each row is a different initial guess
            0.9  1.5   3;
            0.8  3     2;
            1.0  0.4  15];

% Suggested limits for fminsearch (base MATLAB).
p.maxIter = 700;
p.maxEvals = 1400;

% Matching thresholds: [speed RMSE, absolute bias, displacement], percent.
% Every threshold must pass. These are descriptive bands, not report grades.
p.good = [15 5 10];
p.acceptable = [30 10 20];
p.bandVersion = 'v1_2026_10_20';
end
