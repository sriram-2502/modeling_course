% Student default: explore supplied logs before implementing any TODO.
folder=fileparts(mfilename('fullpath'));addpath(folder);
animationFigure=provided.animate_saved_results(folder,struct('InitialMode','logged','IncludeFinalTests',false));
