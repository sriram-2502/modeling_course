Your generated results go here. No fitted answers are distributed.
Run replay_data or animate_results immediately to explore supplied logs: no results needed.
After completing the student functions and freezing method choices, run run_project.
Then animate_model_results compares your saved prediction CSVs with the logged data.
