PROJECT 04 -- FROZEN GO1 DATA CONTRACT

Source: instructor-supplied Unitree Go1 walking experiments.
flat_walk_01.csv through flat_walk_03.csv: flat-ground recordings (F1-F3).
debris_walk_01.csv through debris_walk_03.csv: debris recordings (D1-D3).
manifest.csv assigns fixed training, validation and final-test roles.
The logged desired forward speed is the input; estimated forward speed is the target.
The instructor retains original recording identifiers in a separate provenance map.
These are logged command/state-estimate channels, not motion-capture truth.
No body/world rotation is applied. This is a nominal straight-motion channel
model, not a verified 3-D physical coordinate/force-identification model.
Selected runs have modest yaw variation; yaw and lateral speed are supplied
for checking the straight-motion assumption. Controller GRF outputs are NOT
measured external forces and are not used to identify physical mass/inertia.

SPLIT (by whole run, fixed before student fitting)
F1 / D1: training. F2 / D2: development validation. F3 / D3: final held-out tests.
Fit the flat baseline using only F1 and the adapted model using only D1.
Instructor dataset-design pilots have inspected all runs. Student final-test
claims require freezing the method/parameters before inspecting final errors.

FIXED PREPROCESSING
1. Check finite states and strictly increasing actual timestamps.
2. Set source t=0 at the first record.
3. Keep from start until min(original end, last desired vx>0.05 m/s + 2 s).
   This input-only cropping rule preserves stopping behavior and applies to all runs.
4. At original timestamps, causal first-order low-pass command and velocity
   separately with the SAME tau=0.12 s and a=exp(-delta_t/tau):
   filtered[n]=a*filtered[n-1]+(1-a)*raw[n]. First filtered sample=first raw sample.
5. Interpolate to 0.02 s using linear interpolation. No output beyond source support.
6. Comparison displacement=trapezoidal integral of filtered logged speed from zero.
7. Model input is the supplied filtered command with zero-order hold between samples.
8. Initial model states=[first filtered speed, 0, 0]. Score t>=0.4 s through CSV end.

CSV COLUMNS
Time_s, CommandRaw_mps, SpeedRaw_mps: raw channels resampled to 50 Hz, NOT full-rate originals.
LoggedX_m: logged x-position minus its first value; separate estimator sanity check.
Pitch_rad, Yaw_rad, LateralSpeed_mps: context channels, not modeled outputs.
Command_mps, Speed_mps: identically filtered input/output used for fitting and scoring.
IntegratedX_m: integral of Speed_mps; the displacement reference used by metrics/replay.
LoggedX_m and IntegratedX_m need not agree; do not grade their difference as model error.
Filtering changes the prediction target: this project models averaged forward motion,
not individual gait oscillations. Keep raw channels in plots to acknowledge this limitation.

METRICS AND BANDS
Time-weighted RMSE and signed mean bias use filtered speed, t>=0.4.
Speed normalization=max(RMS(command),0.10 m/s).
Displacement normalization=max(integral(abs(filtered speed)) over score window,0.50 m).
Good: normalized speed RMSE<=15%, absolute bias<=5%, displacement error<=10%.
Acceptable: all <=30%,10%,20%. Otherwise Needs improvement; incomplete/nonfinite=Invalid.
All three limits must pass. These are course-specific descriptive bands, not grades,
statistical confidence intervals, or a claim of irreducible sensor noise.
Displacement drift integrates speed error; it is not independent position ground truth.

provenance_audit.json stores source/CSV SHA256 and an independent decoder/filter check.
processing.csv records fixed settings. Do not overwrite data while fitting.
