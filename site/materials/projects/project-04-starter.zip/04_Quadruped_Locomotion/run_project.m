%% PROJECT 04: predict forward walking speed
% FIRST TIME? Run start_here instead. It works before you write any code.
% Complete the six functions in +student using the checkpoints in README.md.
% Run this full script AFTER choosing your method using F2/D2 validation.

%% 1. Load the supplied data and fixed settings
projectFolder = fileparts(mfilename('fullpath'));
addpath(projectFolder);

results = provided.load_project(projectFolder);
settings = results.p;

flatTrainingRun = provided.get_run(results, "F1");
debrisTrainingRun = provided.get_run(results, "D1");

%% 2. Task 1b: locate your completed Simulink model
% Build and save the plant first; use open_student_model to edit it.
results.model = student.build_model(settings);

%% 3. Tasks 1c and 2b: fit the SAME model family to each training run
% Parameter order everywhere: [K, zeta, omega_n].
[flatParameters, flatTrials] = student.fit_parameters(flatTrainingRun, settings);
[debrisParameters, debrisTrials] = student.fit_parameters(debrisTrainingRun, settings);

parameters = [flatParameters; debrisParameters];
provided.check_parameters(parameters, settings);

results.flatTrials = flatTrials;
results.debrisTrials = debrisTrials;
results.flatModes = student.analyze_modes(flatParameters);
results.debrisModes = student.analyze_modes(debrisParameters);

%% 4. Tasks 2a and 2b: predict and score the six runs
% Evaluation and numerical integration are supplied. They use YOUR matrices.
% This includes final tests F3/D3: freeze your method before this full run.
results = provided.evaluate_models(results, parameters);
results.verification = provided.verify_model(results);

%% 5. Tasks 2b and 2c: compare the evidence and explain your decision
results.comparison = student.compare_models(results.metrics);
results.decision = student.recommend(results.metrics, results.comparison);

%% 6. Save your work and inspect the results
provided.save_results(results);
provided.plot_results(results);

disp(results.metrics);
disp(results.comparison);
disp(results.decision);
disp('Saved. Run animate_model_results to compare your model with the logs.');
