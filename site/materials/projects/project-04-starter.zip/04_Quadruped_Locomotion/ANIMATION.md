# Explore first, then predict

1. Run `replay_data` (or student `animate_results`) immediately after extraction.
   It animates supplied logged speed integrals, with command, speed, progress,
   and tracking error plots. No fitted model, result files or Simulink needed.
2. Explore F1/D1 training recordings and F2/D2 validation recordings. Final tests
   are excluded from this first-look menu. Observe lag, bias and terrain differences.
3. Derive the second-order speed model, complete the independent Simulink plant,
   fit only F1/D1, and use the validation checkpoint to choose your method.
4. Freeze choices, run the complete project, then use `animate_model_results`.
   The hollow teal robot follows the logged speed integral; the solid purple
   robot follows your saved prediction. Both start together on the same track. This mode includes final tests and metrics.

Use Play/Pause, the time slider, playback speed and camera menus. The default
camera follows logged progress; global and side views are available. Export AVI
records the selected complete replay at 25 fps (independent of playback speed).
The older comparison viewer remains available as `animate_results_2d`.

Body dimensions are approximate. Leg motion is an illustrative distance-based
cycle, so it pauses when forward travel pauses. Body attitude is held level;
we do not animate measured pitch as though the speed model predicted it.
Debris is a fixed-seed smooth random height surface, not recovered terrain.
Small vertical graphics offsets put feet above that surface; they do not change
the simulated states, fitting or scores. Flat terrain stays level. The logged
wireframe and solid prediction overlay without a lateral offset, exposing drift.
Positions integrate filtered speed rather than replaying logged x directly.
Tracking error (logged minus command) differs from model error (model minus logged).

The presentation is inspired by ARCaD-Lab-UM's RF-MPC 3D robot/follow-camera and
synchronized-plot layout: https://github.com/ARCaD-Lab-UM/RF-MPC . This viewer is
an independent implementation; it does not import their solver, dynamics or code.
Only standard MATLAB graphics, timers and VideoWriter are used.

CSV names are `flat_walk_01.csv` through `flat_walk_03.csv` and
`debris_walk_01.csv` through `debris_walk_03.csv`. F1-F3 and D1-D3 remain
short task identifiers; the manifest maps them to the descriptive filenames.
