# Project 04: Go1 forward-motion modeling

Use a fresh MATLAB session when switching projects with the same package names.
Open this folder as MATLAB's current folder and run **`start_here` first**.
It launches `replay_data` and prints the next steps in the Command Window.
You will see a 3D robot replay of the supplied CSV logs immediately, even with
every TODO unfinished and no files in `results/`. Student `animate_results`
opens the same data-first view. This is a starting observation, not a fitted answer.

Compare F1 (flat) with D1 (debris). Watch command versus logged speed, lag,
tracking error and accumulated progress. Ask: **what simple model could predict
the speed from the command?** Then use the supplied second-order family,
complete the functions below, and test that idea on separate runs.

![Supplied-data replay, available before coding](docs/animation_preview.png)

Read the nine-page `docs/student_code_guide.pdf` and the project handout.
Its background page explains the effective speed model before the function contracts. Base MATLAB handles fitting, exact integration,
metrics, plotting and replay. Standard Simulink is required for your independent
block model. No identification, optimization, control or robotics toolbox is needed.

## What is provided

- Six fixed CSV runs in `data/`, including input/output, filtering and provenance.
- `project_settings.m`: fixed bounds, starting guesses and scoring rules.
- `+provided`: numerical propagator, metrics, evaluation, verification, plots,
  CSV export and saved-data animation. Numerical prediction uses your matrices;
  the initial logged-data replay is independent of every student function.
- `models/go1_forward_model.slx`: intentionally incomplete I/O scaffold.
- `run_project.m`: main workflow; checkpoints allow incremental development.
- `open_student_model.m`: opens the scaffold with example block variables ready,
  so you can edit/run Simulink before fitting any parameters.
- Fitting helpers: `provided.training_loss`, `provided.encode_parameters`, and
  `provided.decode_parameters`. You complete optimization and interpretation.

## What you complete

| Function in +student | Task | Your work |
|---|---|---|
| model_matrices | 1b | Derive the first-order model |
| build_model | 1b | Complete the independent standard-block SLX |
| fit_parameters | 1c, 2b | Fit the same family separately on F1 and D1 |
| analyze_modes | 1c | Speed poles and damping classification |
| compare_models | 2b | Quantify benefits and degradation |
| recommend | 2c | Justify shared or terrain-specific use |

Every unfinished function stops with `go1:TODO`; the initial full run is expected
to stop. Each function now has a step-by-step skeleton. Replace placeholders,
complete its TODO steps, then remove its `error('go1:TODO',...)` line.
`NaN` and empty strings are unfinished placeholders, not valid answers.
Task 1a data interpretation, Task 2a transfer analysis and the written
discussion remain your work even where evaluation machinery is supplied.

## Work in this order

| Step | Work on | Try it |
|---|---|---|
| 1 | Explore F1 and D1 | `start_here`, then `run_checkpoint("data")` |
| 2 | `model_matrices`, then `analyze_modes` | `run_checkpoint("model")` |
| 3 | Wire/save the SLX; complete `build_model` | `open_student_model`, then `run_checkpoint("simulink")` |
| 4 | `fit_parameters` | `run_checkpoint("flat")`, then `run_checkpoint("debris")` |
| 5 | Assess the method using F2/D2 | `run_checkpoint("validation")` |
| 6 | Freeze choices, then inspect final metrics | `results = run_checkpoint("final")` |
| 7 | `compare_models` and `recommend` | Use `results.metrics` to complete the table/string skeletons |
| 8 | Run and save the completed workflow | `run_project`, then `animate_model_results` |

Run `run_checkpoint` with no input to list the choices. To retain outputs, use
`results = run_checkpoint("data")`. The validation checkpoint fits only F1/D1
and scores only F2/D2, without simulating or scoring F3/D3.
The final checkpoint supplies metrics/plots without requiring your comparison or
recommendation to be finished. It returns them for inspection without saving an archive; the full runner
later saves the completed submission outputs.
The data checkpoint opens **both F1 and D1** inspection figures. Most
checkpoints only return results in memory. The `"simulink"` checkpoint also
writes `verification_F2.csv`, `verification_D2.csv` and
`verification_metrics.csv`; only `run_project` saves the complete prediction
archive. In exported filenames, `model1` means flat baseline and `model2`
means debris adapted. Save selected report figures yourself.

### Names used in the code

`student.name(...)` calls `name.m` in `+student`; keep MATLAB in the parent
folder. `trainingRun` is one run table, `settings` is the fixed configuration
struct (also stored as `results.p`), and `theta = [K,zeta,omega_n]` is one
parameter row. The optimizer changes `q`, three unconstrained coordinates;
supplied encoding/decoding helpers keep the corresponding `theta` in bounds.
`trials` records every optimization start. `results` collects the inputs and
outputs of the chosen checkpoint; only fields created by that stage exist.
Model response state columns are `[v,dv/dt,p]`, where `p` is displacement,
distinct from the settings field `results.p`.

For example, after completing matrices and fitting:

```matlab
results = run_checkpoint("flat");
disp(results.theta)
disp(results.trials)
```

A later assignment to `results` replaces the previous checkpoint output.
The PDF guide gives the full dependency checklist and function contracts.

Freeze your choices before examining F3/D3. The full runner evaluates all six
runs and both models, so do not use it to repeatedly tune on final-test results.

You normally edit **only `+student` and the SLX**. The `+provided` folder is
ready-to-use support code; you do not need to understand the animation or
numerical propagation internals to complete the tasks. Settings use the same
field names as the instructor solution; their comments explain units and order.

After a successful full run, use **`animate_model_results`** to compare your
saved predictions with logged progress, or `plot_saved_results` for static plots.
Initial replay excludes F3/D3; the post-freeze comparison includes them.
The hollow teal logged robot overlays the solid purple model on the same track.
Debris is a repeatable illustrative rough surface. The 3D viewer has
follow/global/side cameras, synchronized plots and AVI export.
`animate_results_2d` preserves the old viewer. See `ANIMATION.md` for controls.
Leg motion and debris geometry are illustrative, not measured gait or terrain.
Submit your code, SLX and generated CSVs with the report. Relative paths make
the folder portable. Do not require the original binary logs or instructor files.

Input files use descriptive names: `flat_walk_01.csv` to `flat_walk_03.csv`,
and `debris_walk_01.csv` to `debris_walk_03.csv`. The manifest keeps the short
F1-F3/D1-D3 task IDs and their fixed roles.
