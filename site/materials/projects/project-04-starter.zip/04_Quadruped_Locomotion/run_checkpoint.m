function results = run_checkpoint(stage)
% RUN_CHECKPOINT Try one part before running the complete project.
%   run_checkpoint                  list the available checkpoints
%   run_checkpoint("data")          inspect input and output (no TODO needed)
%   run_checkpoint("replay")        animate supplied logs (no TODO needed)
%   run_checkpoint("model")         check matrices and mode analysis
%   run_checkpoint("simulink")      compare independent implementations
%   run_checkpoint("flat")          fit F1 only
%   run_checkpoint("debris")        fit D1 only
%   run_checkpoint("validation")    fit F1/D1; score ONLY F2/D2
%   run_checkpoint("final")         AFTER method freeze: get all metrics/plots
%
% To keep the returned data: results = run_checkpoint("data").

projectFolder = fileparts(mfilename('fullpath'));
addpath(projectFolder);
results = provided.load_project(projectFolder);
settings = results.p;

if nargin == 0
    help run_checkpoint
    return
end

switch lower(string(stage))
    case "data"
        disp(results.manifest);
        show_data(provided.get_run(results, "F1"), "F1: flat training");
        show_data(provided.get_run(results, "D1"), "D1: debris training");

    case "replay"
        options = struct('InitialMode', 'logged', 'IncludeFinalTests', false);
        results.figure = provided.animate_saved_results(projectFolder, options);

    case "model"
        exampleParameters = [1 0.8 6]; % Diagnostic fixture, not fitted values
        [A, B] = student.model_matrices(exampleParameters);

        assert(isequal(size(A), [3 3]), 'A must be 3-by-3.');
        assert(isequal(size(B), [3 1]), 'B must be 3-by-1.');
        assert(all(isfinite([A(:); B(:)])), 'Replace every NaN in A and B.');

        flatRun = provided.get_run(results, "F1");
        results.response = provided.simulate_model(exampleParameters, flatRun, settings);
        results.modes = student.analyze_modes(exampleParameters);
        disp(results.modes);

    case "simulink"
        exampleParameters = [1 0.8 6];
        sameParametersForBoth = [exampleParameters; exampleParameters];

        results = provided.evaluate_models(results, sameParametersForBoth, ["F2", "D2"]);
        results.model = student.build_model(settings);
        results.verification = provided.verify_model(results);

    case {"flat", "debris"}
        if lower(string(stage)) == "flat"
            trainingRun = provided.get_run(results, "F1");
        else
            trainingRun = provided.get_run(results, "D1");
        end

        [results.theta, results.trials] = student.fit_parameters(trainingRun, settings);
        disp(results.theta);
        disp(results.trials);

    case {"validation", "final"}
        if lower(string(stage)) == "final"
            disp('Final evaluation: use only after freezing your method on F2/D2.');
        end
        flatRun = provided.get_run(results, "F1");
        debrisRun = provided.get_run(results, "D1");
        [flatParameters, results.flatTrials] = student.fit_parameters(flatRun, settings);
        [debrisParameters, results.debrisTrials] = student.fit_parameters(debrisRun, settings);

        parameters = [flatParameters; debrisParameters];
        provided.check_parameters(parameters, settings);
        if lower(string(stage)) == "validation"
            results = provided.evaluate_models(results, parameters, ["F2", "D2"]);
            disp(results.metrics);
            disp('F3/D3 were NOT simulated or scored. Freeze choices before the full run.');
        else
            results = provided.evaluate_models(results, parameters);
            disp(results.metrics);
            provided.plot_results(results);
            disp('Use these metrics to complete compare_models and recommend. No conclusions are filled for you.');
        end

    otherwise
        error('go1:Checkpoint', 'Unknown stage. Run run_checkpoint with no input to see the choices.');
end
end

function show_data(run, description)
% Supplied inspection plot: students explain the observed tracking behavior.
figure('Name', description, 'Color', 'white');
plot(run.Time_s, run.SpeedRaw_mps, 'Color', [0.8 0.8 0.8]);
hold on
plot(run.Time_s, run.Command_mps, 'k:', 'LineWidth', 1.2);
plot(run.Time_s, run.Speed_mps, 'Color', [0.05 0.49 0.53], 'LineWidth', 1.2);
xlabel('Time (s)');
ylabel('Forward speed (m/s)');
title(description);
legend('Unfiltered logged speed', 'Filtered command', 'Filtered logged speed');
grid on
end
