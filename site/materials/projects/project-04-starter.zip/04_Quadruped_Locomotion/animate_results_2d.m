% Previous simple 2D comparison viewer. Requires saved predictions.
folder=fileparts(mfilename('fullpath'));addpath(folder);
animationFigure=provided.animate_saved_results_2d(folder);
