% AFTER method freeze and a successful full run: compare your saved predictions.
folder=fileparts(mfilename('fullpath'));addpath(folder);
animationFigure=provided.animate_saved_results(folder,struct('InitialMode','comparison','IncludeFinalTests',true));
