function modelPath = build_model(settings)
% TASK 1b | Finish the supplied Simulink scaffold, then return its file path.
%
% 1. Run open_student_model from the student folder.
% 2. Add sums/gains, connect the integrators and add the ODE feedback paths.
% 3. Save the model without changing its name or the 'states' log name.
% 4. Remove the TODO error below. This function need not generate the blocks.
%
% Input:  settings.modelDir identifies the local models folder.
% Output: modelPath is the full path to your saved SLX.
%
% Variables for your blocks (already loaded by open_student_model/verifier):
% speedCommand   input timeseries; From Workspace interpolation must be OFF
% gainInput      K*omega_n^2
% gainDamping    2*zeta*omega_n
% gainSpeed      omega_n^2
% initialSpeed   initial speed; initial derivative and displacement are zero
% stopTime       end time; outputTimes identifies the comparison sample times
%
% Log timeseries 'states' with columns [v, dv/dt, p], in exactly that order.
% Use the handout and the quarter-car Simulink examples on Canvas for ideas.

modelPath = fullfile(settings.modelDir, 'go1_forward_model.slx');
error('go1:TODO', 'Task 1b: complete/save the SLX, then remove this TODO error.');

% Check: run_checkpoint("simulink") after your matrices work.
end
