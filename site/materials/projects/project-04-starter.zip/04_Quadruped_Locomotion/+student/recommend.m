function decision = recommend(metrics, comparison)
% TASK 2c | Write your engineering conclusion as one scalar string.
% metrics and comparison contain the evidence. No additional simulation needed.
% Get metrics after method freeze with r = run_checkpoint("final").

error('go1:TODO', 'Recommendation: write your supported conclusion, then remove this error.');

% Use your own words and numbers. Address:
% 1. One shared parameter set, or terrain-specific selection?
% 2. Which measured improvement/degradation supports that choice?
% 3. What information and complexity does model selection require?
% 4. What limitation prevents claiming the model is universally accurate?
% Looking ahead (report only): camera + LiDAR -> terrain/debris height map ->
% selection or updating of effective model parameters. Explain calibration data,
% a sensing limitation, and usefulness for rescue or nuclear-facility inspection.
% No sensor processing, controller or additional simulation is required.

decision = ""; % Replace with your conclusion. There is no single correct choice.
end
