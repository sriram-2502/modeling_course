function [theta, trials] = fit_parameters(trainingRun, settings)
% TASKS 1c / 2b | Fit one parameter row using ONE training recording.
% Called with F1 for flat walking and D1 for debris walking. Reuse this method.
%
% INPUTS: trainingRun is a table. settings comes from project_settings.
% OUTPUTS: theta = [K,zeta,omega_n]; trials = a table of all optimization starts.
%
% Provided helpers handle simulation, loss and parameter bounds. You complete
% the optimizer call, trial record and selection of the lowest training loss.
% Required first: your model_matrices function must work.

error('go1:TODO', 'Fit: complete the three TODO steps below, then remove this error.');

%% Setup: starting guesses and optimizer options are already supplied
numberOfStarts = size(settings.starts, 1);
trialValues = nan(numberOfStarts, 8);
bestLoss = Inf;
theta = nan(1, 3);

options = optimset('Display', 'off', ...
    'MaxIter', settings.maxIter, 'MaxFunEvals', settings.maxEvals, ...
    'TolX', 1e-7, 'TolFun', 1e-10);

%% Try each initial guess, using the SAME training data
for startIndex = 1:numberOfStarts
    initialTheta = settings.starts(startIndex, :);
    initialQ = provided.encode_parameters(initialTheta, settings);

    % q is what the optimizer changes; theta is the physical parameter row.
    objective = @(q) provided.training_loss( ...
        provided.decode_parameters(q, settings), trainingRun, settings);

    % TODO 1. Call fminsearch(objective, initialQ, options).
    % Keep its four outputs: fittedQ, lossValue, exitFlag, optimizerInfo.
    % See "help fminsearch" for the syntax; no optimization toolbox is needed.

    % TODO 2. Decode fittedQ to candidateTheta using provided.decode_parameters.
    % Fill trialValues(startIndex,:) with:
    % [startIndex, candidateTheta, lossValue, exitFlag,
    %  optimizerInfo.iterations, nearBound]
    % nearBound: true if any parameter is within 1% of either bound.
    % Hint: fraction = (candidateTheta-settings.lower)./(settings.upper-settings.lower);
    %       nearBound = any(fraction < 0.01 | fraction > 0.99);

    % TODO 3. If lossValue is smaller than bestLoss, update BOTH:
    % theta = candidateTheta; bestLoss = lossValue.
end

%% Return readable diagnostics, including unsuccessful starts
trials = array2table(trialValues, 'VariableNames', ...
    {'Start', 'K', 'Zeta', 'Omega_n_radps', 'Loss', ...
     'ExitFlag', 'Iterations', 'NearBound'});

% Check: run_checkpoint("flat"), then run_checkpoint("debris").
% Do not replace trainingRun with validation or final-test data.
end
