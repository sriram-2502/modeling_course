function [A, B] = model_matrices(theta)
% TASK 1b | Turn the handout's ODE into dx/dt = A*x + B*u.
%
% INPUT:  theta = [K, zeta, omega_n], a 1-by-3 parameter row.
% STATE:  x = [v; a; p], where a = dv/dt and dp/dt = v.
% OUTPUT: A is 3-by-3; B is 3-by-1. Use SI units.
%
% Work on paper first: write one first-order equation for each state.
% The supplied numerical solver will call this function automatically.

error('go1:TODO', 'Task 1b: fill A and B below, then remove this TODO error.');

% Step 1. Read the parameters using their names.
K = theta(1);
zeta = theta(2);
omega_n = theta(3);

% Step 2. Replace ALL NaNs with coefficients from your derived equations.
% Row 1 describes dv/dt; row 2 describes da/dt; row 3 describes dp/dt.
A = [NaN NaN NaN;
     NaN NaN NaN;
     NaN NaN NaN];
B = [NaN;
     NaN;
     NaN];

% Try: run_checkpoint("model") after completing analyze_modes too.
% NaNs are placeholders, not valid coefficients or expected answers.
end
