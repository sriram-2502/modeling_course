% Student tasks: model_matrices, build_model, fit_parameters, analyze_modes, compare_models, recommend.
% Start with README.md and docs/student_code_guide.pdf.
% First run start_here: replay and next steps need no TODO completed.
