function comparison = compare_models(metrics)
% TASK 2b | Does adaptation help debris prediction, and what does it cost on flat?
% Input: supplied metrics table. Output: one comparison row per F2,D2,F3,D3.
% You do not need to recompute errors or simulate anything in this function.
% After method freeze: r = run_checkpoint("final"); use r.metrics as input.

error('go1:TODO', 'Comparison: fill the loop below, then remove this error.');

runIDs = ["F2"; "D2"; "F3"; "D3"];
improvement = nan(4, 1);
baselineBand = strings(4, 1);
adaptedBand = strings(4, 1);

for runIndex = 1:numel(runIDs)
    runID = runIDs(runIndex);

    % Supplied: select the two rows you want to compare.
    baseline = metrics(metrics.Run == runID & metrics.Model == "Flat baseline", :);
    adapted = metrics(metrics.Run == runID & metrics.Model == "Debris adapted", :);

    % TODO: fill improvement(runIndex), baselineBand(runIndex), adaptedBand(runIndex).
    % RMSE improvement (%) = 100*(baseline RMSE - adapted RMSE)/baseline RMSE.
    % Positive = improvement; negative = degradation.
    % Useful columns: SpeedRMSE_mps, SpeedBias_mps, DisplacementError_m, Band.
    % Also discuss the signed bias and displacement in your report.
end

comparison = table(runIDs, improvement, baselineBand, adaptedBand, ...
    'VariableNames', {'Run', 'RMSEchange_pct', 'BaselineBand', 'AdaptedBand'});
end
