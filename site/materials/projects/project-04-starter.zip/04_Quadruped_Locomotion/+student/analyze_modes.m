function modes = analyze_modes(theta)
% TASK 1c | Explain what your speed model's poles mean.
% Input: theta = [K,zeta,omega_n]. Output: one struct with the fields below.

error('go1:TODO', 'Modes: complete the steps below, then remove this error.');

% Step 1. Get your matrices: [A,B] = student.model_matrices(theta).
% Step 2. Use eig on the 2-by-2 SPEED part of A.
% Step 3. Classify damping from zeta and decide speed stability from the poles.
% Step 4. Identify the separate displacement pole from your full model.
% Do not confuse the displacement integrator with unstable speed dynamics.

modes.speedPoles = nan(2, 1);  % Replace with the two speed poles
modes.dampingClass = "";      % Explain under/critical/overdamping
modes.stableSpeed = false;    % Replace with your logical stability test
modes.positionPole = NaN;     % Replace with the displacement mode's pole

% Check together with your matrices: run_checkpoint("model").
end
