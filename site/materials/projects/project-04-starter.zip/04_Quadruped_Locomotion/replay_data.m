% START HERE: supplied experimental CSVs only. No model or fitted answers.
folder=fileparts(mfilename('fullpath'));addpath(folder);
animationFigure=provided.animate_saved_results(folder,struct('InitialMode','logged','IncludeFinalTests',false));
