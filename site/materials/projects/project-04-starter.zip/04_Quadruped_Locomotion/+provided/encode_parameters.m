function q = encode_parameters(theta, settings)
% Convert an in-bound physical guess [K,zeta,omega_n] to optimizer coordinates.
% The inverse map is provided.decode_parameters. No fitted values are supplied.
if any(theta <= settings.lower | theta >= settings.upper, 'all')
    error('go1:StartBounds', 'An initial guess must lie strictly inside the parameter bounds.');
end
q = log((theta - settings.lower) ./ (settings.upper - theta));
end
