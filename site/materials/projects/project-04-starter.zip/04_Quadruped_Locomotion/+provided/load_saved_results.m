function results=load_saved_results(folder)
% CSV-only reconstruction for plot regeneration; no MAT, fitting or Simulink.
read=@(file)readtable(file,'Delimiter',',','VariableNamingRule','preserve','TextType','string');
root=folder;p=project_settings();p.root=root;p.outputDir=fullfile(folder,'results');p.modelDir=fullfile(folder,'models');
manifest=read(fullfile(root,'data','manifest.csv'));parameters=read(fullfile(p.outputDir,'fitted_parameters.csv'));
theta=parameters{:,{'K','Zeta','Omega_n_radps'}};runs=cell(height(manifest),1);responses=cell(height(manifest),2);
for k=1:height(manifest)
 for j=1:2
  T=read(fullfile(p.outputDir,sprintf('%s_model%d.csv',erase(manifest.File(k),'.csv'),j)));
  if j==1,runs{k}=T;end
  responses{k,j}=struct('t',T.Time_s,'states',T{:,{'PredictedSpeed_mps','PredictedAcceleration_mps2','PredictedX_m'}},'theta',theta(j,:));
 end
end
results=struct('p',p,'manifest',manifest,'models',parameters.Model','theta',theta,'runs',{runs},'responses',{responses}, ...
 'metrics',read(fullfile(p.outputDir,'case_metrics.csv')));
end
