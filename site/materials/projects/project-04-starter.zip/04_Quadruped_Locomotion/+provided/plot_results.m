function plot_results(results)
p=results.p;out=p.outputDir;colors=[82 45 128;229 106 23]/255;
f=figure('Visible','off','Color','w','Units','inches','Position',[1 1 7 5.2]);tl=tiledlayout(f,2,3,'TileSpacing','compact','Padding','compact');
for k=1:6
 ax=nexttile(tl);run=results.runs{k};hold(ax,'on');
 plot(ax,run.Time_s,run.SpeedRaw_mps,'Color',[.8 .8 .8],'LineWidth',.5,'DisplayName','Raw speed');
 plot(ax,run.Time_s,run.Command_mps,'k:','LineWidth',1.1,'DisplayName','Filtered command');
 plot(ax,run.Time_s,run.Speed_mps,'Color',[.15 .5 .55],'LineWidth',1.5,'DisplayName','Filtered logged speed');
 for j=1:2,plot(ax,run.Time_s,results.responses{k,j}.states(:,1),'Color',colors(j,:),'LineWidth',1.1,'DisplayName',results.models(j));end
 title(ax,sprintf('%s | %s | %s',results.manifest.ID(k),results.manifest.Terrain(k),results.manifest.Role(k)));
 xlabel(ax,'Time (s)');ylabel(ax,'Forward speed (m/s)');grid(ax,'on');
end
lg=legend(ax,'Orientation','horizontal','NumColumns',3,'Box','off');lg.Layout.Tile='south';
set(findall(f,'Type','axes'),'FontName','Arial','FontSize',8);export(f,'all_runs');
f=figure('Visible','off','Color','w','Units','inches','Position',[1 1 7 4.8]);tl=tiledlayout(f,2,2,'TileSpacing','compact','Padding','compact');
for terrain=1:2
 id="F3";if terrain==2,id="D3";end;k=find(results.manifest.ID==id,1);run=results.runs{k};
 for panel=1:2
  ax=nexttile(tl,(panel-1)*2+terrain);hold(ax,'on');
  if panel==1
   plot(ax,run.Time_s,run.IntegratedX_m,'k','LineWidth',1.5,'DisplayName','Logged-speed integral');
   for j=1:2,plot(ax,run.Time_s,results.responses{k,j}.states(:,3),'Color',colors(j,:),'LineWidth',1.2,'DisplayName',results.models(j));end
   ylabel(ax,'Integrated displacement (m)');
  else
   for j=1:2,plot(ax,run.Time_s,results.responses{k,j}.states(:,1)-run.Speed_mps,'Color',colors(j,:),'LineWidth',1.1,'DisplayName',results.models(j));end
   yline(ax,0,'k:','HandleVisibility','off');ylabel(ax,'Model speed error (m/s)');
  end
  title(ax,id+" | held-out test");xlabel(ax,'Time (s)');grid(ax,'on');
 end
end
lg=legend(tl.Children(end),'Orientation','horizontal','Box','off');lg.Layout.Tile='south';
set(findall(f,'Type','axes'),'FontName','Arial','FontSize',9);export(f,'held_out_comparison');
f=figure('Visible','off','Color','w','Units','inches','Position',[1 1 6.5 3]);tl=tiledlayout(f,1,2,'TileSpacing','compact','Padding','compact');
for j=1:2
 ax=nexttile(tl);theta=results.theta(j,:);run=results.runs{j};[A,~]=student.model_matrices(theta);L=eig(A(1:2,1:2));
 plot(ax,real(L),imag(L),'x','Color',colors(j,:),'LineWidth',2,'MarkerSize',10);xline(ax,0,'k:');grid(ax,'on');
 xlabel(ax,'Real part (1/s)');ylabel(ax,'Imaginary part (1/s)');title(ax,results.models(j));
end
export(f,'speed_poles');
 function export(fig,name)
  exportgraphics(fig,fullfile(out,[name '.pdf']),'ContentType','vector','BackgroundColor','white');
  exportgraphics(fig,fullfile(out,[name '.png']),'Resolution',180);close(fig);
 end
end
