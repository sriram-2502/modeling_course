function theta = decode_parameters(q, settings)
% Map unrestricted optimizer coordinates back into the fixed physical bounds.
theta = settings.lower + (settings.upper - settings.lower) ./ (1 + exp(-q));
end
