function save_results(results)
% CSVs support replay without fitting, simulation, or a saved MATLAB workspace.
p=results.p;if ~isfolder(p.outputDir),mkdir(p.outputDir);end
writetable(results.metrics,fullfile(p.outputDir,'case_metrics.csv'));
writetable(results.flatTrials,fullfile(p.outputDir,'flat_fit_trials.csv'));
writetable(results.debrisTrials,fullfile(p.outputDir,'debris_fit_trials.csv'));
writetable(table(results.models',results.theta(:,1),results.theta(:,2),results.theta(:,3), ...
 'VariableNames',{'Model','K','Zeta','Omega_n_radps'}),fullfile(p.outputDir,'fitted_parameters.csv'));
for k=1:6
 for j=1:2
  T=results.runs{k};r=results.responses{k,j};
  T.PredictedSpeed_mps=r.states(:,1);T.PredictedAcceleration_mps2=r.states(:,2);T.PredictedX_m=r.states(:,3);
  writetable(T,fullfile(p.outputDir,sprintf('%s_model%d.csv',erase(results.manifest.File(k),'.csv'),j)));
 end
end
save(fullfile(p.outputDir,'project_results.mat'),'results');
end
