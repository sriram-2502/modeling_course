function run = get_run(results, runID)
% Select by the F1/D1 task label, so students never need to remember row numbers.
index = find(results.manifest.ID == string(runID));
if numel(index) ~= 1
    error('go1:RunID', 'Choose one run: F1, F2, F3, D1, D2 or D3.');
end
run = results.runs{index};
end
