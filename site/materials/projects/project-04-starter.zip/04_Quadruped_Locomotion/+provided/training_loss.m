function loss = training_loss(theta, trainingRun, settings)
% Supplied objective: normalized, time-weighted speed MSE on ONE training run.
% Students still choose optimizer calls, compare starts and select a fitted row.
predictedSpeed = provided.predict_speed(theta, trainingRun, settings);

scoreMask = trainingRun.Time_s >= settings.scoreStart;
time = trainingRun.Time_s(scoreMask);
command = trainingRun.Command_mps(scoreMask);
speedError = predictedSpeed(scoreMask) - trainingRun.Speed_mps(scoreMask);

duration = time(end) - time(1);
commandRMS = sqrt(trapz(time, command.^2) / duration);
scale = max(commandRMS, 0.10);
loss = trapz(time, speedError.^2) / duration / scale^2;

if ~isfinite(loss)
    loss = 1e10;
end
end
