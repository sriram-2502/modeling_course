function fig=animate_saved_results_2d(folder,options)
% Illustrative forward progress, NOT reconstructed quadruped leg dynamics.
if nargin<2,options=struct;end
if ~isfield(options,'Visible'),options.Visible='on';end
read=@(file)readtable(file,'Delimiter',',','VariableNamingRule','preserve','TextType','string');
manifest=read(fullfile(folder,'data','manifest.csv'));
metrics=read(fullfile(folder,'results','case_metrics.csv'));params=read(fullfile(folder,'results','fitted_parameters.csv'));
fig=figure('Name','Go1 | saved CSV replay','NumberTitle','off','Color','w','Position',[100 100 1150 650],'Visible',options.Visible);
runMenu=uicontrol(fig,'Style','popupmenu','Units','normalized','Position',[.03 .93 .25 .05], ...
 'String',cellstr(manifest.ID+" | "+manifest.Terrain+" | "+manifest.Role),'Value',3,'Callback',@loadCase,'Tag','Go1Run');
modelMenu=uicontrol(fig,'Style','popupmenu','Units','normalized','Position',[.31 .93 .23 .05], ...
 'String',cellstr(params.Model),'Value',1,'Callback',@loadCase,'Tag','Go1Model');
play=uicontrol(fig,'Style','pushbutton','Units','normalized','Position',[.57 .93 .10 .05], ...
 'String','Play','Callback',@toggle,'Tag','Go1Play');
rate=uicontrol(fig,'Style','popupmenu','Units','normalized','Position',[.70 .93 .12 .05], ...
 'String',{'0.5x','1x','2x','4x'},'Value',2);
status=uicontrol(fig,'Style','text','Units','normalized','Position',[.03 .82 .94 .09], ...
 'BackgroundColor','w','HorizontalAlignment','left','FontSize',10);
world=axes(fig,'Position',[.06 .27 .51 .49]);history=axes(fig,'Position',[.66 .27 .30 .49]);
seek=uicontrol(fig,'Style','slider','Units','normalized','Position',[.06 .10 .88 .04], ...
 'Min',0,'Max',1,'Value',0,'Callback',@scrub,'Tag','Go1Time');
uicontrol(fig,'Style','text','Units','normalized','Position',[.05 .03 .90 .04], ...
 'BackgroundColor','w','String','Schematic progress only: displacement integrates filtered speed. Decorative legs are not a gait model.');
t=0;data=[];robots=[];dots=[];playing=false;clock=tic;last=0;
tm=timer('ExecutionMode','fixedSpacing','Period',.04,'BusyMode','drop','TimerFcn',@tick);
setappdata(fig,'PlaybackTimer',tm);fig.CloseRequestFcn=@closeViewer;loadCase();
 function loadCase(varargin)
  stop(tm);playing=false;play.String='Play';t=0;seek.Value=0;
  id=manifest.ID(runMenu.Value);j=modelMenu.Value;
  data=read(fullfile(folder,'results',sprintf('%s_model%d.csv',erase(manifest.File(runMenu.Value),'.csv'),j)));
  cla(world);hold(world,'on');cla(history);hold(history,'on');
  colors=[.12 .5 .55;.32 .18 .5];robots=gobjects(2,1);
  for row=1:2
   y=(2-row)*.9;plot(world,[-2 max([data.IntegratedX_m;data.PredictedX_m])+2],[y y],'Color',[.75 .75 .75]);
   robots(row)=patch(world,nan,nan,colors(row,:),'EdgeColor',colors(row,:));
  end
  ylim(world,[-.1 1.6]);world.YTick=[];xlabel(world,'Forward displacement from start (m)');
  title(world,'Logged-speed integral (upper) and model (lower)');
  plot(history,data.Time_s,data.Speed_mps,'Color',colors(1,:),'LineWidth',1.3);
  plot(history,data.Time_s,data.PredictedSpeed_mps,'Color',colors(2,:),'LineWidth',1.3);
  dots=plot(history,[0 0],[0 0],'ro','MarkerFaceColor','r');
  xlabel(history,'Time (s)');ylabel(history,'Filtered speed (m/s)');grid(history,'on');legend(history,{'Logged speed','Model'},'Location','best');
  m=metrics(metrics.Run==id & metrics.Model==params.Model(j),:);
  status.String=sprintf('%s | %s | %s | K %.3f, zeta %.3f, omega_n %.2f rad/s\n%s | speed RMSE %.4f m/s | terminal drift %+.3f m | CSV-only playback', ...
   id,manifest.Terrain(runMenu.Value),params.Model(j),params.K(j),params.Zeta(j),params.Omega_n_radps(j),m.Band,m.SpeedRMSE_mps,m.DisplacementError_m);
  render();last=toc(clock);
 end
 function render()
  values=interp1(data.Time_s,[data.IntegratedX_m data.PredictedX_m data.Speed_mps data.PredictedSpeed_mps],t);
  for row=1:2
   x=values(row);y=(2-row)*.9;phase=.05*sin(2*pi*2*t);
   xy=[-.18 .24;.18 .24;.18 .40;-.18 .40;-.18 .24;-.12 .24;-.18+phase 0;-.12 .24;.12 .24;.18-phase 0;.12 .24];
   set(robots(row),'XData',xy(:,1)+x,'YData',xy(:,2)+y);
  end
  center=mean(values(1:2));xlim(world,center+[-.7 .7]);
  set(dots,'XData',[t t],'YData',values(3:4));seek.Value=t/data.Time_s(end);drawnow limitrate;
 end
 function toggle(varargin)
  if playing,stop(tm);playing=false;play.String='Play';return;end
  if t>=data.Time_s(end),t=0;end
  playing=true;play.String='Pause';last=toc(clock);start(tm);
 end
 function tick(varargin)
  now=toc(clock);rates=[.5 1 2 4];t=min(data.Time_s(end),t+(now-last)*rates(rate.Value));last=now;
  render();if t>=data.Time_s(end),stop(tm);playing=false;play.String='Play';end
 end
 function scrub(varargin),t=seek.Value*data.Time_s(end);last=toc(clock);render();end
 function closeViewer(varargin),stop(tm);delete(tm);delete(fig);end
end
