function results=evaluate_models(results,theta,ids)
% Provided: use the same simulator and scoring rule for both fitted models.
p=results.p;results.theta=theta;results.models=["Flat baseline","Debris adapted"];
if nargin<3,ids=results.manifest.ID;end
rows=struct([]);results.responses=cell(6,2);
for k=1:6
 if ~any(results.manifest.ID(k)==ids),continue;end
 for j=1:2
  r=provided.simulate_model(theta(j,:),results.runs{k},p);results.responses{k,j}=r;
  m=provided.evaluate_match(r,results.runs{k},p);
  row=struct('Run',results.manifest.ID(k),'Terrain',results.manifest.Terrain(k),'Role',results.manifest.Role(k),'Model',results.models(j));
  for field=fieldnames(m)',row.(field{1})=m.(field{1});end
  rows=[rows;row]; %#ok<AGROW>
 end
end
results.metrics=struct2table(rows);
end
