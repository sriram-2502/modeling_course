function fig=animate_saved_results(folder,options)
% 3D CSV replay. No fitting, model calls, Simulink or specialist toolboxes.
% Logged mode works before students implement ANY function or save results.
% options: InitialMode ('logged'/'comparison'), IncludeFinalTests, Visible.
% Optional VideoFile and ExportEndTime support scripted AVI capture.
% Geometry, leg motion and terrain are illustrative, not measured kinematics.
if nargin<2,options=struct;end
if ~isfield(options,'Visible'),options.Visible='on';end
if ~isfield(options,'InitialMode'),options.InitialMode='logged';end
if ~isfield(options,'IncludeFinalTests'),options.IncludeFinalTests=false;end
read=@(file)readtable(file,'Delimiter',',','VariableNamingRule','preserve','TextType','string');
dataDir=fullfile(folder,'data');if ~isfolder(dataDir),dataDir=fullfile(folder,'..','data');end
manifest=read(fullfile(dataDir,'manifest.csv'));
if ~options.IncludeFinalTests,manifest=manifest(manifest.Role~="test",:);end
out=fullfile(folder,'results');params=[];metrics=[];
hasResults=isfile(fullfile(out,'fitted_parameters.csv'))&&isfile(fullfile(out,'case_metrics.csv'));
if hasResults
 params=read(fullfile(out,'fitted_parameters.csv'));metrics=read(fullfile(out,'case_metrics.csv'));
end
modeNames={'Explore logged data'};if hasResults,modeNames{2}='Compare saved model';end
initial=1;if strcmpi(options.InitialMode,'comparison')
 if ~hasResults,error('go1:MissingPredictions','Run your completed run_project first. For immediate data replay, run animate_results or replay_data.');end
 initial=2;
end
fig=figure('Name','Go1 | explore data, then compare your model','NumberTitle','off', ...
 'Color','w','Position',[70 65 1280 800],'Visible',options.Visible);
mode=menu([.025 .94 .19 .038],modeNames,initial,@loadCase,'Go1Mode');
runMenu=menu([.23 .94 .22 .038],cellstr(manifest.ID+" | "+manifest.Terrain+" | "+manifest.Role),1,@loadCase,'Go1Run');
modelNames={'No model needed'};if hasResults,modelNames=cellstr(params.Model);end
modelMenu=menu([.47 .94 .20 .038],modelNames,1,@loadCase,'Go1Model');
camera=menu([.69 .94 .18 .038],{'Follow logged robot','Fixed global view','Side view'},1,@render,'Go1Camera');
exportButton=uicontrol(fig,'Style','pushbutton','Units','normalized','Position',[.89 .94 .085 .04], ...
 'String','Export AVI','Callback',@exportClip,'Tag','Go1Export');
status=uicontrol(fig,'Style','text','Units','normalized','Position',[.025 .845 .95 .08], ...
 'BackgroundColor','w','HorizontalAlignment','left','FontSize',11,'Tag','Go1Status');
world=axes(fig,'Position',[.045 .235 .57 .57],'Tag','Go1World');
speedAx=axes(fig,'Position',[.72 .645 .25 .16]);
positionAx=axes(fig,'Position',[.72 .425 .25 .15]);
errorAx=axes(fig,'Position',[.72 .205 .25 .15]);
play=uicontrol(fig,'Style','pushbutton','Units','normalized','Position',[.03 .115 .10 .045], ...
 'String','Play','Callback',@toggle,'Tag','Go1Play');
rate=menu([.15 .115 .10 .04],{'0.5x','1x','2x','4x'},2,[],'Go1Rate');
seek=uicontrol(fig,'Style','slider','Units','normalized','Position',[.28 .12 .58 .03], ...
 'Min',0,'Max',1,'Value',0,'Callback',@scrub,'Tag','Go1Time');
timeText=uicontrol(fig,'Style','text','Units','normalized','Position',[.88 .11 .09 .04], ...
 'BackgroundColor','w','String','0.00 s','FontSize',11);
uicontrol(fig,'Style','text','Units','normalized','Position',[.025 .025 .95 .065], ...
 'BackgroundColor','w','HorizontalAlignment','left','FontSize',10, ...
 'String',{'Hollow teal: logged progress. Solid purple: prediction. Both use the same starting position and track.', ...
 'Leg motion and rough terrain are illustrative. Explore F1/D1 first; then build and validate your model.'});
t=0;data=[];robots={};cursors=gobjects(3,1);playing=false;busy=false;last=0;clock=tic;comparing=false;rough=false;
colors=[.05 .49 .53;.32 .18 .50];lanes=0;info='';id="";
tm=timer('ExecutionMode','fixedSpacing','Period',.04,'BusyMode','drop','TimerFcn',@tick);
setappdata(fig,'PlaybackTimer',tm);fig.CloseRequestFcn=@closeViewer;loadCase();

 function h=menu(pos,labels,value,callback,tag)
  h=uicontrol(fig,'Style','popupmenu','Units','normalized','Position',pos, ...
   'String',labels,'Value',value,'Callback',callback,'Tag',tag,'FontSize',10);
 end
 function loadCase(varargin)
  stop(tm);playing=false;play.String='Play';t=0;seek.Value=0;
  id=manifest.ID(runMenu.Value);comparing=mode.Value==2;
  data=read(fullfile(dataDir,manifest.File(runMenu.Value)));lanes=0;
  if comparing
   j=modelMenu.Value;file=fullfile(out,sprintf('%s_model%d.csv',erase(manifest.File(runMenu.Value),'.csv'),j));
   if ~isfile(file)
    mode.Value=1;loadCase();warning('go1:MissingCase','No saved prediction for %s; showing logged data.',id);return;
   end
   prediction=read(file);
   assert(height(prediction)==height(data)&&max(abs(prediction.Time_s-data.Time_s))<1e-8,'Prediction and data times differ.');
   data.PredictedX_m=prediction.PredictedX_m;data.PredictedSpeed_mps=prediction.PredictedSpeed_mps;
   assert(all(isfinite(data{:,{'PredictedX_m','PredictedSpeed_mps'}}),'all'),'Prediction contains nonfinite values.');
   lanes=[0 0];modelMenu.Enable='on';
   m=metrics(metrics.Run==id & metrics.Model==params.Model(j),:);
   assert(height(m)==1,'Expected one metric row for this run/model.');
   info=sprintf('%s | %s | %s | RMSE %.4f m/s | scored drift %+.3f m\nK %.3f, zeta %.3f, omega_n %.2f rad/s | %s', ...
    id,manifest.Terrain(runMenu.Value),params.Model(j),m.SpeedRMSE_mps,m.DisplacementError_m, ...
    params.K(j),params.Zeta(j),params.Omega_n_radps(j),m.Band);
  else
   modelMenu.Enable='off';
   info=sprintf('%s | %s | %s | LOGGED DATA ONLY - no fitted model needed\nTeal robot follows the integral of logged speed. The dotted speed curve is the command. Build a model to predict this response.', ...
    id,manifest.Terrain(runMenu.Value),manifest.Role(runMenu.Value));
  end
  status.String=info;
  cla(world);hold(world,'on');grid(world,'on');world.Color=[.97 .98 .99];
  world.FontSize=10;world.ZLim=[-.015 .65];world.YLim=[-.85 .85];
  xlabel(world,'Forward displacement (m)');ylabel(world,'Lateral position (m)');zlabel(world,'Height (m)');
  view(world,[-35 20]);daspect(world,[1 1 1]);
  dist=data.IntegratedX_m;if comparing,dist=[dist;data.PredictedX_m];end
  xmin=min([0;dist])-1;xmax=max([0;dist])+1;
  rough=manifest.Terrain(runMenu.Value)=="debris";
  if rough
   [gx,gy]=meshgrid(xmin:.055:xmax,-.85:.055:.85);
   % Fixed-seed smooth noise gives a repeatable illustrative surface.
   gz=terrainHeight(gx,gy);
   surf(world,gx,gy,gz,'EdgeColor','none','FaceColor','interp','FaceAlpha',.88,'Tag','Go1Terrain');
   colormap(world,[linspace(.55,.82,64)' linspace(.48,.77,64)' linspace(.37,.65,64)']);
   clim(world,[0 .05]);
  else
   patch(world,[xmin xmax xmax xmin],[-.85 -.85 .85 .85],[0 0 0 0], ...
    [.88 .90 .91],'FaceAlpha',.4,'EdgeColor','none');
  end
  for x=floor(xmin):ceil(xmax)
   ygrid=linspace(-.8,.8,70);zgrid=zeros(size(ygrid))+.001;
   if rough,zgrid=terrainHeight(x+zeros(size(ygrid)),ygrid)+.001;end
   plot3(world,x+zeros(size(ygrid)),ygrid,zgrid,'-','Color',[.76 .78 .8]);
   text(world,x,-.78,.012,sprintf('%d m',x),'FontSize',9,'Color',[.4 .4 .4],'Clipping','on');
  end
  robots=cell(numel(lanes),1);
  for row=1:numel(lanes)
   robots{row}=createRobot(world,colors(row,:),row==1);
  end
  if comparing,title(world,'Hollow teal: logged progress | Solid purple: prediction');else,title(world,'Hollow teal: recorded forward progress');end
  axesList=[speedAx positionAx errorAx];
  % Reset also removes hidden cursor lines from the previous selected case.
  for ax=axesList,cla(ax,'reset');hold(ax,'on');grid(ax,'on');ax.FontSize=10;xlim(ax,[0 data.Time_s(end)]);end
  plot(speedAx,data.Time_s,data.Command_mps,'k:','LineWidth',1.1,'DisplayName','Command');
  plot(speedAx,data.Time_s,data.Speed_mps,'Color',colors(1,:),'LineWidth',1.3,'DisplayName','Logged');
  plot(positionAx,data.Time_s,data.IntegratedX_m,'Color',colors(1,:),'LineWidth',1.3,'DisplayName','Logged integral');
  if comparing
   plot(speedAx,data.Time_s,data.PredictedSpeed_mps,'Color',colors(2,:),'LineWidth',1.1,'DisplayName','Model');
   plot(positionAx,data.Time_s,data.PredictedX_m,'Color',colors(2,:),'LineWidth',1.1,'DisplayName','Model');
   plot(errorAx,data.Time_s,data.PredictedSpeed_mps-data.Speed_mps,'Color',colors(2,:));
   title(errorAx,'Prediction error: model - logged');
  else
   plot(errorAx,data.Time_s,data.Speed_mps-data.Command_mps,'Color',[.88 .40 .08]);
   title(errorAx,'Tracking error: logged - command');
  end
  title(speedAx,'Forward speed');ylabel(speedAx,'v (m/s)');
  title(positionAx,'Integrated forward progress');ylabel(positionAx,'p (m)');
  ylabel(errorAx,'Error (m/s)');xlabel(errorAx,'Time (s)');
  legend(speedAx,'Location','northoutside','Orientation','horizontal','Box','off','FontSize',9);
  for k=1:3,cursors(k)=xline(axesList(k),0,'-','Color',[.85 .25 .10],'LineWidth',1.2,'HandleVisibility','off');end
  render();last=toc(clock);
 end
 function render(varargin)
  if ~isgraphics(fig)||isempty(data),return;end
  pos=interp1(data.Time_s,data.IntegratedX_m,t);positions=pos;
  if comparing,positions=[pos interp1(data.Time_s,data.PredictedX_m,t)];end
  for row=1:numel(lanes),updateRobot(robots{row},positions(row),lanes(row),rough);end
  if camera.Value==2
   xlim(world,[min([0;data.IntegratedX_m])-1 max([0;data.IntegratedX_m])+1]);
   if comparing,xlim(world,[min([0;data.IntegratedX_m;data.PredictedX_m])-1 max([0;data.IntegratedX_m;data.PredictedX_m])+1]);end
  else
   % Follow the logged robot; widen only when required to retain model drift.
   xlim(world,[min(pos-1.1,min(positions)-.45) max(pos+1.1,max(positions)+.45)]);
  end
  if camera.Value==3,view(world,[0 0]);else,view(world,[-35 20]);end
  for k=1:3,cursors(k).Value=t;end
  seek.Value=t/data.Time_s(end);timeText.String=sprintf('%.2f s',t);
  setappdata(fig,'ReplayState',struct('Run',id,'Mode',mode.Value,'Time',t,'Positions',positions,'DisplayOffsets',lanes));
  drawnow limitrate;
 end
 function toggle(varargin)
  if busy,return;end
  if playing,stop(tm);playing=false;play.String='Play';return;end
  if t>=data.Time_s(end),t=0;end
  playing=true;play.String='Pause';last=toc(clock);start(tm);
 end
 function tick(varargin)
  now=toc(clock);rates=[.5 1 2 4];t=min(data.Time_s(end),t+(now-last)*rates(rate.Value));last=now;
  render();if isgraphics(fig)&&t>=data.Time_s(end),stop(tm);playing=false;play.String='Play';end
 end
 function scrub(varargin),t=seek.Value*data.Time_s(end);last=toc(clock);render();end
 function exportClip(varargin)
  if isfield(options,'VideoFile')
   [path,file,ext]=fileparts(options.VideoFile);file=[file ext];
  else
   [file,path]=uiputfile('*.avi','Export the selected replay','go1_replay.avi');
   if isequal(file,0),return;end
  end
  stop(tm);playing=false;play.String='Play';busy=true;
  controls=[mode runMenu modelMenu camera exportButton play rate seek];set(controls,'Enable','off');
  old=t;writer=VideoWriter(fullfile(path,file),'Motion JPEG AVI');writer.FrameRate=25;
  cleanup=onCleanup(@()finishExport(writer,controls,old));open(writer);
  final=data.Time_s(end);if isfield(options,'ExportEndTime'),final=min(final,options.ExportEndTime);end
  frames=unique([0:1/25:final,final]);
  for frame=frames
   if ~isgraphics(fig),break;end
   t=frame;render();drawnow;writeVideo(writer,getframe(fig));
  end
  clear cleanup; % Finalize while callback variables are still alive.
 end
 function finishExport(writer,controls,old)
  close(writer);busy=false;
  if isgraphics(fig)
   set(controls,'Enable','on');if ~comparing,modelMenu.Enable='off';end
   t=old;render();
  end
 end
 function closeViewer(varargin),stop(tm);delete(tm);delete(fig);end
end

function h=box(ax,center,size,color)
V=[-1 -1 -1;1 -1 -1;1 1 -1;-1 1 -1;-1 -1 1;1 -1 1;1 1 1;-1 1 1].*size/2+center;
h=patch(ax,'Vertices',V,'Faces',[1 2 3 4;5 6 7 8;1 2 6 5;2 3 7 6;3 4 8 7;4 1 5 8], ...
 'FaceColor',color,'EdgeColor',color*.6,'LineWidth',.6);
end
function robot=createRobot(ax,color,hollow)
robot.body=box(ax,[0 0 .38],[.50 .22 .12],color);
robot.baseVertices=robot.body.Vertices;
robot.nose=box(ax,[.265 0 .395],[.045 .15 .075],[.16 .19 .23]);
robot.noseVertices=robot.nose.Vertices;
if hollow
 robot.body.Tag='Go1LoggedBody';
 % Slightly expanded shell keeps teal edges visible when both robots coincide.
 robot.body.FaceColor='none';robot.body.EdgeColor=color;robot.body.LineWidth=2;
 robot.nose.FaceColor='none';robot.nose.EdgeColor=color;robot.nose.LineWidth=1.6;
 robot.baseVertices=(robot.baseVertices-[0 0 .38])*1.045+[0 0 .38];
 robot.noseVertices=(robot.noseVertices-[0 0 .395])*1.045+[0 0 .395];
else
 robot.body.Tag='Go1ModelBody';
end
robot.legs=gobjects(4,1);robot.joints=gobjects(4,1);robot.feet=gobjects(4,1);
for k=1:4
 robot.legs(k)=plot3(ax,nan,nan,nan,'-','Color',color*.6,'LineWidth',4);
 robot.joints(k)=plot3(ax,nan,nan,nan,'o','Color',[.2 .23 .27],'MarkerFaceColor',[.7 .73 .76],'MarkerSize',5);
 robot.feet(k)=plot3(ax,nan,nan,nan,'o','Color',[.15 .17 .20],'MarkerFaceColor',[.15 .17 .20],'MarkerSize',6);
 if hollow
  robot.legs(k).Tag='Go1LoggedLeg';
  robot.legs(k).Color=color;robot.legs(k).LineWidth=2;robot.legs(k).LineStyle='-';
  robot.joints(k).Color=color;robot.joints(k).MarkerFaceColor='none';robot.joints(k).MarkerSize=7;
  robot.feet(k).Color=color;robot.feet(k).MarkerFaceColor='none';robot.feet(k).MarkerSize=8;
 else
  robot.legs(k).Tag='Go1ModelLeg';
 end
end
end
function updateRobot(robot,x,y,rough)
heightOffset=0;if rough,heightOffset=terrainHeight(x,y);end
robot.body.Vertices=robot.baseVertices+[x y heightOffset];robot.nose.Vertices=robot.noseVertices+[x y heightOffset];
hips=[.19 .13; .19 -.13; -.19 .13; -.19 -.13];offsets=[0 .5 .5 0];
for k=1:4
 phase=mod(x/.32+offsets(k),1);
 if phase<.62,footX=.075-.15*phase/.62;footZ=.012;
 else,s=(phase-.62)/.38;footX=-.075+.15*(.5-.5*cos(pi*s));footZ=.012+.065*sin(pi*s);end
 hip=[x+hips(k,1),y+hips(k,2),.33+heightOffset];foot=[hip(1)+footX,hip(2),footZ];
 if rough,foot(3)=foot(3)+terrainHeight(foot(1),foot(2));end
 % Equal-length planar links. Midpoint plus perpendicular gives knee position.
 dx=foot(1)-hip(1);dz=foot(3)-hip(3);d=hypot(dx,dz);L=.19;
 bend=sqrt(max(L^2-(d/2)^2,0));knee=(hip+foot)/2-bend*[-dz 0 dx]/d;
 points=[hip;knee;foot];set(robot.legs(k),'XData',points(:,1),'YData',points(:,2),'ZData',points(:,3));
 set(robot.joints(k),'XData',points(1:2,1),'YData',points(1:2,2),'ZData',points(1:2,3));
 set(robot.feet(k),'XData',foot(1),'YData',foot(2),'ZData',foot(3));
end
end

function z=terrainHeight(x,y)
% Bounded band-limited random surface; isolated stream never changes fit RNG.
persistent amplitude kx ky phase
if isempty(amplitude)
 stream=RandStream('mt19937ar','Seed',4204);
 amplitude=rand(stream,1,18);amplitude=amplitude/sum(amplitude);
 kx=5+18*rand(stream,1,18);ky=3+16*rand(stream,1,18);phase=2*pi*rand(stream,1,18);
end
z=zeros(size(x+y));
for k=1:numel(amplitude),z=z+amplitude(k)*sin(kx(k)*x+ky(k)*y+phase(k));end
z=.025+.025*z;
end
