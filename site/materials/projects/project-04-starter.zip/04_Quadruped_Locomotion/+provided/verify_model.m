function verification=verify_model(results)
p=results.p;path=fullfile(p.modelDir,'go1_forward_model.slx');load_system(path);[~,model]=fileparts(path);
cleanup=onCleanup(@()close_system(model,0));rows=struct([]);
for item=1:2
 if item==1,id="F2";j=1;else,id="D2";j=2;end
 k=find(results.manifest.ID==id,1);run=results.runs{k};theta=results.theta(j,:);exact=results.responses{k,j};
 variables=struct('speedCommand',timeseries(run.Command_mps,run.Time_s), ...
  'gainInput',theta(1)*theta(3)^2,'gainDamping',2*theta(2)*theta(3),'gainSpeed',theta(3)^2, ...
  'initialSpeed',run.Speed_mps(1),'stopTime',run.Time_s(end),'outputTimes',run.Time_s');
 in=Simulink.SimulationInput(model);
 for name=fieldnames(variables)',in=in.setVariable(name{1},variables.(name{1}));end
 in=in.setModelParameter('ReturnWorkspaceOutputs','on','OutputOption','SpecifiedOutputTimes','OutputTimes','outputTimes');
 out=sim(in);x=squeeze(out.states.Data);t=out.states.Time;if size(x,1)~=numel(t),x=x';end
 x=interp1(t,x,run.Time_s);err=max(abs(x-exact.states),[],1);
 assert(err(1)<1e-4 && err(3)<1e-4,'Simulink verification failed.');
 rows=[rows;struct('Run',id,'Model',results.models(j),'MaxSpeedError_mps',err(1), ...
  'MaxRateError_mps2',err(2),'MaxDisplacementError_m',err(3))]; %#ok<AGROW>
 T=array2table([run.Time_s x exact.states], ...
  'VariableNames',{'Time_s','SimSpeed','SimRate','SimX','ExactSpeed','ExactRate','ExactX'});
 writetable(T,fullfile(p.outputDir,"verification_"+id+".csv"));
end
verification=struct2table(rows);writetable(verification,fullfile(p.outputDir,'verification_metrics.csv'));disp(verification);
end
