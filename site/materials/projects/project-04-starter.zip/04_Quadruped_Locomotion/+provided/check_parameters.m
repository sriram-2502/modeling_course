function check_parameters(parameters, settings)
% Friendly contract check for the two fitted rows, not an answer checker.
if ~isequal(size(parameters), [2 3]) || any(~isfinite(parameters), 'all')
    error('go1:Parameters', 'Each fit must return a finite 1-by-3 row: [K, zeta, omega_n].');
end
if any(parameters < settings.lower | parameters > settings.upper, 'all')
    error('go1:Bounds', 'A fitted value is outside the fixed bounds in project_settings.m.');
end
fraction = (parameters - settings.lower) ./ (settings.upper - settings.lower);
if any(fraction < 0.01 | fraction > 0.99, 'all')
    warning('go1:BoundHit', 'A parameter is near a bound. Report this identification limitation.');
end
end
