function metric=evaluate_match(response,run,p)
metric=struct('SpeedRMSE_mps',NaN,'SpeedBias_mps',NaN,'DisplacementError_m',NaN, ...
 'SpeedError_pct',NaN,'Bias_pct',NaN,'DisplacementError_pct',NaN,'Band',"Invalid");
if size(response.states,1)~=height(run) || size(response.states,2)~=3 || ...
 numel(response.t)~=height(run) || any(~isfinite(response.states),'all') || ...
 any(abs(response.t(:)-run.Time_s)>1e-8),return;end
use=run.Time_s>=p.scoreStart;t=run.Time_s(use);v=run.Speed_mps(use);u=run.Command_mps(use);e=response.states(use,1)-v;
average=@(x)trapz(t,x)/(t(end)-t(1));scale=max(sqrt(average(u.^2)),.1);
rmse=sqrt(average(e.^2));bias=average(e);
truth=run.IntegratedX_m(use);pred=response.states(use,3);distanceScale=max(trapz(t,abs(v)),.5);
drift=(pred(end)-pred(1))-(truth(end)-truth(1));scores=[100*rmse/scale 100*abs(bias)/scale 100*abs(drift)/distanceScale];
metric=struct('SpeedRMSE_mps',rmse,'SpeedBias_mps',bias,'DisplacementError_m',drift, ...
 'SpeedError_pct',scores(1),'Bias_pct',scores(2),'DisplacementError_pct',scores(3),'Band',"Needs improvement");
if all(isfinite(scores))
 if all(scores<=p.good),metric.Band="Good";elseif all(scores<=p.acceptable),metric.Band="Acceptable";end
else,metric.Band="Invalid";end
end
