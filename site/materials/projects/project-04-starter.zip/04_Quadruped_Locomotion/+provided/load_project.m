function results=load_project(folder)
p=project_settings();p.root=folder;p.outputDir=fullfile(folder,'results');p.modelDir=fullfile(folder,'models');
manifest=readtable(fullfile(folder,'data','manifest.csv'),'TextType','string','Delimiter',',','VariableNamingRule','preserve');
runs=cell(height(manifest),1);
for k=1:height(manifest),runs{k}=readtable(fullfile(folder,'data',manifest.File(k)),'Delimiter',',','VariableNamingRule','preserve');end
results=struct('p',p,'manifest',manifest,'runs',{runs});
end
