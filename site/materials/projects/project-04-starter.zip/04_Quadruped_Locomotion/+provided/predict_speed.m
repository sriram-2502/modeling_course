function v=predict_speed(theta,run,p)
% Exact ZOH two-state response evaluated with base-MATLAB filter (fast for fitting).
[A,B]=student.model_matrices(theta);E=expm([A(1:2,1:2) B(1:2);zeros(1,3)]*p.dt);
Ad=E(1:2,1:2);Bd=E(1:2,3);tr=trace(Ad);den=[1 -tr det(Ad)];
v0=run.Speed_mps(1);a0=0;n=height(run);
forced=filter([0 Bd(1) Ad(1,2)*Bd(2)-Ad(2,2)*Bd(1)],den,run.Command_mps);
free=filter([v0 Ad(1,1)*v0+Ad(1,2)*a0-tr*v0],den,[1;zeros(n-1,1)]);
v=forced+free;
end
