function response=simulate_model(theta,run,p)
% Exact interval propagation with zero-order-hold command; no Control Toolbox.
[A,B]=student.model_matrices(theta);E=expm([A B;zeros(1,4)]*p.dt);Ad=E(1:3,1:3);Bd=E(1:3,4);
states=zeros(height(run),3);states(1,:)=[run.Speed_mps(1) 0 0];
for k=1:height(run)-1,states(k+1,:)=(Ad*states(k,:)'+Bd*run.Command_mps(k))';end
assert(max(abs(states(:,1)-provided.predict_speed(theta,run,p)))<1e-9,'Fast/full predictors disagree.');
response=struct('t',run.Time_s,'states',states,'theta',theta);
end
