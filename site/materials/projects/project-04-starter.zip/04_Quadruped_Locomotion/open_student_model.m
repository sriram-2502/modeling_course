%% Edit and run your Simulink model before fitting any parameters
% These illustrative values are a diagnostic fixture, NOT a fitted answer.
projectFolder = fileparts(mfilename('fullpath'));
addpath(projectFolder);
setup = provided.load_project(projectFolder);
exampleRun = provided.get_run(setup, "F2");

K = 1;
zeta = 0.8;
omega_n = 6; % rad/s

% Named variables used by the standard blocks and the supplied verifier.
speedCommand = timeseries(exampleRun.Command_mps, exampleRun.Time_s);
gainInput = K * omega_n^2;
gainDamping = 2 * zeta * omega_n;
gainSpeed = omega_n^2;
initialSpeed = exampleRun.Speed_mps(1);
stopTime = exampleRun.Time_s(end);
outputTimes = exampleRun.Time_s';

modelPath = fullfile(setup.p.modelDir, 'go1_forward_model.slx');
open_system(modelPath);
disp('Complete the plant from your ODE, then save it. Log [v, dv/dt, p] as states.');
disp('When ready, remove the TODO in student.build_model and run the simulink checkpoint.');
