%% START HERE: a working example before you write any code
% Run this entire script. It opens the supplied CSV replay, with no model needed.
projectFolder = fileparts(mfilename('fullpath'));
addpath(projectFolder);
run(fullfile(projectFolder, 'replay_data.m'));

disp('1. In the viewer, press Play. Compare flat F1 and debris D1.');
disp('2. Run run_checkpoint("data") to inspect the input/output data.');
disp('3. Complete model_matrices and analyze_modes in +student.');
disp('4. Run open_student_model to build your independent Simulink plant.');
disp('5. Complete fit_parameters; use the flat, debris and validation checkpoints.');
disp('6. Freeze choices. Get metrics with results = run_checkpoint("final").');
disp('7. Complete compare_models and recommend using those metrics.');
disp('8. Run run_project, then animate_model_results.');
