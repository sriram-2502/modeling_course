% RUN_PROJECT Student suspension project. Run this script from any folder.
% Complete functions in +student; supplied tools live in +provided.
clearvars; close all; clc;
projectFolder = fileparts(mfilename('fullpath'));
addpath(projectFolder);
p = provided.load_project(projectFolder, project_settings());

%% Task 1a: Fit the three dampers.
fits.linearC = student.fit_linear(p.damper, p.fitInterval);
fits.nonlinear = student.fit_nonlinear(p.damper);
provided.check_fits(p, fits);
forceErrors = provided.plot_fits(p, fits);
save(fullfile(p.outputDir,'damper_fits.mat'),'fits');

%% Task 1b: Verify MATLAB against your independent Simulink model.
verification = provided.verify_simulink(p, fits);

%% Task 2a: Compare fitted models on the same designs and roads.
linear = provided.run_designs(p, fits, "linear");
nonlinear = provided.run_designs(p, fits, "nonlinear");
if any(linear.summary.Feasible)
    provisional = student.choose_design(linear.summary, p, "linear");
    provided.check_choice(provisional, linear.summary);
else
    provisional = struct('pair',[], 'reason', ...
        "No linear candidate is feasible; continue to CSV validation before deciding.");
    fprintf('%s\n',provisional.reason);
end

%% Task 2b: Validate predictions against the unchanged CSV reference.
reference = provided.run_designs(p, fits, "reference");
validation = provided.validate_models(p, linear, nonlinear, reference);

%% Task 2c: Choose one reference-feasible pair for both roads.
recommendation = student.choose_design(reference.summary, p, "reference");
provided.check_choice(recommendation, reference.summary);

%% Task 1c: Include your FINAL pair in the linear sine comparison.
sweep = provided.sine_sweep(p, fits, recommendation.pair);
provided.plot_validation(p, linear, nonlinear, reference, recommendation.pair);

%% Save everything needed for your report and code ZIP.
results = struct('parameters',p, 'fits',fits, 'forceErrors',forceErrors, ...
    'verification',verification, 'linear',linear, 'nonlinear',nonlinear, ...
    'provisional',provisional, 'reference',reference, 'validation',validation, ...
    'recommendation',recommendation, 'sweep',sweep);
save(fullfile(p.outputDir,'student_results.mat'),'results');
% Optional supplied playback: run animate_results.m after this script finishes.
fprintf('\nFinal pair: S%d + D%d\n%s\nOutputs: %s\n', ...
    recommendation.pair, recommendation.reason, p.outputDir);
