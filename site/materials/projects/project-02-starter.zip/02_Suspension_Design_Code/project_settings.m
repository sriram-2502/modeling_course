function settings = project_settings
% PROJECT_SETTINGS Your analysis choices; assignment constants are supplied.
settings.fitInterval = [-0.25 0.25]; % m/s: justify retaining or revising this.

% Start with all nine pairs, [spring index, damper index].
[spring,damper] = ndgrid(1:3,1:3);
settings.designPairs = [spring(:) damper(:)];
% For a smaller study, include [2 2] and at least two distinct alternatives.
end
