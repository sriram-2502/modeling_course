% ANIMATE_RESULTS Replay saved student results without running the analysis.
% Run this script from any working directory. Road/model/design controls are
% in the animation window. Run run_project.m first to generate/update the logs.
animationFolder = fileparts(mfilename('fullpath'));
addpath(animationFolder);
animationDataFile = fullfile(animationFolder,'results','student_results.mat');
if ~isfile(animationDataFile)
    error('suspension:MissingResults', ...
        'Saved results not found: %s\nRun the student run_project.m first.', ...
        animationDataFile);
end
animationData = load(animationDataFile,'results');
if ~isfield(animationData,'results')
    error('suspension:MissingResults', ...
        'The saved file has no results structure. Run the student run_project.m again.');
end
animationFigure = provided.animate_results(animationData.results);
clear animationFolder animationDataFile animationData
