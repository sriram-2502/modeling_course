% CHECK_SETUP Run this before editing any student functions.
folder=fileparts(mfilename('fullpath')); addpath(folder);
p=provided.load_project(folder,project_settings());
assert(exist('ode45','file')~=0,'MATLAB ODE tools are required.');
assert(exist('ss','file')~=0 && exist('lsim','file')~=0,'Control System Toolbox is required.');
assert(exist('Simulink.SimulationInput','class')==8,'Simulink is required.');
assert(isfile(fullfile(p.modelDir,'student_quarter_car.slx')),'The Simulink scaffold is missing.');
for road=1:2
    t=provided.time_grid(p,road); [r,rdot]=provided.road_input(t,p,road);
    assert(all(isfinite([r;rdot])) && all(diff(t)>0));
    query=p.entryTime+.37; h=1e-5;
    [~,analytic]=provided.road_input(query,p,road);
    before=provided.road_input(query-h,p,road); after=provided.road_input(query+h,p,road);
    assert(abs((after-before)/(2*h)-analytic)<1e-6,'Road derivative check failed.');
end
fprintf('Setup OK: data, roads, paths, scaffold, and required tools found.\n');
fprintf('Next: open docs/student_code_guide.pdf and complete +student functions.\n');
