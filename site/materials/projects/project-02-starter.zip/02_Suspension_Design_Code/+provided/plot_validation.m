function plot_validation(p,linear,nonlinear,reference,pair)
% PLOT_VALIDATION Plot one selected pair without replacing numerical validation.
k=find(all(p.designPairs==pair,2),1); f=figure('Visible','off'); tiledlayout(2,1);
for road=1:2
    nexttile; hold on;
    batches={reference,linear,nonlinear}; labels={'CSV reference','Linear fit','Nonlinear fit'};
    styles={'-','--',':'};
    for model=1:3
        r=batches{model}.responses{k,road};
        if r.completed, plot(r.t,r.bodyAcceleration,styles{model},'DisplayName',labels{model}); end
    end
    grid on; xlabel('Time (s)'); ylabel('Body acceleration (m/s^2)');
    title(sprintf('S%d + D%d: Test %s',pair,p.roads(road).name)); legend('Location','best');
end
provided.save_plot(f,p,'selected_validation');
end
