function check_choice(choice,summary)
% CHECK_CHOICE Validate the interface and feasibility, without selecting a winner.
assert(isstruct(choice) && isfield(choice,'pair') && isfield(choice,'reason'), ...
    'Return choice.pair and choice.reason from choose_design.');
assert(isequal(size(choice.pair),[1 2]) && all(ismember(choice.pair,1:3)));
row=summary.Spring==choice.pair(1) & summary.Damper==choice.pair(2);
assert(nnz(row)==1 && summary.Feasible(row), ...
    'Choose a tested pair feasible on both roads; otherwise revise your candidate set.');
assert(isstring(choice.reason) && isscalar(choice.reason) && strlength(strtrim(choice.reason))>0, ...
    'Explain your selection in choice.reason as a nonempty string.');
end
