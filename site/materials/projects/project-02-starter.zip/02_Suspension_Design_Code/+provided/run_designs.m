function batch = run_designs(p,fits,mode)
% RUN_DESIGNS Same road settings and ODE for every tested spring/damper pair.
responses=cell(size(p.designPairs,1),2); rows=struct([]);
for k=1:size(p.designPairs,1)
    pair=p.designPairs(k,:);
    fprintf('%s model: S%d + D%d\n',mode,pair);
    for road=1:2
        response=provided.simulate_road(p,fits,pair,road,mode);
        responses{k,road}=response; m=response.metric;
        row=struct('Spring',pair(1),'Damper',pair(2),'Road',p.roads(road).name, ...
            'Model',mode,'Completed',response.completed,'RMS_mps2',m.rmsAcceleration, ...
            'Peak_mps2',m.peakAcceleration,'Travel_mm',1000*m.maxTravel, ...
            'MinLoadFraction',m.minLoadFraction,'MaxDamperSpeed_mps',m.maxDamperSpeed, ...
            'Feasible',m.feasible,'RoadBand',m.roadBand,'FailureReason',response.failureReason);
        if isempty(rows), rows=row; else, rows(end+1)=row; end %#ok<AGROW>
    end
end
metrics=struct2table(rows); summary=provided.summarize_designs(metrics,p);
writetable(metrics,fullfile(p.outputDir,mode+"_metrics.csv"));
writetable(summary,fullfile(p.outputDir,mode+"_summary.csv"));
batch=struct('metrics',metrics,'summary',summary,'responses',{responses});
end
