function [w,dw] = road_taper(distance,roadLength,taperLength)
% ROAD_TAPER Half-cosine window; dw is derivative with respect to distance.
w=zeros(size(distance)); dw=w;
inside=distance>=0 & distance<=roadLength; w(inside)=1;
enter=inside & distance<taperLength;
leave=inside & distance>roadLength-taperLength;
w(enter)=(1-cos(pi*distance(enter)/taperLength))/2;
dw(enter)=pi/(2*taperLength)*sin(pi*distance(enter)/taperLength);
tail=roadLength-distance(leave);
w(leave)=(1-cos(pi*tail/taperLength))/2;
dw(leave)=-pi/(2*taperLength)*sin(pi*tail/taperLength);
end
