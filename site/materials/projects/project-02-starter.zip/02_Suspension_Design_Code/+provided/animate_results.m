function fig = animate_results(results,options)
% ANIMATE_RESULTS Replay computed responses; does not rerun the solver.
% Supplied visualization only: replay YOUR saved responses and chosen pair.
% Options.Visible='off' and Options.AutoPlay=false support graphics checks.
% Close the viewer to release its playback timer. The function is nonblocking.
% Lec14 moving-car style, with parallel tire spring/damper inside the wheel.
if nargin<2, options=struct; end
if ~isfield(options,'Visible'), options.Visible='on'; end
if ~isfield(options,'AutoPlay'), options.AutoPlay=true; end
if ~isfield(options,'Maximize'), options.Maximize=true; end
p=results.parameters;
colors=[0.16 0.43 0.78; 0.85 0.34 0.12];
labels={'Baseline S2+D2',sprintf('Your choice S%d+D%d', ...
    results.recommendation.pair(1),results.recommendation.pair(2))};
playbackPairs=[2 2; results.recommendation.pair];
linearCoefficients=results.fits.linearC;
old=findall(groot,'Type','figure','Tag','StudentSuspensionPlayback');
if ~isempty(old), close(old); end
fig=figure('Name','Suspension project | animated response playback', ...
    'NumberTitle','off','Color','w','Position',[90 70 1200 760], ...
    'Visible',options.Visible,'Tag','StudentSuspensionPlayback');
if options.Maximize && strcmp(options.Visible,'on'), fig.WindowState='maximized'; end
uicontrol(fig,'Style','text','Units','normalized','Position',[.02 .95 .08 .025], ...
    'String','Road test','BackgroundColor','w','HorizontalAlignment','left');
roadMenu=uicontrol(fig,'Style','popupmenu','Units','normalized', ...
    'Position',[.10 .945 .17 .035],'String',{'A: speed hump','B: rough road'}, ...
    'Callback',@changeCase,'Tag','PlaybackRoad');
modeMenu=uicontrol(fig,'Style','popupmenu','Units','normalized', ...
    'Position',[.29 .945 .23 .035], ...
    'String',{'CSV reference','Linear fit','Nonlinear fit'}, ...
    'Callback',@changeCase,'Tag','PlaybackModel');
playButton=uicontrol(fig,'Style','pushbutton','Units','normalized', ...
    'Position',[.55 .945 .09 .038],'String','Play','Callback',@togglePlay, ...
    'Tag','PlaybackPlay');
uicontrol(fig,'Style','pushbutton','Units','normalized', ...
    'Position',[.65 .945 .09 .038],'String','Restart','Callback',@restart, ...
    'Tag','PlaybackRestart');
speedMenu=uicontrol(fig,'Style','popupmenu','Units','normalized', ...
    'Position',[.76 .945 .10 .035],'String',{'0.25x','0.5x','1x','2x','4x'}, ...
    'Value',3,'Tag','PlaybackSpeed');
uicontrol(fig,'Style','text','Units','normalized','Position',[.87 .945 .11 .035], ...
    'String','Playback speed','BackgroundColor','w');
status=uicontrol(fig,'Style','text','Units','normalized', ...
    'Position',[.02 .895 .49 .035],'BackgroundColor','w','FontSize',10, ...
    'HorizontalAlignment','left');
designMenu=uicontrol(fig,'Style','popupmenu','Units','normalized', ...
    'Position',[.76 .89 .22 .035],'String',labels, ...
    'Callback',@changeDesign,'Tag','PlaybackDesign');
cameraMenu=uicontrol(fig,'Style','popupmenu','Units','normalized', ...
    'Position',[.53 .89 .21 .035],'String',{'Camera: Global','Camera: Follow car'}, ...
    'Value',2,'Callback',@changeCamera,'Tag','PlaybackCamera');
carAxes=axes(fig,'Position',[.07 .53 .64 .31]);
infoBox=uicontrol(fig,'Style','text','Units','normalized', ...
    'Position',[.755 .52 .235 .335],'BackgroundColor',[.95 .97 .99], ...
    'ForegroundColor',[.12 .2 .28],'FontSize',10, ...
    'HorizontalAlignment','left','Tag','PlaybackInfo');
traceAxes(1)=axes(fig,'Position',[.08 .31 .86 .15]);
traceAxes(2)=axes(fig,'Position',[.08 .105 .86 .15]);
seek=uicontrol(fig,'Style','slider','Units','normalized', ...
    'Position',[.08 .025 .75 .028],'Min',0,'Max',1,'Value',0, ...
    'Callback',@seekTime,'Tag','PlaybackTime');
uicontrol(fig,'Style','text','Units','normalized','Position',[.84 .02 .12 .03], ...
    'String','Seek / scrub time','BackgroundColor','w');
clock=tic; currentTime=0; playing=false; lastTick=0;
traces=cell(1,2); drawings=cell(1,2); data=cell(1,2);
cursors=gobjects(1,2); movingDots=gobjects(2,2);
duration=1; gain=1; displaySpeed=1; caseReady=false;
playTimer=timer('ExecutionMode','fixedSpacing','Period',.033, ...
    'BusyMode','drop','TimerFcn',@tick,'Name','StudentSuspensionProjectPlayback');
setappdata(fig,'PlaybackTimer',playTimer);
fig.CloseRequestFcn=@closeViewer;
loadCase();
if options.AutoPlay, togglePlay(); end

    function loadCase()
        mode=modeMenu.Value;
        collections={results.reference.responses,results.linear.responses,results.nonlinear.responses};
        cases=collections{mode}; road=roadMenu.Value;
        pairs=[2 2; results.recommendation.pair];
        data=cell(1,2);
        for c=1:2
            row=find(all(p.designPairs==pairs(c,:),2),1);
            if ~isempty(row) && row<=size(cases,1) && road<=size(cases,2)
                data{c}=cases{row,road};
            end
        end
        caseReady=false;
        for c=1:2
            d=data{c};
            if ~isstruct(d) || ~isfield(d,'completed') || ~d.completed || ...
                    ~all(isfield(d,{'t','states','road','bodyAcceleration'})) || numel(d.t)<2
                reason='No completed saved response for this case.';
                if isstruct(d) && isfield(d,'failureReason') && strlength(string(d.failureReason))>0
                    reason=char(d.failureReason);
                end
                unavailable(sprintf('%s | Road %s: %s',labels{c}, ...
                    char(p.roads(road).name),reason));
                return;
            end
            % These are field aliases for drawing, not a second dynamics model.
            d.y=d.states; d.r=d.road; data{c}=d;
        end
        caseReady=true; playButton.Enable='on'; seek.Enable='on';
        % Compare only the common computed interval; never extrapolate a failed run.
        duration=min(data{1}.t(end),data{2}.t(end));
        currentTime=0; seek.Value=0;
        buildDrawing();
        for a=1:2
            % Reset also removes hidden cursor/dot handles from the previous case.
            ax=traceAxes(a); cla(ax,'reset'); hold(ax,'on'); grid(ax,'on');
            for k=1:2
                d=data{k};
                if a==1, values=1e3*d.y(:,1); else, values=d.bodyAcceleration; end
                traces{a,k}=plot(ax,d.t,values,'Color',colors(k,:),'LineWidth',1.3);
                movingDots(a,k)=plot(ax,0,0,'o','Color',colors(k,:), ...
                    'MarkerFaceColor',colors(k,:),'HandleVisibility','off');
            end
            if a==1
                roadLine=plot(ax,data{1}.t,1e3*data{1}.r,'k:','LineWidth',1);
                ylabel(ax,'Displacement (mm)');
                legend(ax,[traces{a,1},traces{a,2},roadLine], ...
                    [labels,{'Road'}],'Location','northoutside','Orientation','horizontal');
            else
                ylabel(ax,'Body accel. (m/s^2)'); xlabel(ax,'Time (s)');
            end
            xlim(ax,[0 duration]);
            cursors(a)=xline(ax,0,'Color',[.3 .3 .3],'HandleVisibility','off');
        end
        lastTick=toc(clock); renderFrame();
    end

    function renderFrame()
        for k=1:2
            d=data{k};
            z=interp1(d.t,[d.y(:,1),d.y(:,3),d.r,d.bodyAcceleration],currentTime);
            if k==designMenu.Value
                h=drawings{1}; worldX=displaySpeed*currentTime;
                if cameraMenu.Value==2
                    cameraOffset=worldX; x=0;
                    xlim(carAxes,[-2 2]);
                else
                    cameraOffset=0; x=worldX;
                    xlim(carAxes,[-1.5 displaySpeed*duration+1.5]);
                end
                h.road.XData=h.road.UserData-cameraOffset;
                body=1.20+gain*z(1); road=gain*z(3);
                % Drawing-only clearance leaves room for the internal tire elements.
                % Raw simulated displacement remains unchanged in the plots/metrics.
                wheel=max(.35+gain*z(2),road+.30);
                updateRectangle(h.body,x,body,.90,.28);
                updateRectangle(h.unsprung,x,wheel,.32,.18);
                theta=linspace(0,2*pi,150);
                set(h.wheel,'XData',x+.27*cos(theta),'YData',wheel+.27*sin(theta));
                updateSpring(h.spring,x-.075,body-.14,wheel+.09);
                updateDamper(h.damper,x+.075,body-.14,wheel+.09);
                % Tire spring and damper share upper and lower attachments.
                upper=wheel-.09; lower=max(road+.11,wheel-.22);
                updateSpring(h.tire,x-.075,upper,lower);
                updateCompactDamper(h.tireDamper,x+.075,upper,lower);
                set(h.tireUpperBar,'XData',x+[-.11 .11],'YData',[upper upper]);
                set(h.tireLowerBar,'XData',x+[-.11 .11],'YData',[lower lower]);
                set(h.contactRod,'XData',[x x],'YData',[road lower]);
                set(h.contact,'XData',x,'YData',road);
                h.info.String=sprintf('Time = %.2f s',currentTime);
                updateInfo(d,z,k);
            end
            set(movingDots(1,k),'XData',currentTime,'YData',1e3*z(1));
            set(movingDots(2,k),'XData',currentTime,'YData',z(4));
        end
        for a=1:2, cursors(a).Value=currentTime; end
        seek.Value=currentTime/duration;
        modes={'CSV reference','Linear fit','Nonlinear fit'};
        suffix='';
        if ~all(cellfun(@(d) d.completed,data)), suffix=' | incomplete response: common interval only'; end
        status.String=sprintf('%s | Road %s | %.2f / %.2f s%s', ...
            modes{modeMenu.Value},char(p.roads(roadMenu.Value).name),currentTime,duration,suffix);
        drawnow limitrate;
    end

    function tick(~,~)
        if ~isgraphics(fig), return; end
        now=toc(clock); elapsed=now-lastTick; lastTick=now;
        speeds=[.25 .5 1 2 4];
        currentTime=min(duration,currentTime+elapsed*speeds(speedMenu.Value));
        renderFrame();
        if currentTime>=duration, pausePlayback(); end
    end

    function togglePlay(varargin)
        if ~caseReady, return; end
        if playing, pausePlayback(); return; end
        if currentTime>=duration, currentTime=0; end
        playing=true; playButton.String='Pause'; lastTick=toc(clock);
        start(playTimer);
    end

    function pausePlayback()
        stop(playTimer); playing=false;
        if isgraphics(playButton), playButton.String='Play'; end
    end

    function restart(varargin)
        if ~caseReady, return; end
        pausePlayback(); currentTime=0; renderFrame(); togglePlay();
    end

    function seekTime(varargin)
        if ~caseReady, return; end
        currentTime=seek.Value*duration; lastTick=toc(clock); renderFrame();
    end

    function changeCase(varargin)
        resume=playing; pausePlayback(); loadCase();
        if resume && caseReady, togglePlay(); end
    end

    function changeDesign(varargin)
        if ~caseReady, return; end
        buildDrawing(); renderFrame();
    end

    function changeCamera(varargin)
        if ~caseReady, return; end
        updateCameraLabel(); renderFrame();
        % Camera changes must not count UI work as elapsed playback time.
        lastTick=toc(clock);
    end

    function updateCameraLabel()
        if cameraMenu.Value==2
            xlabel(carAxes,'Distance from car (display m)');
        else
            xlabel(carAxes,'Vehicle travel direction, x (display m; 1 m/s animation speed)');
        end
    end

    function buildDrawing()
        % Match the lecture's fixed road, centered patches, wheel, and colors.
        ax=carAxes; cla(ax,'reset'); hold(ax,'on'); grid(ax,'on'); box(ax,'on');
        axis(ax,'equal');
        xRoad=linspace(-2.5,displaySpeed*duration+2.5,3000);
        zRoad=gain*interp1(data{1}.t,data{1}.r,xRoad/displaySpeed,'linear',0);
        ymin=min(zRoad)-.15;
        ymax=1.20+.14+max(cellfun(@(d) max(gain*d.y(:,1)),data))+.25;
        xlim(ax,[xRoad(1) xRoad(end)]); ylim(ax,[ymin ymax]);
        xlabel(ax,'Vehicle travel direction, x (display m; 1 m/s animation speed)');
        ylabel(ax,'Vertical displacement, z (m)');
        title(ax,{['Quarter-car | ' labels{designMenu.Value}], ...
            sprintf('Road %s | schematic tire; displacement scale 1:1', ...
            char(p.roads(roadMenu.Value).name))}, ...
            'FontSize',11,'FontWeight','bold');
        h.road=plot(ax,xRoad,zRoad,'k-','LineWidth',3,'Tag','PlaybackRoadProfile');
        h.road.UserData=xRoad;
        yline(ax,0,'--','Color',[.5 .5 .5]);
        h.body=drawRectangle(ax,0,1.20,.90,.28,[.20 .55 .95]);
        h.unsprung=drawRectangle(ax,0,.35,.32,.18,[.95 .70 .20]);
        theta=linspace(0,2*pi,150);
        h.wheel=plot(ax,.27*cos(theta),.35+.27*sin(theta),'k-','LineWidth',2.5, ...
            'Tag','PlaybackWheel');
        % Symmetric attachment centers; both elements fit on the yellow block.
        h.spring=drawSpring(ax,-.075,1.06,.44,.06,10);
        h.spring.Tag='PlaybackSuspensionSpring';
        h.damper=drawDamper(ax,.075,1.06,.44);
        h.damper.lower.Tag='PlaybackSuspensionDamper';
        h.tire=drawSpring(ax,-.075,.26,.13,.026,4);
        h.tire.Tag='PlaybackTireSpring';
        h.tireDamper=drawCompactDamper(ax,.075,.26,.13);
        h.tireUpperBar=plot(ax,[-.11 .11],[.26 .26],'k-','LineWidth',1.5, ...
            'Tag','PlaybackTireUpperBar');
        h.tireLowerBar=plot(ax,[-.11 .11],[.13 .13],'k-','LineWidth',1.5, ...
            'Tag','PlaybackTireLowerBar');
        h.contactRod=plot(ax,[0 0],[0 .13],'-','Color',[.85 .1 .1], ...
            'LineWidth',2.5,'Tag','PlaybackContactRod');
        h.contact=plot(ax,0,0,'ro','MarkerFaceColor','r','MarkerSize',7);
        h.info=text(ax,.02,.96,'','Units','normalized','FontSize',12, ...
            'FontWeight','bold','VerticalAlignment','top');
        drawings{1}=h;
        updateCameraLabel();
    end

    function unavailable(message)
        pausePlayback(); playButton.Enable='off'; seek.Enable='off';
        for a=1:2, cla(traceAxes(a),'reset'); end
        cla(carAxes,'reset'); axis(carAxes,'off');
        text(carAxes,.02,.65,{'Saved response unavailable',message, ...
            'Choose another road/model, or correct the case and rerun run_project.m.'}, ...
            'Units','normalized','Interpreter','none','FontSize',11);
        status.String=message; infoBox.String='No completed data for this case.';
        drawnow;
    end

    function updateInfo(response,z,index)
        pair=playbackPairs(index,:); metric=response.metric;
        modes={'CSV interpolation','Linear fit','Nonlinear fit'};
        if metric.feasible, feasible='Yes'; else, feasible='No'; end
        lines={labels{index}; ...
            sprintf('Spring k_s = %.0f N/m',p.springs(pair(1))); ...
            sprintf('Damper D%d | %s',pair(2),modes{modeMenu.Value}); ...
            sprintf('c_eq (linear fit) = %.1f N s/m',linearCoefficients(pair(2))); ...
            sprintf('Tire: k_t = %.0f N/m',p.kt); ...
            sprintf('Tire: c_t = %.0f N s/m',p.ct); ...
            sprintf('Road %s | speed %.1f km/h',char(p.roads(roadMenu.Value).name), ...
                3.6*p.roads(roadMenu.Value).speed); ...
            sprintf('Now: travel = %+.1f mm',1000*(z(1)-z(2))); ...
            sprintf('Body acceleration = %+.2f m/s^2',z(4)); ...
            sprintf('Test RMS accel. = %.3f m/s^2',metric.rmsAcceleration); ...
            sprintf('Test max travel = %.1f mm',1000*metric.maxTravel); ...
            sprintf('Road band: %s | feasible: %s',char(metric.roadBand),feasible)};
        tooltip='c_eq describes the linear fit only; it is not a constant damping coefficient for CSV/nonlinear playback.';
        if modeMenu.Value==3
            params=results.fits.nonlinear.parameters(pair(2),:);
            lines{end+1}='Nonlinear parameters (saved order):';
            lines{end+1}=mat2str(params(1:min(6,numel(params))),3);
            if numel(params)>6, lines{end}=[lines{end} ' ...']; end
            tooltip=sprintf('%s\nFull parameter row: %s\nParameter definitions/units follow your fitted model.', ...
                tooltip,mat2str(params,6));
        end
        infoBox.String=lines; infoBox.TooltipString=tooltip;
    end

    function closeViewer(varargin)
        stop(playTimer); delete(playTimer); delete(fig);
    end
end

function h=drawCompactDamper(ax,x,upper,lower)
% Smaller version of the lecture damper for the inside of the tire.
h.upper=patch(ax,nan,nan,[.65 .65 .65],'EdgeColor','k','LineWidth',1);
h.lower=patch(ax,nan,nan,[.45 .45 .45],'EdgeColor','k','LineWidth',1);
h.rod=plot(ax,nan,nan,'k-','LineWidth',1.5,'Tag','PlaybackTireDamper');
updateCompactDamper(h,x,upper,lower);
end

function updateCompactDamper(h,x,upper,lower)
width=.022; height=min(.028,.22*(upper-lower));
set(h.upper,'XData',x+[-width width width -width], ...
    'YData',[upper-height upper-height upper upper]);
set(h.lower,'XData',x+[-width width width -width], ...
    'YData',[lower lower lower+height lower+height]);
set(h.rod,'XData',[x x],'YData',[upper-height lower+height]);
end

% Drawing helpers retained from the instructor Lec14 demo.
function h = drawRectangle(ax,x_center,y_center,width,height,color)

    x = x_center + ...
        [-width/2,width/2,width/2,-width/2];

    y = y_center + ...
        [-height/2,-height/2,height/2,height/2];

    h = patch(ax,x,y,color, ...
        'EdgeColor','k', ...
        'LineWidth',1.5);

end


function updateRectangle(h,x_center,y_center,width,height)

    x = x_center + ...
        [-width/2,width/2,width/2,-width/2];

    y = y_center + ...
        [-height/2,-height/2,height/2,height/2];

    set(h,'XData',x,'YData',y);

end


function h = drawSpring(ax,x_center,y_top,y_bottom,width,number_of_coils)

    number_of_points = 2*number_of_coils + 1;

    y = linspace(y_top,y_bottom,number_of_points);

    x = x_center + width*(-1).^(0:number_of_points-1);

    % Force spring endpoints to lie on centerline
    x(1)   = x_center;
    x(end) = x_center;

    h = plot(ax,x,y, ...
        'Color',[0.1 0.1 0.1], ...
        'LineWidth',2);

end


function updateSpring(h,x_center,y_top,y_bottom)

    old_x = get(h,'XData');

    number_of_points = numel(old_x);

    spring_width = ...
        (max(old_x)-min(old_x))/2;

    y = linspace(y_top,y_bottom,number_of_points);

    x = x_center + ...
        spring_width*(-1).^(0:number_of_points-1);

    % Force spring endpoints to lie on centerline
    x(1)   = x_center;
    x(end) = x_center;

    set(h,'XData',x,'YData',y);

end


function h = drawDamper(ax,x_center,y_top,y_bottom)

    damper_width  = 0.07;
    damper_height = 0.10;

    % Upper damper housing
    h.upper = patch(ax, ...
        x_center + ...
        [-damper_width,damper_width,damper_width,-damper_width], ...
        [ ...
            y_top-damper_height, ...
            y_top-damper_height, ...
            y_top, ...
            y_top], ...
        [0.65 0.65 0.65], ...
        'EdgeColor','k', ...
        'LineWidth',1.2);

    % Lower damper housing
    h.lower = patch(ax, ...
        x_center + ...
        [-damper_width,damper_width,damper_width,-damper_width], ...
        [ ...
            y_bottom, ...
            y_bottom, ...
            y_bottom+damper_height, ...
            y_bottom+damper_height], ...
        [0.45 0.45 0.45], ...
        'EdgeColor','k', ...
        'LineWidth',1.2);

    % Damper rod
    h.rod = plot(ax, ...
        [x_center,x_center], ...
        [y_top-damper_height,y_bottom+damper_height], ...
        'k-', ...
        'LineWidth',2);

end


function updateDamper(h,x_center,y_top,y_bottom)

    damper_width  = 0.07;
    damper_height = 0.10;

    set(h.upper, ...
        'XData',x_center + ...
        [-damper_width,damper_width,damper_width,-damper_width], ...
        'YData',[ ...
            y_top-damper_height, ...
            y_top-damper_height, ...
            y_top, ...
            y_top]);

    set(h.lower, ...
        'XData',x_center + ...
        [-damper_width,damper_width,damper_width,-damper_width], ...
        'YData',[ ...
            y_bottom, ...
            y_bottom, ...
            y_bottom+damper_height, ...
            y_bottom+damper_height]);

    set(h.rod, ...
        'XData',[x_center,x_center], ...
        'YData',[ ...
            y_top-damper_height, ...
            y_bottom+damper_height]);

end
