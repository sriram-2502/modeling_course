function errors = validate_models(p,linear,nonlinear,reference)
% VALIDATE_MODELS Call the STUDENT comparison function for matching cases.
rows=struct([]); batches={linear,nonlinear}; modes=["linear","nonlinear"];
fields={'rmsErrorPercent','accelerationErrorRMS','velocityMin','velocityMax','outsideFitFraction'};
for model=1:2
    batch=batches{model};
    for k=1:size(p.designPairs,1)
        for road=1:2
            predicted=batch.responses{k,road}; truth=reference.responses{k,road};
            complete=predicted.completed && truth.completed;
            comparison=cell2struct(num2cell(nan(1,5)),fields,2);
            if complete
                comparison=student.compare_responses(predicted,truth,p);
                assert(isstruct(comparison) && all(isfield(comparison,fields)), ...
                    'compare_responses must return every documented comparison field.');
                for j=1:numel(fields)
                    value=comparison.(fields{j});
                    assert(isnumeric(value) && isscalar(value) && isfinite(value), ...
                        'Each comparison field must be a finite numeric scalar.');
                end
                assert(comparison.accelerationErrorRMS>=0 && ...
                    comparison.velocityMin<=comparison.velocityMax && ...
                    comparison.outsideFitFraction>=0 && comparison.outsideFitFraction<=1);
            end
            pair=p.designPairs(k,:);
            row=struct('Spring',pair(1),'Damper',pair(2),'Road',p.roads(road).name, ...
                'Model',modes(model),'BothCompleted',complete, ...
                'RMS_Error_percent',comparison.rmsErrorPercent, ...
                'AccelerationDifferenceRMS_mps2',comparison.accelerationErrorRMS, ...
                'ReferenceVelocityMin_mps',comparison.velocityMin, ...
                'ReferenceVelocityMax_mps',comparison.velocityMax, ...
                'OutsideFitFraction',comparison.outsideFitFraction);
            if isempty(rows), rows=row; else, rows(end+1)=row; end %#ok<AGROW>
        end
    end
end
errors=struct2table(rows);
writetable(errors,fullfile(p.outputDir,'model_validation.csv'));
end
