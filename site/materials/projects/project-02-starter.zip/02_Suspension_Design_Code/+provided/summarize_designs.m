function summary = summarize_designs(metrics,p)
% SUMMARIZE_DESIGNS One row per pair, in settings.designPairs order.
rows=struct([]);
for k=1:size(p.designPairs,1)
    pair=p.designPairs(k,:); m=metrics(metrics.Spring==pair(1) & metrics.Damper==pair(2),:);
    a=m.RMS_mps2(m.Road=="A"); b=m.RMS_mps2(m.Road=="B");
    feasible=all(m.Feasible) && all(m.Completed);
    score=max([a/p.roads(1).good b/p.roads(2).good]);
    if ~feasible || ~isfinite(score), score=Inf; end
    row=struct('Spring',pair(1),'Damper',pair(2),'RMS_A_mps2',a,'RMS_B_mps2',b, ...
        'Feasible',feasible,'OverallBand',provided.performance_band([a b], ...
        [p.roads.good],[p.roads.acceptable],feasible),'WorstNormalizedRMS',score);
    if isempty(rows), rows=row; else, rows(end+1)=row; end %#ok<AGROW>
end
summary=struct2table(rows);
end
