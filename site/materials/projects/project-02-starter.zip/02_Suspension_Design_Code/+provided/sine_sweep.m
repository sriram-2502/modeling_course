function sweep = sine_sweep(p,fits,selectedPair)
% SINE_SWEEP Supplied analysis helper; it probes YOUR linear ODE for A and B.
pairs=unique([2 2;selectedPair],'rows','stable'); n=numel(p.frequencies);
ratio=zeros(n,size(pairs,1)); exact=ratio; modal=struct([]);
for k=1:size(pairs,1)
    pair=pairs(k,:); force=@(v) fits.linearC(pair(2))*v;
    zeroRoad=@(~) deal(0,0); unitRoad=@(~) deal(1,0); unitVelocity=@(~) deal(0,1);
    rhs=@(x,road) student.quarter_car_rhs(0,x,p,p.springs(pair(1)),force,road);
    origin=rhs(zeros(4,1),zeroRoad); assert(norm(origin)<1e-10,'Zero input/state must give zero derivative.');
    A=zeros(4); basis=eye(4);
    for j=1:4, A(:,j)=rhs(basis(:,j),zeroRoad)-origin; end
    B=[rhs(zeros(4,1),unitRoad)-origin rhs(zeros(4,1),unitVelocity)-origin];
    probe=[.01;.03;-.02;-.04];
    assert(norm(rhs(probe,zeroRoad)-A*probe)<1e-8,'The linear-force ODE must be linear in its states.');
    poles=eig(A); decay=-max(real(poles));
    assert(decay>0,'Your linear ODE has unstable/nondecaying poles: check signs.');
    system=ss(A,B,eye(4),zeros(4,2));
    for j=1:n
        frequency=p.frequencies(j); omega=2*pi*frequency;
        dt=min(p.dt,1/(100*frequency)); settle=max(8/frequency,12/decay);
        t=(0:dt:settle+5/frequency)';
        input=p.sineAmplitude*[sin(omega*t) omega*cos(omega*t)];
        states=lsim(system,input,t,zeros(4,1)); use=t>=t(end)-5/frequency;
        coefficients=[sin(omega*t(use)) cos(omega*t(use)) ones(nnz(use),1)]\states(use,1);
        ratio(j,k)=hypot(coefficients(1),coefficients(2))/p.sineAmplitude;
        harmonic=(1i*omega*eye(4)-A)\(B(:,1)+1i*omega*B(:,2));
        exact(j,k)=abs(harmonic(1));
    end
    modal(k).pair=pair; modal(k).poles=poles; %#ok<AGROW>
    modal(k).naturalHz=abs(poles)/(2*pi); modal(k).dampingRatio=-real(poles)./abs(poles);
end
sweep=struct('frequency',p.frequencies(:),'pairs',pairs,'ratio',ratio,'exactRatio',exact,'modal',modal);
sweep.maxRelativeDifference=max(abs(ratio-exact)./max(exact,1e-10),[],'all');
assert(sweep.maxRelativeDifference<.003,'Measured sine gain does not match the harmonic check.');
rows=table;
for k=1:size(pairs,1)
    block=table(repmat(pairs(k,1),n,1),repmat(pairs(k,2),n,1),p.frequencies(:),ratio(:,k),exact(:,k), ...
        'VariableNames',{'Spring','Damper','Frequency_Hz','MeasuredGain','HarmonicGain'});
    rows=[rows;block]; %#ok<AGROW>
end
writetable(rows,fullfile(p.outputDir,'sine_sweep.csv'));
f=figure('Visible','off'); plot(p.frequencies,ratio,'LineWidth',1.3);
yline(1,':','HandleVisibility','off'); grid on; xlabel('Frequency (Hz)'); ylabel('Body / road amplitude');
legend(compose('S%d + D%d',pairs(:,1),pairs(:,2)),'Location','northeast');
provided.save_plot(f,p,'sine_response');
end
