function [r,rdot] = road_input(t,p,roadIndex)
% ROAD_INPUT Prescribed height and analytic vertical road velocity.
road=p.roads(roadIndex); distance=road.speed*(t-p.entryTime);
r=zeros(size(t)); rdot=r; inside=distance>=0 & distance<=road.length;
q=distance(inside);
if roadIndex==1
    theta=2*pi*q/road.length;
    r(inside)=road.height/2*(1-cos(theta));
    rdot(inside)=road.speed*road.height*pi/road.length*sin(theta);
else
    [w,dw]=provided.road_taper(q,road.length,p.taperLength);
    h=.008*sin(2*pi*q/5)+.002*sin(2*pi*q/1.5);
    dh=.008*2*pi/5*cos(2*pi*q/5)+.002*2*pi/1.5*cos(2*pi*q/1.5);
    r(inside)=w.*h; rdot(inside)=road.speed*(dw.*h+w.*dh);
end
end
