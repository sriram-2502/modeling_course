function verification = verify_simulink(p,fits)
% VERIFY_SIMULINK Baseline Test A; scalar variables match the scaffold names.
matlab=provided.simulate_road(p,fits,[2 2],1,"linear");
modelPath=student.build_simulink_model(p);
assert(isfile(modelPath),'Save the completed Simulink model before verification.');
load_system(modelPath); [~,name]=fileparts(modelPath);
cleanup=onCleanup(@() close_system(name,0));
t=matlab.t; road=p.roads(1);
sourceTime=unique([(0:.0002:t(end))';p.entryTime; ...
    p.entryTime+road.length/road.speed;t(end)]);
[r,rdot]=provided.road_input(sourceTime,p,1);
input=Simulink.SimulationInput(name);
input=input.setVariable('roadHeight',timeseries(r,sourceTime));
input=input.setVariable('roadVelocity',timeseries(rdot,sourceTime));
input=input.setVariable('ks',p.springs(2)); input=input.setVariable('ceq',fits.linearC(2));
input=input.setVariable('ms',p.ms); input=input.setVariable('mu',p.mu);
input=input.setVariable('kt',p.kt); input=input.setVariable('ct',p.ct);
input=input.setVariable('stopTime',t(end)); input=input.setVariable('outputTimes',t');
input=input.setModelParameter('Solver','ode45','RelTol',num2str(p.relTol), ...
    'AbsTol',num2str(p.absTol),'MaxStep',num2str(p.dt),'StopTime','stopTime', ...
    'ReturnWorkspaceOutputs','on','OutputOption','SpecifiedOutputTimes','OutputTimes','outputTimes');
output=sim(input); logged=output.states; data=squeeze(logged.Data);
if size(data,1)~=numel(logged.Time), data=data'; end
assert(size(data,2)==4,'Log exactly four states, ordered [zs vs zu vu].');
[sourceTime,keep]=unique(logged.Time);
x=interp1(sourceTime,data(keep,:),t,'linear');
assert(all(isfinite(x),'all'),'Simulink logging must span the MATLAB time grid.');
error=max(abs(matlab.states(:,[1 3])-x(:,[1 3])),[],1);
agreement=table(["Body";"Wheel"],error', ...
    'VariableNames',{'Position','MaxPositionDifference_m'});
writetable(agreement,fullfile(p.outputDir,'linear_verification.csv'));
verification=struct('t',t,'matlabStates',matlab.states,'simulinkStates',x, ...
    'agreement',agreement,'inputGrid_s',.0002,'modelPath',modelPath);
save(fullfile(p.outputDir,'linear_verification.mat'),'verification');
f=figure('Visible','off'); tiledlayout(2,1);
for j=1:2
    nexttile; state=2*j-1;
    plot(t,1000*matlab.states(:,state),t,1000*x(:,state),'--'); grid on;
    ylabel('Displacement (mm)'); title(agreement.Position(j));
end
xlabel('Time (s)'); legend({'MATLAB','Simulink'},'Location','best');
provided.save_plot(f,p,'linear_verification');
assert(all(error<1e-5), ...
    'MATLAB and Simulink disagree: inspect force signs, state order, coefficients, inputs, and initial conditions.');
end
