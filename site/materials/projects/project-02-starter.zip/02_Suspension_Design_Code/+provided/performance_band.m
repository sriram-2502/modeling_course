function band = performance_band(rms,goodLimits,acceptableLimits,feasible)
% PERFORMANCE_BAND Road or both-road rating under the unchanged course rules.
if ~all(feasible(:)) || any(~isfinite(rms(:)))
    band="Needs improvement";
elseif all(rms(:)<=goodLimits(:)), band="Good";
elseif all(rms(:)<=acceptableLimits(:)), band="Acceptable";
else, band="Needs improvement";
end
end
