function force = damper_force(v,p,fits,damper,mode)
% DAMPER_FORCE Select a force model without changing the student ODE.
if mode~="linear" && any(abs(v)>p.velocityLimit,'all')
    error('provided:DamperSupport','Damper velocity exceeds +/-2 m/s CSV support.');
end
switch mode
    case "linear"
        force=fits.linearC(damper)*v;
    case "nonlinear"
        force=student.nonlinear_force(v,fits.nonlinear.parameters(damper,:));
    case "reference"
        force=interp1(p.damper.v_mps,p.damper{:,damper+1},v,'linear');
    otherwise
        error('provided:Mode','Unknown force model: %s',mode);
end
assert(isequal(size(force),size(v)) && all(isfinite(force),'all'), ...
    'Damper force must be finite and have the same shape as velocity.');
end
