function p = load_project(folder, settings)
% LOAD_PROJECT Fixed assignment data; paths are relative to this package.
p.ms=450; p.mu=45; p.kt=220000; p.ct=300; p.g=9.81;
p.springs=[18000 26000 34000]; p.dt=.002;
p.entryTime=1; p.settleTime=4; p.taperLength=5;
p.relTol=1e-8; p.absTol=1e-10;
p.travelLimit=.080; p.loadLimit=.10; p.velocityLimit=2;
p.frequencies=logspace(log10(.2),log10(20),61);
p.sineAmplitude=.001;
p.roads(1)=struct('name',"A",'speed',20/3.6,'length',3.6576, ...
    'height',.0762,'good',1,'acceptable',1.5);
p.roads(2)=struct('name',"B",'speed',40/3.6,'length',100, ...
    'height',NaN,'good',.6,'acceptable',.8);
p.projectDir=folder; p.outputDir=fullfile(folder,'results');
p.modelDir=fullfile(folder,'models');
if ~exist(p.outputDir,'dir'), mkdir(p.outputDir); end
p.damper=readtable(fullfile(folder,'data','damper_curves.csv'));
assert(isequal(p.damper.Properties.VariableNames,{'v_mps','D1_N','D2_N','D3_N'}));
assert(height(p.damper)==1601 && all(diff(p.damper.v_mps)>0));
assert(all(isfinite(p.damper{:,:}),'all'));
p.fitInterval=settings.fitInterval; p.designPairs=settings.designPairs;
assert(isnumeric(p.fitInterval) && isequal(size(p.fitInterval),[1 2]) && ...
    all(isfinite(p.fitInterval)) && p.fitInterval(1)<0 && p.fitInterval(2)>0 && ...
    p.fitInterval(1)>=-2 && p.fitInterval(2)<=2,'Use a fitting interval around zero within CSV support.');
assert(isnumeric(p.designPairs) && size(p.designPairs,2)==2 && ...
    size(p.designPairs,1)>=3 && all(ismember(p.designPairs,1:3),'all') && ...
    size(unique(p.designPairs,'rows'),1)==size(p.designPairs,1) && ...
    ismember([2 2],p.designPairs,'rows'), ...
    'Choose distinct pairs including baseline [2 2] and at least two alternatives.');
end
