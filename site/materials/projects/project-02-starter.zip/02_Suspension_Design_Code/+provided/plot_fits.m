function errors = plot_fits(p,fits)
% PLOT_FITS Overlay data and fitted forces; report errors on common ranges.
v=p.damper.v_mps; central=v>=p.fitInterval(1) & v<=p.fitInterval(2);
assert(nnz(central)>=3,'Choose a fitting interval containing enough data.');
rows=struct([]); f=figure('Visible','off','Position',[100 100 1050 360]);
tiledlayout(1,3,'TileSpacing','compact');
for d=1:3
    data=p.damper{:,d+1}; linear=provided.damper_force(v,p,fits,d,"linear");
    nonlinear=provided.damper_force(v,p,fits,d,"nonlinear");
    row=struct('Damper',d,'LinearC_Ns_per_m',fits.linearC(d), ...
        'LinearCentralRMSE_N',sqrt(mean((linear(central)-data(central)).^2)), ...
        'NonlinearCentralRMSE_N',sqrt(mean((nonlinear(central)-data(central)).^2)), ...
        'LinearFullRMSE_N',sqrt(mean((linear-data).^2)), ...
        'NonlinearFullRMSE_N',sqrt(mean((nonlinear-data).^2)));
    if isempty(rows), rows=row; else, rows(end+1)=row; end %#ok<AGROW>
    nexttile; plot(v(1:20:end),data(1:20:end),'o','MarkerSize',3); hold on;
    plot(v,linear,'--'); plot(v,nonlinear,'-','LineWidth',1.3);
    xline(p.fitInterval(1),':','HandleVisibility','off'); xline(p.fitInterval(2),':','HandleVisibility','off');
    xlabel('Velocity (m/s)'); ylabel('Force (N)'); title("D"+d); grid on;
    if d==1
        lg=legend({'CSV samples','Linear fit','Nonlinear fit'},'Orientation','horizontal');
        lg.Layout.Tile='south';
    end
end
errors=struct2table(rows); writetable(errors,fullfile(p.outputDir,'force_fit_errors.csv'));
provided.save_plot(f,p,'damper_fits');
end
