function metric = evaluate_response(response,p)
% EVALUATE_RESPONSE Supplied metrics; never rate a partial run as completed.
metric=struct('rmsAcceleration',NaN,'peakAcceleration',NaN,'maxTravel',NaN, ...
    'minLoadFraction',NaN,'maxDamperSpeed',NaN,'feasible',false,'roadBand',"Needs improvement");
if ~response.completed, return; end
use=response.t>=p.entryTime-1e-12; t=response.t(use); a=response.bodyAcceleration(use);
metric.rmsAcceleration=sqrt(trapz(t,a.^2)/(t(end)-t(1)));
metric.peakAcceleration=max(abs(a)); metric.maxTravel=max(abs(response.travel(use)));
metric.minLoadFraction=min(response.tireLoad(use))/((p.ms+p.mu)*p.g);
metric.maxDamperSpeed=max(abs(response.damperVelocity(use)));
metric.feasible=metric.maxTravel<=p.travelLimit && metric.minLoadFraction>=p.loadLimit ...
    && metric.maxDamperSpeed<=p.velocityLimit;
road=p.roads(response.roadIndex);
metric.roadBand=provided.performance_band(metric.rmsAcceleration,road.good,road.acceptable,metric.feasible);
end
