function save_plot(fig,p,name)
% SAVE_PLOT Full data remain in the MAT file; figures are convenient evidence.
exportgraphics(fig,fullfile(p.outputDir,[name '.pdf']),'ContentType','vector');
exportgraphics(fig,fullfile(p.outputDir,[name '.png']),'Resolution',180);
close(fig);
end
