function t = time_grid(p,roadIndex)
% TIME_GRID Exact terminal time is included even if not a grid multiple.
road=p.roads(roadIndex);
last=p.entryTime+road.length/road.speed+p.settleTime;
t=(0:p.dt:last)';
if last-t(end)>1e-10, t(end+1,1)=last; end
end
