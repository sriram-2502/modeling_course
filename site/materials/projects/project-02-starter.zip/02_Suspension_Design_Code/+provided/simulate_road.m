function response = simulate_road(p,fits,pair,roadIndex,mode)
% SIMULATE_ROAD Integrate the STUDENT ODE with a chosen force callback.
t=provided.time_grid(p,roadIndex);
forceLaw=@(v) provided.damper_force(v,p,fits,pair(2),mode);
roadInput=@(time) provided.road_input(time,p,roadIndex);
rhs=@(time,x) student.quarter_car_rhs(time,x,p,p.springs(pair(1)),forceLaw,roadInput);
options=odeset('RelTol',p.relTol,'AbsTol',p.absTol,'MaxStep',p.dt);
try
    dx=rhs(0,zeros(4,1));
    assert(isequal(size(dx),[4 1]) && all(isfinite(dx)),'ODE output must be a finite 4-by-1 column.');
    [t,x]=ode45(rhs,t,zeros(4,1),options);
    [r,rdot]=roadInput(t); velocity=x(:,2)-x(:,4); travel=x(:,1)-x(:,3);
    % Recover acceleration by calling the student force-balance ODE.
    acceleration=zeros(size(t));
    for k=1:numel(t), derivative=rhs(t(k),x(k,:)'); acceleration(k)=derivative(2); end
    tireLoad=(p.ms+p.mu)*p.g-p.kt*(x(:,3)-r)-p.ct*(x(:,4)-rdot);
    response=struct('completed',true,'t',t,'states',x,'road',r,'roadVelocity',rdot, ...
        'bodyAcceleration',acceleration,'travel',travel,'damperVelocity',velocity, ...
        'tireLoad',tireLoad,'pair',pair,'roadIndex',roadIndex,'mode',mode,'failureReason',"");
catch problem
    if ~strcmp(problem.identifier,'provided:DamperSupport'), rethrow(problem); end
    response=struct('completed',false,'pair',pair,'roadIndex',roadIndex,'mode',mode, ...
        'failureReason',string(problem.message));
end
response.metric=provided.evaluate_response(response,p);
end
