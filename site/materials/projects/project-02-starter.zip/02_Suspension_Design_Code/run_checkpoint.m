function output = run_checkpoint(stage,pair)
% RUN_CHECKPOINT Test one stage without completing all seven student functions.
%   run_checkpoint("linear_fit")  requires only fit_linear
%   run_checkpoint("fits")        requires all three fitting functions
%   run_checkpoint("matlab")      requires fit_linear and quarter_car_rhs
%   run_checkpoint("simulink")    adds your completed Simulink plant/function
%   run_checkpoint("reference")   requires ONLY quarter_car_rhs
%   run_checkpoint("sine",[s d])  requires fit_linear and quarter_car_rhs
% The reference checkpoint simulates baseline Test A; the sine checkpoint
% defaults to baseline. Full report results still come from run_project.m.
if nargin<2, pair=[2 2]; end
assert(isnumeric(pair) && isequal(size(pair),[1 2]) && all(ismember(pair,1:3)), ...
    'Specify pair indices as [spring damper], each in 1:3.');
stage=string(stage);
assert(isscalar(stage) && ismember(stage,["linear_fit","fits","matlab","simulink","reference","sine"]), ...
    'Choose linear_fit, fits, matlab, simulink, reference, or sine.');
folder=fileparts(mfilename('fullpath')); addpath(folder);
p=provided.load_project(folder,project_settings()); output=struct('stage',stage);
fits=struct;
if stage~="reference"
    fits.linearC=student.fit_linear(p.damper,p.fitInterval);
    assert(isequal(size(fits.linearC),[1 3]) && all(isfinite(fits.linearC)) && ...
        all(fits.linearC>0),'Return three finite positive linear coefficients.');
end
switch stage
    case "linear_fit"
        use=p.damper.v_mps>=p.fitInterval(1) & p.damper.v_mps<=p.fitInterval(2);
        f=figure('Visible','off'); tiledlayout(1,3);
        for d=1:3
            nexttile; v=p.damper.v_mps(use);
            plot(v,p.damper{use,d+1},'o',v,fits.linearC(d)*v,'--');
            grid on; title("D"+d); xlabel('Velocity (m/s)'); ylabel('Force (N)');
        end
        provided.save_plot(f,p,'checkpoint_linear_fit');
        output.linearC=fits.linearC;
        % This partial fit file is enough for open_simulink.m; a full fits
        % checkpoint/main run replaces it with both fitted representations.
        save(fullfile(p.outputDir,'damper_fits.mat'),'fits');
    case "fits"
        fits.nonlinear=student.fit_nonlinear(p.damper);
        provided.check_fits(p,fits); output.forceErrors=provided.plot_fits(p,fits);
        output.fits=fits; save(fullfile(p.outputDir,'damper_fits.mat'),'fits');
    case {"matlab","reference"}
        mode="linear"; if stage=="reference", mode="reference"; end
        response=provided.simulate_road(p,fits,[2 2],1,mode);
        assert(response.completed,'Baseline did not complete: inspect CSV support and the ODE.');
        output.response=response; disp(response.metric);
        f=figure('Visible','off');
        plot(response.t,1000*response.states(:,[1 3])); grid on;
        xlabel('Time (s)'); ylabel('Displacement (mm)'); legend({'Body','Wheel'});
        provided.save_plot(f,p,['checkpoint_' char(stage)]);
    case "simulink"
        output.verification=provided.verify_simulink(p,fits);
        disp(output.verification.agreement);
    case "sine"
        output.sweep=provided.sine_sweep(p,fits,pair);
end
save(fullfile(p.outputDir,"checkpoint_"+stage+".mat"),'output');
fprintf('Checkpoint %s completed. Outputs: %s\n',stage,p.outputDir);
end
