function linearC = fit_linear(damperData, fitInterval)
% TASK 1a: Fit a through-origin line F = c*v for each of D1, D2, D3.
% IN:  damperData table: v_mps, D1_N, D2_N, D3_N; fitInterval [low high] m/s.
% OUT: linearC = [c_D1 c_D2 c_D3], a finite positive 1-by-3 row in N*s/m.
% Steps: select the same velocity rows for all dampers; fit zero-intercept
% slopes; return coefficients in D1/D2/D3 order. Justify the interval.
linearC = nan(1,3);
% TODO: replace the error below with your implementation.
error('student:Todo','Task 1a: complete +student/fit_linear.m');
end
