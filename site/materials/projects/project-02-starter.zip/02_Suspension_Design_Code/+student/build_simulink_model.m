function modelPath = build_simulink_model(p)
% TASK 1b: Complete models/student_quarter_car.slx and save it.
% Start from the quarter-car Simulink example already provided on Canvas.
% Adapt it to this assignment's parameters, tire damping, and logging contract.
% The scaffold supplies input sources, four integrators, and state logging.
% ADD your relative-motion sums, force gains, mass gains, and connections.
% Keep these workspace variable names: roadHeight, roadVelocity (timeseries),
% ks, ceq, ms, mu, kt, ct, stopTime, outputTimes.
% Log a Timeseries named states, ordered [zs vs zu vu], through StateOutput.
% Implement force sums/gains/integrators independently of quarter_car_rhs.m.
% Build in the Simulink editor or add your own add_block/add_line code here.
modelPath = fullfile(p.modelDir,'student_quarter_car.slx');
% TODO: after completing and saving the model, remove this error.
error('student:Todo','Task 1b: complete the Simulink scaffold and this function.');
end
