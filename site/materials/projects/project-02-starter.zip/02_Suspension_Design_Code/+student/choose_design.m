function choice = choose_design(summary, p, stage)
% TASKS 2a/2c: Choose one pair for BOTH roads and explain your priorities.
% IN: one row per design (provided.summarize_designs); stage is "linear"
%     for a provisional choice or "reference" for the final recommendation.
% OUT: choice.pair=[springIndex damperIndex], chosen from summary;
%      choice.reason=nonempty string explaining the criterion/tradeoff.
% The final pair must be feasible on both roads. If no feasible row exists,
% add/revise candidate pairs and rerun; do not silently recommend a failed pair.
% The main script calls this function only when a linear feasible pair exists;
% otherwise it records no provisional choice and continues to CSV validation.
% WorstNormalizedRMS is supplied as an OPTIONAL criterion, not a required answer.
% A smaller predicted comfort score is different from a smaller model error.
% In your REPORT, also discuss how camera/LiDAR road preview and an active
% suspension actuator might extend this passive design. This is conceptual;
% no controller, sensor model, or extra function is required in this starter.
choice = struct('pair',[NaN NaN],'reason',"");
% TODO: implement a defensible choice. Explain changes after CSV validation.
error('student:Todo','Tasks 2a/2c: complete +student/choose_design.m');
end
