% Functions to complete for ME3050 suspension project.
% Task 1a: fit_linear, fit_nonlinear, nonlinear_force
% Task 1b: quarter_car_rhs, build_simulink_model (and the .slx plant)
% Task 2b: compare_responses
% Tasks 2a/2c: choose_design
% Task 1c and shared evaluation helpers are in the provided package.
