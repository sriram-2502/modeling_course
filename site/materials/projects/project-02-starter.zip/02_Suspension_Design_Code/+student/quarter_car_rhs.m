function dx = quarter_car_rhs(t, x, p, springK, forceLaw, roadInput)
% TASK 1b: Write the four first-order equations from the handout.
% IN: t seconds; x=[zs;vs;zu;vu]; p fixed parameters; springK in N/m.
%     forceLaw(v) returns signed damper force in N.
%     [r,rdot]=roadInput(t) returns road height/vertical velocity.
% OUT: dx=[vs;as;vu;au], a finite 4-by-1 column.
% Use the callbacks rather than choosing linear/nonlinear/CSV modes here.
% The identical ODE must support all three force laws and both roads.
% [r,rdot] = roadInput(t);
% relativeVelocity = x(2)-x(4);
% damperForce = forceLaw(relativeVelocity);
dx = nan(4,1);
% TODO: obtain the forces and apply Newton's law to each mass.
error('student:Todo','Task 1b: complete +student/quarter_car_rhs.m');
end
