function force = nonlinear_force(velocity, parameters)
% TASK 1a: Evaluate your fitted nonlinear damper law.
% IN:  velocity scalar/vector in m/s; ONE damper's 1-by-P parameter row.
% OUT: force in N, exactly the same shape as velocity.
% Evaluate both signs correctly. Use elementwise operations for arrays.
% Positive relative velocity means rebound; negative means compression.
force = nan(size(velocity));
% TODO: implement the family fitted in fit_nonlinear.m.
error('student:Todo','Task 1a: complete +student/nonlinear_force.m');
end
