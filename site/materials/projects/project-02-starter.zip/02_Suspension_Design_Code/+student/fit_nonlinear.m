function model = fit_nonlinear(damperData)
% TASK 1a: Fit ONE justified nonlinear family to all three damper curves.
% IN:  damperData table with velocity in m/s and signed forces in N.
% OUT: model.parameters: finite 3-by-P matrix; row d belongs to damper d.
% Choose your own nonlinear family and number of parameters P from the data.
% Define each parameter's meaning, order, and units consistently in both files.
% MATLAB idea: minimize summed squared force errors using fminsearch.
% If the chosen family needs positive parameters, a transformed parameterization
% can help. fminbnd is another option for a one-dimensional bounded search.
% Optional: lsqcurvefit if you have Optimization Toolbox (not required).
% Keep the interface here and implement nonlinear_force.m to evaluate your
% chosen family's parameter rows. Explain your choice.
% Preserve F(0)=0 and v*F(v)>=0; document the training range in your report.
model.parameters = []; % TODO: replace with your fitted 3-by-P parameter matrix.
% TODO: fit parameters to the data; do not copy CSV values into the evaluator.
error('student:Todo','Task 1a: complete +student/fit_nonlinear.m');
end
