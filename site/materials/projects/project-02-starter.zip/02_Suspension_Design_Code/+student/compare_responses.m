function comparison = compare_responses(model, reference, p)
% TASK 2b: Quantify fitted-model error relative to CSV interpolation.
% IN: complete response structs; p settings. Helpers have already attached
%     model.metric and reference.metric (same metric names for both).
% OUT: struct fields with scalar finite values:
% rmsErrorPercent       signed percent error in acceleration RMS
% accelerationErrorRMS  time-weighted RMS of (model acceleration - reference)
% velocityMin, velocityMax  CSV-reference damper-velocity range, in m/s
% outsideFitFraction    fraction of reference output samples outside fitInterval
% Evaluate t>=p.entryTime through the last sample. Interpolate the model onto
% reference times if necessary. RMS error and error-history RMS are different.
comparison = struct('rmsErrorPercent',NaN,'accelerationErrorRMS',NaN, ...
    'velocityMin',NaN,'velocityMax',NaN,'outsideFitFraction',NaN);
% TODO: calculate and interpret the differences; keep the CSV reference fixed.
error('student:Todo','Task 2b: complete +student/compare_responses.m');
end
