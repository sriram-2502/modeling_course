Generated outputs will appear here after you complete the student functions.
The starter does not include solved designs, fitted coefficients, or instructor results.
After run_project.m saves student_results.mat, run ../animate_results.m in MATLAB
to replay your responses. The supplied animation does not run the solver again.
