% OPEN_SIMULINK Prepare baseline Test A variables for interactive model editing.
% First complete Task 1a and run that section of run_project to save the fits.
projectFolder=fileparts(mfilename('fullpath')); addpath(projectFolder);
p=provided.load_project(projectFolder,project_settings());
fitFile=fullfile(p.outputDir,'damper_fits.mat');
assert(isfile(fitFile),'First run the setup and Task 1a sections of run_project.m.');
saved=load(fitFile,'fits');
ms=p.ms; mu=p.mu; kt=p.kt; ct=p.ct; ks=p.springs(2); ceq=saved.fits.linearC(2);
t=provided.time_grid(p,1); stopTime=t(end); outputTimes=t';
sourceTime=unique([(0:.0002:stopTime)';p.entryTime; ...
    p.entryTime+p.roads(1).length/p.roads(1).speed;stopTime]);
[r,rdot]=provided.road_input(sourceTime,p,1);
roadHeight=timeseries(r,sourceTime); roadVelocity=timeseries(rdot,sourceTime);
open_system(fullfile(p.modelDir,'student_quarter_car.slx'));
fprintf('Baseline Test A variables are ready. Complete the plant and save the model.\n');
